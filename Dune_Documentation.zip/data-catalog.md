[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Data Catalog

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Blockchain Data](#blockchain-data)
* [EVM Chains](#evm-chains)
* [Other Chains](#other-chains)
* [Adding new blockchains](#adding-new-blockchains)
* [Curated](#curated)
* [Community Data](#community-data)
* [Our Data Difference](#our-data-difference)

# Data Catalog

Dune’s extensive data catalog provides detailed analytics for a wide range of blockchains.

Our data catalog can be divided into the following categories:

* [Blockchain Data](#blockchain-data)
  + [EVM-Compatible Chains](#evm-compatible-chains)
  + [Other chains](#other-chains)
* [Curated Data](#curated)
  + dex trades
  + nft trades
  + labels
  + etc.
* [Community Data](#community-data)
  + farcaster
  + lens protocol
  + snapshot
  + reservoir
  + etc.

Our entire data catalog is accessible through the Dune [Web App](/web-app/overview), the [Dune API](/api-reference/overview/introduction) or the [Snowflake Data Marketplace](https://app.snowflake.com/marketplace/providers/GZSVZMYSCO/Dune).

Learn about our curated dataset building and contribution process in Spellbook:


# [​](#blockchain-data) Blockchain Data

Dune provides data for a wide range of blockchains. Our data catalog includes raw data, decoded data, and abstracted data tables for each blockchain.

### [​](#evm-chains) EVM Chains

We provide the most comprehensive data catalog for Ethereum Mainnet and EVM-compatible rollups, sidechains and other layer 2 solutions.
All EVM chains on Dune have raw data, decoded data and abstracted data tables available.

[## Raw data](./evm/ethereum/raw/transactions)[## Decoded data](./evm/ethereum/decoded/overview)[## Curated data](/data-catalog/curated/overview)

### [​](#other-chains) Other Chains

We provide data for a wide range of blockchains. The depth of data available for these chains may vary, but we always carry the full chain history in its raw form.

### [​](#adding-new-blockchains) Adding new blockchains

If you are a representative of a blockchain you would like to see supported on Dune, please reach out to us. We are always looking to expand our data catalog and provide the most comprehensive data available.

[## 

Request a new blockchain integration!](https://dune.com/enterprise)

# [​](#curated) Curated

Dune provides a wide range of curated tables that simplify the process of querying and analyzing blockchain data. These tables are built on top of raw and decoded data tables and provide a high-level view of the data.

[## Curated Data

Curated data simplifies the process of querying and analyzing blockchain data.](/data-catalog/curated/overview)

# [​](#community-data) Community Data

Dune also carries off-chain data important to the web3 ecosystem that is provided by third-party data providers.

## [​](#our-data-difference) Our Data Difference

We are building world-class data infrastructure so you don’t have to. Our data catalog is designed to provide the most comprehensive and accurate blockchain data available. We are committed to delivering the highest quality data, with the following features:

* **Comprehensive Chain Histories:** Full access to blockchain data histories without gaps, ensuring source integrity.
* **Accurate and Validated Data:** Commitment to accuracy, with validated consistency and uniqueness for all transactions and events.
* **Rich Data Variety:** Decoded data transforms complex byte arrays into clear, structured, and usable information.
* **abstracted Data:** Dune’s [Spellbook](https://github.com/duneanalytics/spellbook) enables collaborative, community-driven data modeling, unlocking new insights at lightning speed.
* **Vibrant Community Data Pools:** Access to vast pools of data contributed by an active and innovative community.
* **Cross-Chain:** Our entire data catalog is hosted in the same database, making it easy to compare and contrast data across different chains.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/overview)

[Data Freshness](/data-catalog/data-freshness)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.