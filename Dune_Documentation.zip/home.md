[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Welcome to Dune

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Welcome to Dune](/home)
* [Quickstart](/quickstart)
* [Web3 Data Resources](/learning-resources)

##### Jump right in

* [Create your first query](/learning/how-tos/create-your-first-query)
* [Create New Content](/learning/how-tos/create-new-content)
* [Create your first visualization](/learning/how-tos/create-your-first-visualization)
* [Navigate the Query Editor](/learning/how-tos/navigate-query-editor)
* [Find Datasets on Dune](/learning/how-tos/find-datasets)
* [Export Data Out of Dune](/learning/how-tos/export-data-out)
* [Create and Manage Teams on Dune](/learning/how-tos/create-and-manage-teams)
* [Understanding Credits on Dune](/learning/how-tos/credit-system-on-dune)
* [Search for Content on Dune](/learning/how-tos/search-for-content)
* [Share Dune Content](/learning/how-tos/share-dune-content)
* [Share your query](/learning/how-tos/share-your-query)
* [Transfer Ownership](/learning/how-tos/transfer-ownership)
* [Migrating from Flipside to Dune](/learning/flipside-migration-guide)

On this page

* [Go through our YouTube Tutorials](#go-through-our-youtube-tutorials)
* [Start building](#start-building)
* [Learn more](#learn-more)
* [Why Dune?](#why-dune%3F)

# Welcome to Dune

Dune is a web-based platform that allows you to query public blockchain data and aggregate it into beautiful dashboards.

Blockchains are open and transparent, but each chain is unique—making it difficult to understand, ingest, and aggregate data. Dune gives you the tools to analyze cross-chain data for different tokens, wallets, and protocols. You can also easily share your work with the community, export and integrate data into your own applications, and more.

### [​](#go-through-our-youtube-tutorials) Go through our YouTube Tutorials

We’ve created tutorials covering all product surfaces of Dune, how to navigate and understand all tables, and how to level up as a crypto data analyst. [Check out the full playlist.](https://www.youtube.com/playlist?list=PLK3b5d4iK10ext4v-GBySekaA8-GP8quD)


### [​](#start-building) Start building

Ready to start building? Once you have an [account](https://dune.com/auth/register) and you have reviewed the [Quickstart](quickstart), check out these essentials to start using Dune.

[## Web App

Learn about the Dune Web App, your portal to creating, viewing, and interacting with blockchain analytics dashboards.](/web-app)[## Data Catalog

Explore our comprehensive Data Catalog to find and utilize the exact datasets you need for your queries and analytics.](/data-catalog)[## API

Integrate Dune directly into your workflow with our API, allowing for automated data extraction and analysis.](/api-reference)[## Query Engine

Discover the power of the Dune Query Engine to execute advanced SQL queries and analyze blockchain data.](/query-engine)[## Alerts

Set up alerts to be notified when specific conditions are met in the data.](/web-app/alerts)

**Quickstart**
To get started with Dune in 5 minutes, see the [Quickstart](/quickstart).

### [​](#learn-more) Learn more

If you are new to blockchain or SQL —or want to go deeper on Dune concepts and best practices— check out the following resources:

* [Dune Official Getting Started Video Series](https://www.youtube.com/watch?v=S-cctFmR828&list=PLK3b5d4iK10ext4v-GBySekaA8-GP8quD&index=1) to learn how data flows and how to navigate the Dune app to get the most out of it
* Join our community in [Discord](https://discord.gg/FjwGvbgDFS) to get support through the `#🐥︱beginners` and `#🙋︱query-questions` channels

You can also level up by following the [crypto data analyst roadmap](https://roadmap.sh/r?id=65fee5b66deb533d6e19fb88):

  
  


### [​](#why-dune%3F) Why Dune?

Dune—along with our massive community of users and experts—provides powerful tools and analysis of all onchain data. You can find a [dashboard](https://dune.com/browse/dashboards?q=dex&order=favorites&time_range=all) for pretty much anything web3-related, including for EVMs like Ethereum, Polygon, Goerli, and Optimism—and non-EVM chains like Solana and Bitcoin.
Examples of real dashboards:

* [NFT marketplaces](https://dune.com/hildobby/ethereum-nfts)
* [DEX metrics](https://dune.com/hagaetc/dex-metrics)
* [Project metrics](https://dune.com/whale_hunter/unibot-revenue)
* [DAO Accounting (Maker)](https://dune.com/steakhouse/makerdao)
* [Base Chain Metrics](https://dune.com/optimismfnd/Optimism)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /home)

[Quickstart](/quickstart)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.