[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Queries

Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries

  + [Overview](/api-reference/queries/endpoint/query-object)
  + [POST

    Create Query](/api-reference/queries/endpoint/create)
  + [GET

    Read Query](/api-reference/queries/endpoint/read)
  + [PATCH

    Update Query](/api-reference/queries/endpoint/update)
  + [POST

    Archive Query](/api-reference/queries/endpoint/archive)
  + [POST

    Unarchive Query](/api-reference/queries/endpoint/unarchive)
  + [POST

    Private Query](/api-reference/queries/endpoint/private)
  + [POST

    Unprivate Query](/api-reference/queries/endpoint/unprivate)
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

On this page

* [Queries](#queries)
* [Query Parameters](#query-parameters)

Queries

# Overview

These query management endspoints help you programmatically create and manage Dune SQL queries via the API, ideal for integration with GitHub or other CI/CD pipelines.

### [​](#queries) Queries

Queries all have a `query id` which is returned when you read/create a query. You can also find it within a url, i.e. `https://dune.com/queries/<query_id>/<visualization_id>`.
Each query comes with fields you can edit such as:

* `name`: query name text
* `description`: query description text
* `query_sql`: the raw sql text
* `params`: parameters within the query, using the `{{ foo }}` syntax. See the section below for more details.
* `is_private`: boolean for if query is private or not. Private queries cannot be found or queried by others.
* `archived`: boolean for if query is archived or not. Archived queries cannot run or edited by anyone.

### [​](#query-parameters) Query Parameters

There are four kinds of parameters you can use in a Dune query (these are not API parameters).

* number
* text
* date
* enum (called a list in the UI)

For passing these parameters through the API request body, you can use the following format for executions:

Copy

Ask AI

```
{
"foo": "value",
"bar":1000, 
"baz": "2020-12-01T01:20:30Z"
}

```

Where “foo”, “bar”, and “baz” are three params in a query. If you leave one out, it goes with the default param valiue.
For Queries endpoints, you’ll need to define the type and more:

Copy

Ask AI

```
[
    {
        "key": "block_time_start",
        "type": "datetime",
        "value": "2017-01-01 00:00:00"
    },
    {
        "key": "from",
        "type": "text",
        "value": "0xae2fc483527b8ef99eb5d9b44875f005ba1fae13"
    },
    {
        "key": "limit",
        "type": "number",
        "value": "20"
    },
    {
        "key": "type",
        "type": "enum",
        "value": "DynamicFee",
        "enumOptions": [
            "DynamicFee",
            "Legacy"
        ]
    }
]

```

Note that the `datetime` parameter type requires you use the syntax `timestamp '{{block_time_start}}'` to cast the parameter to a timestamp.
If you are using bytearrays/binary (`0x1234...`), then you will still pass it as text through the API but ensure your SQL text puts the parameter without any quotes around it.

If you’re using the Dune Python SDK, check out the [sdk doc page](/api-reference/overview/sdks) for an example.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/queries/endpoint/query-object)

[Get Latest Query Result in CSV](/api-reference/executions/endpoint/get-query-result-csv)[Create Query](/api-reference/queries/endpoint/create)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.