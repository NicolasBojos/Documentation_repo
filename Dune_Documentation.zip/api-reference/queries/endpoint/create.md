[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Queries

Create Query

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries

  + [Overview](/api-reference/queries/endpoint/query-object)
  + [POST

    Create Query](/api-reference/queries/endpoint/create)
  + [GET

    Read Query](/api-reference/queries/endpoint/read)
  + [PATCH

    Update Query](/api-reference/queries/endpoint/update)
  + [POST

    Archive Query](/api-reference/queries/endpoint/archive)
  + [POST

    Unarchive Query](/api-reference/queries/endpoint/unarchive)
  + [POST

    Private Query](/api-reference/queries/endpoint/private)
  + [POST

    Unprivate Query](/api-reference/queries/endpoint/unprivate)
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

cURL

Python SDK

Python

JavaScript

Go

PHP

Java

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/query \
  --header 'Content-Type: application/json' \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --data '{
  "name": "erc20 balances (user address) API",
  "description": "Example Blockchain Query",
  "parameters": [
    {
      "key": "address",
      "value": "0x2ae8c972fb2e6c00dded8986e2dc672ed190da06",
      "type": "text"
    },
    {
      "key": "blocknumber",
      "value": "0",
      "type": "number"
    },
    {
      "key": "chain",
      "value": "ethereum",
      "type": "enum",
      "enumOptions": [
        "ethereum",
        "polygon",
        "optimism",
        "arbitrum",
        "avalanche_c",
        "gnosis",
        "bnb"
      ]
    }
  ],
  "query_sql": "SELECT * FROM {{blockchain}}.transactions WHERE to = {{address}} AND block_number > {{blocknumber}}",
  "is_private": true
}'

```

200

400

401

402

403

500

Copy

Ask AI

```
{
  "query_id": 1
}
```

Queries

# Create Query

This API allows for anyone to create a query.
The owner of the query will be under the context of the API key.

POST

/

v1

/

query

Try it

cURL

Python SDK

Python

JavaScript

Go

PHP

Java

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/query \
  --header 'Content-Type: application/json' \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --data '{
  "name": "erc20 balances (user address) API",
  "description": "Example Blockchain Query",
  "parameters": [
    {
      "key": "address",
      "value": "0x2ae8c972fb2e6c00dded8986e2dc672ed190da06",
      "type": "text"
    },
    {
      "key": "blocknumber",
      "value": "0",
      "type": "number"
    },
    {
      "key": "chain",
      "value": "ethereum",
      "type": "enum",
      "enumOptions": [
        "ethereum",
        "polygon",
        "optimism",
        "arbitrum",
        "avalanche_c",
        "gnosis",
        "bnb"
      ]
    }
  ],
  "query_sql": "SELECT * FROM {{blockchain}}.transactions WHERE to = {{address}} AND block_number > {{blocknumber}}",
  "is_private": true
}'

```

200

400

401

402

403

500

Copy

Ask AI

```
{
  "query_id": 1
}
```

To access Query endpoints, an [Analyst plan](https://dune.com/pricing) or higher is required.

cURL

Python SDK

Python

JavaScript

Go

PHP

Java

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/query \
  --header 'Content-Type: application/json' \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --data '{
  "name": "erc20 balances (user address) API",
  "description": "Example Blockchain Query",
  "parameters": [
    {
      "key": "address",
      "value": "0x2ae8c972fb2e6c00dded8986e2dc672ed190da06",
      "type": "text"
    },
    {
      "key": "blocknumber",
      "value": "0",
      "type": "number"
    },
    {
      "key": "chain",
      "value": "ethereum",
      "type": "enum",
      "enumOptions": [
        "ethereum",
        "polygon",
        "optimism",
        "arbitrum",
        "avalanche_c",
        "gnosis",
        "bnb"
      ]
    }
  ],
  "query_sql": "SELECT * FROM {{blockchain}}.transactions WHERE to = {{address}} AND block_number > {{blocknumber}}",
  "is_private": true
}'

```

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

API Key, alternative to using the HTTP header X-Dune-Api-Key

#### Body

\*/\*

CreateQueryRequest

The body is of type `object`.

#### Response

200

200400401402403500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/queries/endpoint/create)

[Overview](/api-reference/queries/endpoint/query-object)[Read Query](/api-reference/queries/endpoint/read)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.