[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EigenLayer

Dune EigenLayer Endpoints

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer

  + [Dune EigenLayer Endpoints](/api-reference/eigenlayer/introduction)
  + [GET

    AVS Metadata](/api-reference/eigenlayer/endpoint/avs_metadata)
  + [GET

    AVS Metrics](/api-reference/eigenlayer/endpoint/avs_metrics)
  + [GET

    Operator Metadata](/api-reference/eigenlayer/endpoint/operator_metadata)
  + [GET

    Operator Metrics](/api-reference/eigenlayer/endpoint/operator_metrics)
  + [GET

    Operator <> AVS Mapping](/api-reference/eigenlayer/endpoint/operator_to_avs_mapping)
* EVM Contracts
* Farcaster
* Markets
* Projects

EigenLayer

# Dune EigenLayer Endpoints

Leverage Dune’s API for direct access to [EigenLayer](https://www.eigenlayer.xyz/) data, streamlining your dApp and infrastructure development. No SQL needed—our Domain-specific API is designed for easy integration and flexible application use.

* **JSON Format**: All endpoints deliver JSON-formatted data for straightforward integration.
* **Instant Access**: Begin immediately by [creating a free account](https://dune.com/auth/register) and [obtain an API key](.././overview/authentication).
* **Expansive Data Ecosystem**: Enhance your projects by connecting with an extensive range of on-chain and off-chain data, from [Farcaster](.././farcaster/introduction) to [DEX](../dex/endpoint/dex_pair.mdx) and more. Build alongside with our vibrant community.

[## AVS Metadata

Get AVS metadata, including name, address, and more.](/api-reference/eigenlayer/endpoint/avs_metadata)[## Operator Metadata

Get operator metadata, including name, address, and more.](/api-reference/eigenlayer/endpoint/operator_metadata)[## AVS Metrics

Get AVS metrics, including TVL, number of operators and number of stakers.](/api-reference/eigenlayer/endpoint/avs_metrics)[## Operator Metrics

Get operator metrics, including TVL, number of stakers, and more.](/api-reference/eigenlayer/endpoint/operator_metrics)[## Operator <> AVS Mapping

Get a mapping of which operator is registered to which AVS and when it was registered.](/api-reference/eigenlayer/endpoint/operator_to_avs_mapping)

  

To custom-build an API endpoint with SQL query, watch [this short video](https://youtu.be/o29ig849qMY) and [get started here](.././quickstart/results-eg)!

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/eigenlayer/introduction)

[DEX Pair Stats](/api-reference/dex/endpoint/dex_pair)[AVS Metadata](/api-reference/eigenlayer/endpoint/avs_metadata)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.