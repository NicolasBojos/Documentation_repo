[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EigenLayer

Operator Metadata

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer

  + [Dune EigenLayer Endpoints](/api-reference/eigenlayer/introduction)
  + [GET

    AVS Metadata](/api-reference/eigenlayer/endpoint/avs_metadata)
  + [GET

    AVS Metrics](/api-reference/eigenlayer/endpoint/avs_metrics)
  + [GET

    Operator Metadata](/api-reference/eigenlayer/endpoint/operator_metadata)
  + [GET

    Operator Metrics](/api-reference/eigenlayer/endpoint/operator_metrics)
  + [GET

    Operator <> AVS Mapping](/api-reference/eigenlayer/endpoint/operator_to_avs_mapping)
* EVM Contracts
* Farcaster
* Markets
* Projects

Operator Metadata

cURL

Copy

Ask AI

```
curl --request GET \
  --url https://api.dune.com/api/v1/eigenlayer/operator-metadata \
  --header 'X-Dune-Api-Key: <x-dune-api-key>'
```

200

400

401

402

403

404

500

Copy

Ask AI

```
{
  "cancelled_at": "2024-12-20T11:04:18.724658237Z",
  "execution_ended_at": "2024-12-20T11:04:18.724658237Z",
  "execution_id": "01HKZJ2683PHF9Q9PHHQ8FW4Q1",
  "execution_started_at": "2024-12-20T11:04:18.724658237Z",
  "expires_at": "2024-12-20T11:04:18.724658237Z",
  "is_execution_finished": true,
  "next_offset": 100,
  "next_uri": "https://api.dune.com/api/v1/execution/01HKZJ2683PHF9Q9PHHQ8FW4Q1/results?offset=100&limit=100",
  "query_id": 1234,
  "result": {
    "metadata": {
      "column_names": [
        "Rank",
        "Project",
        "Volume"
      ],
      "column_types": [
        "double",
        "varchar",
        "bigint"
      ],
      "datapoint_count": 1000,
      "execution_time_millis": 1000,
      "pending_time_millis": 1000,
      "result_set_bytes": 1000,
      "row_count": 10,
      "total_result_set_bytes": 10000,
      "total_row_count": 1000
    },
    "rows": [
      {}
    ]
  },
  "state": "QUERY_STATE_COMPLETED",
  "submitted_at": "2024-12-20T11:04:18.724658237Z"
}
```

EigenLayer

# Operator Metadata

Get metadata for all registered operators on Eigenlayer, including
`operator_name`, `operator_contract_address`, `website`, `twitter`, `logo`, `description`

GET

/

v1

/

eigenlayer

/

operator-metadata

Try it

Operator Metadata

cURL

Copy

Ask AI

```
curl --request GET \
  --url https://api.dune.com/api/v1/eigenlayer/operator-metadata \
  --header 'X-Dune-Api-Key: <x-dune-api-key>'
```

200

400

401

402

403

404

500

Copy

Ask AI

```
{
  "cancelled_at": "2024-12-20T11:04:18.724658237Z",
  "execution_ended_at": "2024-12-20T11:04:18.724658237Z",
  "execution_id": "01HKZJ2683PHF9Q9PHHQ8FW4Q1",
  "execution_started_at": "2024-12-20T11:04:18.724658237Z",
  "expires_at": "2024-12-20T11:04:18.724658237Z",
  "is_execution_finished": true,
  "next_offset": 100,
  "next_uri": "https://api.dune.com/api/v1/execution/01HKZJ2683PHF9Q9PHHQ8FW4Q1/results?offset=100&limit=100",
  "query_id": 1234,
  "result": {
    "metadata": {
      "column_names": [
        "Rank",
        "Project",
        "Volume"
      ],
      "column_types": [
        "double",
        "varchar",
        "bigint"
      ],
      "datapoint_count": 1000,
      "execution_time_millis": 1000,
      "pending_time_millis": 1000,
      "result_set_bytes": 1000,
      "row_count": 10,
      "total_result_set_bytes": 10000,
      "total_row_count": 1000
    },
    "rows": [
      {}
    ]
  },
  "state": "QUERY_STATE_COMPLETED",
  "submitted_at": "2024-12-20T11:04:18.724658237Z"
}
```

* Query powering this endpoint can be found [here](https://dune.com/queries/3685760)
* Scheduled to update 15 minutes
* Apply [filters](../../executions/filtering) like WHERE, IN, AND/OR upon results
* Use a combination of `sort_by` and `limit` to grab a subset of results, see [pagination](../../executions/pagination) and [sorting](../../executions/sorting) for more info

# [​](#column-descriptions) Column Descriptions

| Column | Description | Type |
| --- | --- | --- |
| operator\_name | Name of the operator | string |
| operator\_contract\_address | Ethereum contract address of the operator | string |
| website | Website URL of the operator | string |
| twitter | Twitter link of the operator | string |
| logo | URL to the logo image of the operator | string |
| description | Brief description of the operator | string |

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

API Key, alternative to using the HTTP header X-Dune-Api-Key

[​](#parameter-allow-partial-results)

allow\_partial\_results

boolean

This enables returning a query result that was too large and only a partial result is
available. By default allow\_partial\_results is set to false and a failed state is returned.

[​](#parameter-columns)

columns

string

Specifies a comma-separated list of column names to return. If omitted, all columns are included.
Tip: use this to limit the result to specific columns, reducing datapoints cost of the call.

[​](#parameter-filters)

filters

string

Expression to filter out rows from the results to return. This expression is similar to
a SQL WHERE clause. More details about it in the Filtering section of the doc.
This parameter is incompatible with sample\_count.

[​](#parameter-ignore-max-datapoints-per-request)

ignore\_max\_datapoints\_per\_request

boolean

There is a default 250,000 datapoints limit to make sure you don't accidentally spend all
your credits in one call. To ignore the max limit, you can add
ignore\_max\_datapoints\_per\_request=true

[​](#parameter-limit)

limit

integer

Limit number of rows to return. This together with 'offset' allows easy pagination through
results in an incremental and efficient way. This parameter is incompatible
with sampling (sample\_count).

[​](#parameter-offset)

offset

integer

Offset row number to start (inclusive, first row means offset=0) returning results
from. This together with 'limit' allows easy pagination through results in an
incremental and efficient way. This parameter is incompatible with sampling (sample\_count).

[​](#parameter-query-id)

queryID

integer

required

[​](#parameter-sample-count)

sample\_count

integer

Number of rows to return from the result by sampling the data. This is useful when you
want to get a uniform sample instead of the entire result. If the result has less
than the sample count, the entire result is returned. Note that this will return a
randomized sample, so not every call will return the same result. This parameter is
incompatible with `offset`, `limit`, and `filters` parameters.

[​](#parameter-sort-by)

sort\_by

string

Expression to define the order in which the results should be returned. This expression
is similar to a SQL ORDER BY clause. More details about it in the Sorting section of the doc.

#### Response

200

200400401402403404500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/eigenlayer/endpoint/operator_metadata)

[AVS Metrics](/api-reference/eigenlayer/endpoint/avs_metrics)[Operator Metrics](/api-reference/eigenlayer/endpoint/operator_metrics)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.