[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Tables

Clear Data

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

  + [Overview](/api-reference/tables/endpoint/overview)
  + [POST

    Create Table](/api-reference/tables/endpoint/create)
  + [POST

    Insert Data](/api-reference/tables/endpoint/insert)
  + [POST

    Upload CSV](/api-reference/tables/endpoint/upload)
  + [POST

    Clear Data](/api-reference/tables/endpoint/clear)
  + [DEL

    Delete Table](/api-reference/tables/endpoint/delete)

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

curl

Python

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/my_user/interest_rates/clear \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>'

```

200

401

404

500

Copy

Ask AI

```
{
  "message": "Table my_user.interest_rates successfully cleared"
}
```

Tables

# Clear Data

Clear data in a table.

POST

/

v1

/

table

/

{namespace}

/

{table\_name}

/

clear

Try it

curl

Python

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/my_user/interest_rates/clear \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>'

```

200

401

404

500

Copy

Ask AI

```
{
  "message": "Table my_user.interest_rates successfully cleared"
}
```

The `Clear` endpoint removes all the data in the specified table, but does not delete the table.

curl

Python

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/my_user/interest_rates/clear \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>'

```

#### Authorizations

[​](#authorization-x-dune-api-key)

x-dune-api-key

string

header

required

The API key of your team or user.

#### Path Parameters

[​](#parameter-namespace)

namespace

string

required

The the table to clear (e.g. `my_user`).

[​](#parameter-table-name)

table\_name

string

required

The name of the table to clear (e.g. `interest_rates`).

#### Response

200

200401404500

application/json

Successful operation

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/tables/endpoint/clear)

[Upload CSV](/api-reference/tables/endpoint/upload)[Delete Table](/api-reference/tables/endpoint/delete)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.