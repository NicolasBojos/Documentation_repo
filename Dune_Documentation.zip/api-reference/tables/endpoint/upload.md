[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Tables

Upload CSV

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

  + [Overview](/api-reference/tables/endpoint/overview)
  + [POST

    Create Table](/api-reference/tables/endpoint/create)
  + [POST

    Insert Data](/api-reference/tables/endpoint/insert)
  + [POST

    Upload CSV](/api-reference/tables/endpoint/upload)
  + [POST

    Clear Data](/api-reference/tables/endpoint/clear)
  + [DEL

    Delete Table](/api-reference/tables/endpoint/delete)

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

curl

Python SDK

TS SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/upload/csv \
  --header 'Content-Type: application/json' \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --data '{
  "data": "DATE,DGS10,\n2023-12-04,4.28,\n2023-12-05,4.18,\n2023-12-06,4.12,\n2023-12-07,4.14,\n2023-12-08,4.23,\n2023-12-11,4.23",
  "description": "10 year daily interest rates, sourced from https://fred.stlouisfed.org/series/DGS10",
  "table_name": "ten_year_us_interest_rates",
  "is_private": false
}'

```

200

400

401

500

Copy

Ask AI

```
{
  "success": true,
  "table_name": "ten_year_us_interest_rates"
}
```

Tables

# Upload CSV

This API allows for anyone to upload a CSV as a table in Dune. The size limit
per upload is currently 200MB. Your storage is limited by plan, 1MB on free,
15GB on plus, and 50GB on premium.

POST

/

v1

/

table

/

upload

/

csv

Try it

curl

Python SDK

TS SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/upload/csv \
  --header 'Content-Type: application/json' \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --data '{
  "data": "DATE,DGS10,\n2023-12-04,4.28,\n2023-12-05,4.18,\n2023-12-06,4.12,\n2023-12-07,4.14,\n2023-12-08,4.23,\n2023-12-11,4.23",
  "description": "10 year daily interest rates, sourced from https://fred.stlouisfed.org/series/DGS10",
  "table_name": "ten_year_us_interest_rates",
  "is_private": false
}'

```

200

400

401

500

Copy

Ask AI

```
{
  "success": true,
  "table_name": "ten_year_us_interest_rates"
}
```

Consider using the [`/create`](./create) and [`/insert`](./insert) endpoints if you want more flexibility, performance, and the ability to append.

You can also upload CSV through the [Dune UI](https://dune.com/) by pressing the “create” dropdown.

For working with uploads, keep in mind that:

* File has to be < 200 MB
* Column names in the table can’t start with a special character or digits.
* Private uploads require a Premium subscription.
* If you upload to an existing table name, it will delete the old data and overwite it with your new data. Appends are only supported for the `/create`, `/insert` endpoints.
* To delete an upload table, you must go to `user settings (dune.com) -> data -> delete`.

If you have larger datasets you want to upload, please [contact us here](https://docs.google.com/forms/d/e/1FAIpQLSekx61WzIh-MII18zRj1G98aJeLM7U0VEBqaa6pVk_DQ7lq6Q/viewform)

curl

Python SDK

TS SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/upload/csv \
  --header 'Content-Type: application/json' \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --data '{
  "data": "DATE,DGS10,\n2023-12-04,4.28,\n2023-12-05,4.18,\n2023-12-06,4.12,\n2023-12-07,4.14,\n2023-12-08,4.23,\n2023-12-11,4.23",
  "description": "10 year daily interest rates, sourced from https://fred.stlouisfed.org/series/DGS10",
  "table_name": "ten_year_us_interest_rates",
  "is_private": false
}'

```

### [​](#upload-via-google-sheet) Upload via google sheet

To automate the upload of a Google Sheet’s contents to Dune via API, use the following Google Apps Script:

Copy

Ask AI

```
function uploadToDune() {
  var apiKey = "YOUR_DUNE_API_KEY"; // Replace with your actual Dune API key, keep the quotes
  var tableName = "example_table"; // Update with your desired table name
  var description = "Example table description";

  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var range = sheet.getDataRange();
  var values = range.getValues();

  // Convert data to CSV format
  var csvData = "";
  for (var i = 0; i < values.length; i++) {
    csvData += values[i].join(",") + "\n";
  }

  var payload = {
    data: csvData.trim(),
    description: description,
    table_name: tableName,
    is_private: false
  };

  var options = {
    method: "post",
    contentType: "application/json",
    headers: {
      "X-DUNE-API-KEY": apiKey
    },
    payload: JSON.stringify(payload)
  };

  var response = UrlFetchApp.fetch("https://api.dune.com/api/v1/table/upload/csv", options);
  Logger.log(response.getContentText());
}

```

Steps to Use:

1. Open your Google Sheet
2. Navigate to Extensions → Apps Script
3. Replace the script with the code above
4. Save and run uploadToDune
5. (Optional) For easier execution, you can assign this script to a button in your Google Sheet:
   * Click “Insert” in the Google Sheets menu
   * Select “Drawing”
   * Create a button shape and add text like “Upload to Dune”
   * Click “Save and Close”
   * Right-click the button and select “Assign script”
   * Enter “uploadToDune” as the function name
6. Clicking the button will now upload your active sheet’s data to Dune!

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

Alternative to using the X-Dune-Api-Key header

#### Body

\*/\*

payload

The body is of type `object`.

#### Response

200

200400401500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/tables/endpoint/upload)

[Insert Data](/api-reference/tables/endpoint/insert)[Clear Data](/api-reference/tables/endpoint/clear)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.