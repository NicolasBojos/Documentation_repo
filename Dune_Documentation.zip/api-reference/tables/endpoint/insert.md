[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Tables

Insert Data

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

  + [Overview](/api-reference/tables/endpoint/overview)
  + [POST

    Create Table](/api-reference/tables/endpoint/create)
  + [POST

    Insert Data](/api-reference/tables/endpoint/insert)
  + [POST

    Upload CSV](/api-reference/tables/endpoint/upload)
  + [POST

    Clear Data](/api-reference/tables/endpoint/clear)
  + [DEL

    Delete Table](/api-reference/tables/endpoint/delete)

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

curl

Python SDK

TS SDK

Python

Javascript

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/my_user/interest_rates/insert \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --header 'Content-Type: text/csv' \
  --upload-file interest_rates.csv

```

200

400

401

404

500

Copy

Ask AI

```
{
  "rows_written": 9000,
  "bytes_written": 90
}
```

Tables

# Insert Data

Insert the data in a file into a table.

POST

/

v1

/

table

/

{namespace}

/

{table\_name}

/

insert

Try it

curl

Python SDK

TS SDK

Python

Javascript

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/my_user/interest_rates/insert \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --header 'Content-Type: text/csv' \
  --upload-file interest_rates.csv

```

200

400

401

404

500

Copy

Ask AI

```
{
  "rows_written": 9000,
  "bytes_written": 90
}
```

To be able to insert into a table, it must have been created with the [/create endpoint](./create).

* The data in the files must conform to the schema, and must use the same column names as the schema.
* One successful `/insert` request consumes 1 credits.
* The maximum request size is 1.2GB

## [​](#consistency) Consistency

A request to this endpoint has two possible outcomes: Either all of the data in the request was inserted, or none of it was.
It’s not possible for parts of the request data to be inserted, while the rest is not inserted.
In other words, please use and trust the status codes that the endpoint returns.
A status code of 200 means that the data in the request was successfully inserted.
If you get any other status code, you can safely retry your request after addressing the issue that the error message indicated.

## [​](#concurrent-requests) Concurrent requests

A limited number of concurrent insertion requests per table is supported. However, there will be a slight performance penalty as we serialize the writes behind the scenes to ensure data integrity. Larger number of concurrent requests per table may result in an increased number of failures. Therefore, we recommend managing your requests within a 5-10 threshold to maintain optimal performance.

## [​](#supported-filetypes) Supported filetypes

### [​](#csv-files-content-type%3A-text%2Fcsv) CSV files (`Content-Type: text/csv`)

CSV files must use a comma as delimiter, and the column names in the header must match the column names of the table.

### [​](#json-files-content-type%3A-application%2Fx-ndjson) JSON files (`Content-Type: application/x-ndjson`)

These are files where each line is a complete JSON object which creates one table row.
Each line must have keys that match the column names of the table.

## [​](#data-types) Data types

DuneSQL supports a variety of types which are not natively supported in many data exchange formats. Here we provide guidance on how to work with such types.

### [​](#varbinary-values) Varbinary values

When uploading varbinary data using JSON or CSV formats, you need to convert the binary data into a textual representation. Reason being, JSON or CSV don’t natively support binary values. There are many ways to transform binary data to a textual representation. We support **hexadecimal** and **base64** encodings.

#### [​](#base64) base64

Base64 is a binary-to-text encoding scheme that transforms binary data into a sequence of characters. All characters are taken from a set of 64 characters.
Example: `{"varbinary_column":"SGVsbG8gd29ybGQK"}`

#### [​](#hexadecimal) hexadecimal

In the hexadecimal representation input data should contain an even number of characters in the range `[0-9a-fA-F]` always prefixed with `0x`.
Example: `{"varbinary_column":"0x92b7d1031988c7af"}`

curl

Python SDK

TS SDK

Python

Javascript

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/my_user/interest_rates/insert \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --header 'Content-Type: text/csv' \
  --upload-file interest_rates.csv

```

#### Authorizations

[​](#authorization-x-dune-api-key)

x-dune-api-key

string

header

required

The API key of your team or user.

#### Path Parameters

[​](#parameter-namespace)

namespace

string

required

The namespace of the table to insert into (e.g. `my_user`).

[​](#parameter-table-name)

table\_name

string

required

The name of the table to insert into (e.g. `interest_rates`).

#### Body

text/csv · fileapplication/x-ndjson

The file to insert into the table.

The body is of type `file`.

#### Response

200

200400401404500

application/json

Successful operation

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/tables/endpoint/insert)

[Create Table](/api-reference/tables/endpoint/create)[Upload CSV](/api-reference/tables/endpoint/upload)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.