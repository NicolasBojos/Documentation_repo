[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Tables

Create Table

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

  + [Overview](/api-reference/tables/endpoint/overview)
  + [POST

    Create Table](/api-reference/tables/endpoint/create)
  + [POST

    Insert Data](/api-reference/tables/endpoint/insert)
  + [POST

    Upload CSV](/api-reference/tables/endpoint/upload)
  + [POST

    Clear Data](/api-reference/tables/endpoint/clear)
  + [DEL

    Delete Table](/api-reference/tables/endpoint/delete)

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

curl

Python SDK

TS SDK

Python

Javascript

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/create \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --header 'Content-Type: application/json' \
  --data '{
  "namespace":"my_user",
  "table_name":"interest_rates",
  "description": "10 year daily interest rates, sourced from https://fred.stlouisfed.org/series/DGS10",
  "is_private": false,
  "schema": [{"name": "date", "type": "timestamp"}, {"name": "dgs10", "type": "double",  "nullable": true}]
}'

```

200

201

400

401

409

500

Copy

Ask AI

```
{
  "namespace": "my_user",
  "table_name": "my_data",
  "full_name": "dune.my_user.my_data",
  "example_query": "select * from dune.my_user.my_data",
  "already_existed": false,
  "message": "Table created successfully"
}
```

Tables

# Create Table

Create a new Dune table with the specified name and namespace.

POST

/

v1

/

table

/

create

Try it

curl

Python SDK

TS SDK

Python

Javascript

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/create \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --header 'Content-Type: application/json' \
  --data '{
  "namespace":"my_user",
  "table_name":"interest_rates",
  "description": "10 year daily interest rates, sourced from https://fred.stlouisfed.org/series/DGS10",
  "is_private": false,
  "schema": [{"name": "date", "type": "timestamp"}, {"name": "dgs10", "type": "double",  "nullable": true}]
}'

```

200

201

400

401

409

500

Copy

Ask AI

```
{
  "namespace": "my_user",
  "table_name": "my_data",
  "full_name": "dune.my_user.my_data",
  "example_query": "select * from dune.my_user.my_data",
  "already_existed": false,
  "message": "Table created successfully"
}
```

The resulting table will be empty, and can be inserted into with the [/insert endpoint](./insert).

* If a table already exists with the same name, the request will fail.
* Column names in the table can’t start with a special character or a digit.
* Each successful table creation consumes 10 credits.
* To delete a table, you can go to `user settings (dune.com) -> data -> delete` or use the [/delete endpoint](./delete).

## [​](#schema) Schema

You need to define the schema of your data by providing `schema` array of columns in the request. Each column has three parameters:
**name**: the name of the field
**type**: the data type of the field

Dune supports [ISO 8601](https://www.iso.org/iso-8601-date-and-time-format.html) timestamp format

**nullable**: if the column is nullable (true/false, true by default)

curl

Python SDK

TS SDK

Python

Javascript

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/table/create \
  --header 'X-DUNE-API-KEY: <x-dune-api-key>' \
  --header 'Content-Type: application/json' \
  --data '{
  "namespace":"my_user",
  "table_name":"interest_rates",
  "description": "10 year daily interest rates, sourced from https://fred.stlouisfed.org/series/DGS10",
  "is_private": false,
  "schema": [{"name": "date", "type": "timestamp"}, {"name": "dgs10", "type": "double",  "nullable": true}]
}'

```

#### Authorizations

[​](#authorization-x-dune-api-key)

x-dune-api-key

string

header

required

The API key of your team or user.

#### Body

application/json

Create a new Dune Table for uploads

The body is of type `object`.

#### Response

200

200201400401409500

application/json

The Dune table `namespace.table_name` already existed with the same data as the request.

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/tables/endpoint/create)

[Overview](/api-reference/tables/endpoint/overview)[Insert Data](/api-reference/tables/endpoint/insert)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.