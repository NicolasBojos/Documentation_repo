[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

API Quickstart

Tables Management

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart

  + [Execution & Results](/api-reference/quickstart/results-eg)
  + [Query Management](/api-reference/quickstart/queries-eg)
  + [Tables Management](/api-reference/quickstart/tables-eg)
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

On this page

* [Prerequisites](#prerequisites)
* [Upload the CSV](#upload-the-csv)

API Quickstart

# Tables Management

In this quickstart, we will walk through how to upload a CSV file to Dune via Python.

### [​](#prerequisites) Prerequisites

* Python environment set up (check out [Anaconda Navigator](https://docs.continuum.io/free/navigator/) if you want somewhere to start.)
* Have a Dune API key (to obtain one [follow the steps here](../overview/authentication#generate-an-api-key))

Save your Dune API key in a .env file.

Copy

Ask AI

```
DUNE_API_KEY=<paste your API key here>

```

### [​](#upload-the-csv) Upload the CSV

Follow below steps to upload your CSV. Please make sure to modify paths to your .env file and to your CSV file.

Copy

Ask AI

```
import dotenv, os
from dune_client.client import DuneClient

# change the current working directory where .env file lives
os.chdir("/Users/abc/project")
# load .env file
dotenv.load_dotenv(".env")
# setup Dune Python client
dune = DuneClient.from_env()

# define path to your CSV file 
csv_file_path = '<CSV_FILE_PATH>'

with open(csv_file_path) as open_file:
    data = open_file.read()

    table = dune.upload_csv(
        data=str(data),
        description="Data about 80 cereals, sourced from https://www.kaggle.com/datasets/crawford/80-cereals",
        table_name="cereal_table", # define your table name here
        is_private=False
    )

```

Once the upload is successful, you will see the data show up under [Your Data](https://dune.com/queries?category=uploaded_data) in the Data Explorer.
You can query your uploaded table under the name `dune.<team or user handle>.dataset_<table name defined>`. For example, here I defined the table name to be “cereal\_table” and my team name is “dune”, so to access the uploaded table we will do `select * from dune.dune.dataset_cereal_table`
For more information on upload endpoint, please [visit this page](../tables/endpoint/upload).

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/quickstart/tables-eg)

[Query Management](/api-reference/quickstart/queries-eg)[Authentication](/api-reference/overview/authentication)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.