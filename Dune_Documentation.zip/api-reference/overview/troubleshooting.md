[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Troubleshooting Errors

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

On this page

* [Invalid API key](#invalid-api-key)
* [Permission error](#permission-error)
* [Credit limit error](#credit-limit-error)

# Troubleshooting Errors

Dune uses conventional HTTP response codes to indicate the success or failure of an API request. In general: Codes in the `2xx` range indicate success. Codes in the `4xx` range indicate an error that failed given the information provided. Codes in the `5xx` range indicate an error with Dune’s servers.

| HTTP Status Code | Status | Description |
| --- | --- | --- |
| 200 | OK | Everything worked as expected. |
| 400 | Bad Request | The request was unacceptable, often due to missing a required parameter. |
| 401 | Unauthorized | No valid API key provided. |
| 402 | Payment Required | This request would exceed your configured limits per billing cycle. |
| 403 | Forbidden | The API key doesn’t have permissions to perform the request. |
| 404 | Not Found | The requested resource doesn’t exist. |
| 409 | Conflict | The request conflicts with another request. |
| 429 | Too Many Requests | Too many requests hit the API too quickly (rate limited). |
| 500 | Server Errors | Generic internal server error. |

For specific error code information, please refer to each of the endpoint itself. Here we list some common errors and suggest possible solution:

#### [​](#invalid-api-key) Invalid API key

Copy

Ask AI

```
{
  "error": "invalid API Key"
}

```

You did not input a valid API key. You can go generate a new key and make sure you save it in a safe place and paste the key over.

#### [​](#permission-error) Permission error

Copy

Ask AI

```
{
"error": "not found: Query not found or private"
}

```

When you perform an action to a private query your API key doesn’t have access to, you will get this error. If you indeed own this query, please check the context of the API key and the query owner are the same.

#### [​](#credit-limit-error) Credit limit error

Copy

Ask AI

```
{
  "error": "This api request would exceed your configured limits per billing cycle. Please visit your settings on dune.com and adjust your limits to continue usage."
}

```

You are trying to make a request but don’t have enough credits (configured) on your account. If you’d like to incur overage, head over to settings -> subscription and adjust the limit you have set within “limit extra credits” toggle.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/overview/troubleshooting)

[Rate Limits](/api-reference/overview/rate-limits)[Billing](/api-reference/overview/billing)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.