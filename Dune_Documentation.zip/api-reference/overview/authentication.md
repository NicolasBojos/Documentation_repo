[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Authentication

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

On this page

* [Generate an API key](#generate-an-api-key)
* [Permissions](#permissions)
* [Context of a key](#context-of-a-key)
* [Authentication & making API calls](#authentication-%26-making-api-calls)

# Authentication

The Dune API relies on API keys for authentication. Your API key grants access and determines billing details for private queries, so safeguard it diligently!

## [​](#generate-an-api-key) Generate an API key

In order to generate a new API key, go to settings -> API -> create new API key.

* Dune has two types of account: `user` account and `team` account. A team can have many users. A user can join many teams.
* Each user or team account has its own context. Queries created under a team account can only be managed within the team account context.
* An API key belongs to a specific context, and is either associated with a user account or a team account.
* **New**: Scoped API keys can now be created to allow access only to specific endpoints. See the section below on “Scope of a Key.”

* Create key for user account
* Create key for team account

  

Never share your secret API keys in public repositories or other accessible areas.

## [​](#permissions) Permissions

When creating an API key, you can now choose between two permission levels to control which endpoints the key can access:

* All endpoints: This option grants full access to all API endpoints, including Developer APIs, executions, results, queries, tables, and materialized views. This is the default setting.
* Only Developer APIs: Limits access to only [Dune’s real-time APIs](/echo), such as the Tokens API and Balances API.

You can select the appropriate level of access when creating a new API key in the settings under API -> Create API key.

## [​](#context-of-a-key) Context of a key

As mentioned above, a team API key only has access to team account resources and not user account resources. This can be especially relevant when you use Query endpoints.

## [​](#authentication-%26-making-api-calls) Authentication & making API calls

You can authenticate either with the API header or with query parameter to start making API calls. We illustrate below with [execute query endpoint](../executions/endpoint/execute-query) as an example.

* Header Authentication
* Query Parameter Authentication

To authenticate via the API header, include an `x-dune-api-key` property in your request header.

* cURL (bash)
* Python
* JavaScript
* Go
* PHP
* Java

Copy

Ask AI

```
curl -X POST -H x-dune-api-key:{{api_key}} "https://api.dune.com/api/v1/query/{{query_id}}/execute"

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/overview/authentication)

[Tables Management](/api-reference/quickstart/tables-eg)[Client SDKs](/api-reference/overview/sdks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.