[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Billing

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

# Billing

Pricing for API is charged along two dimensions. All details can be found at [dune.com/pricing](https://dune.com/pricing)

If your execution fails, then no credits are charged. If you execute a query but never pull the results, you are only charged for the execution.

| Dimension | Charge |
| --- | --- |
| Executions | 10 credits per medium query engine executions   20 credits per large query engine executions |
| Datapoints (Results) | 1 credit per 1,000 datapoints on Free   1 credit per 5,000 datapoints on Plus   1 credit per 25,000 datapoints on Premium |
| Storage | 1MB on Free   15GB on Plus   50GB on Premium |
| Queries Endpoint | Available on Plus and Premium |
| Webhooks (Alerts) | 1 on Free   5 on Plus   50 on Premium |

A datapoint applies to query results after the query is run, and can in most cases be thought of `rows * columns` with an additional limit of 100 avg bytes per cell in a set of results. This can be expressed as:
Credits=Datapoints1000=max⁡(rows∗columns,⌈totalbytes100⌉)1000Credits = \frac{Datapoints}{1000} = \frac{\max(\text{rows} \* \text{columns}, \lceil \frac{\text{totalbytes}}{100} \rceil)}{1000}Credits=1000Datapoints​=1000max(rows∗columns,⌈100totalbytes​⌉)​
**Byte-Based Calculation Details**
When calculating datapoints based on total bytes, cells that exceed 100 bytes will “spill over” into additional cells. Here’s how this works:
**Example Table:**

Copy

Ask AI

```
+-----+-----+-----+
| A1  | B1  | C1  |
+-----+-----+-----+
| A2  | B2  | C2  |
+-----+-----+-----+
| A3  | B3  | C3  |
+-----+-----+-----+

```

**Spillover Calculation:** If one cell contains 175 bytes, that cell effectively counts as 2 cells in the datapoint calculation:

* First 100 bytes = 1 cell
* Remaining 75 bytes = 1 additional cell

**Example breakdown:**

* 8 cells of 100 bytes each = 8 cells
* 1 cell of 175 bytes = 2 cells (100 + 75)
* Total: 10 cells

**API Usage Billing**
Any API usage billing will be based on what account the API key is associated with. If you use your team API key to call a public query belonging to yourself, the billing will be associated to the team (and vice versa).

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/overview/billing)

[Troubleshooting Errors](/api-reference/overview/troubleshooting)[FAQ](/api-reference/overview/faq)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.