[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Rate Limits

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

# Rate Limits

**Rate Limits**
Our rate limits are implemented in three ways: IP, low vs. high limit endpoints and [subscription plan](https://dune.com/pricing).

* Low limit endpoints *(write-heavy operations)*
  + [create query](../queries/endpoint/create)
  + [update query](../queries/endpoint/update)
  + [private query](../queries/endpoint/private)
  + [unprivate query](../queries/endpoint/unprivate)
  + [archive query](../queries/endpoint/archive)
  + [unarchive query](../queries/endpoint/unarchive)
  + [execute query](../executions/endpoint/execute-query)
  + [create table](../tables/endpoint/create)
  + [insert into table](../tables/endpoint/insert)
  + [upload CSV](../tables/endpoint/upload)
  + [delete table](../tables/endpoint/delete)
* High limit endpoints *(read-heavy operations)*
  + [read query](../queries/endpoint/read)
  + [get execution result](../executions/endpoint/get-execution-result)
  + [get execution result CSV](../executions/endpoint/get-execution-result-csv)
  + [get execution status](../executions/endpoint/get-execution-status)
  + [cancel execution](../executions/endpoint/cancel-execution)

| Dimension |  | Limit |
| --- | --- | --- |
| Per IP |  | 1000 requests per second (rps) |
| Free | Low limit | 15 requests per minute (rpm) |
| Free | High limit | 40 rpm |
| Plus | Low limit | 70 rpm |
| Plus | High limit | 200 rpm |
| Premium | Low limit | 350 rpm |
| Premium | High limit | 1000 rpm |
| Enterprise |  | Please contact us! |

Rate limits for different dimensions are separate but can be utilized independently.
For example, on the Free plan, you have a low limit of 15 requests per minute and a high limit of 40 requests per minute. You can use both types of requests in the same minute, effectively having a combined limit of 55.

**Data Return Limit**
Dune internally has a maximum query result size limit (which currently is 8GB, but subject to increase in the future). If your query yields more than 8GB of data, the result will be truncated in storage. In such cases, pulling the result data (using pagination) but without specifying `allow_partial_results` set to true will trigger an error message: “error”: “Partial Result, please request with ‘allows\_partial\_results=true’”. If you wish to retrieve partial results, you can pass the parameter `allow_partial_results=true`. But please make sure you indeed want to fetch the truncated result.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/overview/rate-limits)

[Sampling](/api-reference/executions/sampling)[Troubleshooting Errors](/api-reference/overview/troubleshooting)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.