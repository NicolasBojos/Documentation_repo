[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Webhooks

Create Webhook

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

  + [Create Webhook](/api-reference/webhooks/webhook)

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

Webhooks

# Create Webhook

How to receive data into webhooks from Dune queries

You can send Dune data to a webhook by going to any query your own, and pressing the “schedule” button to the left of “Run” in the editor. You’ll the popup below, where you can paste in a webhook url and receive data on a scheduled interval.

A good use case for this is sending data to a Slack webhook, which you can [learn to do here](https://api.slack.com/messaging/webhooks).

![](https://mintlify.s3.us-west-1.amazonaws.com/dune/api-reference/webhooks/webhook.png)

You can quickly test the output with a webhook generator [like this one](https://webhook.site/#!/).
Here is an example schema sent to the webhook from this [Jupiter swap fees query](https://dune.com/queries/3106864):

Copy

Ask AI

```
{
  "message": "Query Jupiter Fees was submitted for execution at Wed, 17 Jan 2024 04:18:49 GMT by your query schedule and it was successfully executed with a non-empty result.\nYou can check its latest result here: https://dune.com/queries/3106864?utm_source=webhook&utm_campaign=alerts",
  "query_result": {
    "execution_id": "01HMAT9AB8JRV1NQR1W6NMYQK7",
    "query_id": 3106864,
    "state": "QUERY_STATE_COMPLETED",
    "submitted_at": "2024-01-17T04:18:49Z",
    "expires_at": "2024-04-16T04:20:57Z",
    "execution_started_at": "2024-01-17T04:18:49Z",
    "execution_ended_at": "2024-01-17T04:20:57Z",
    "result": {
      "data_uri": "https://api.dune.com/api/v1/execution/01HMAT9AB8JRV1NQR1W6NMYQK7/results",
      "metadata": {
        "column_names": [
          "week",
          "fee_usd"
        ],
        "result_set_bytes": 1164,
        "total_row_count": 25,
        "datapoint_count": 50,
        "pending_time_millis": 40,
        "execution_time_millis": 127845
      }
    }
  },
  "visualizations": [
    {
      "title": "Chart",
      "image_url": "https://prod-dune-media.s3.eu-west-1.amazonaws.com/screenshots/3106864/01HMAT9AB8JRV1NQR1W6NMYQK7/5222108.png"
    }
  ]
}

```

You’ll need to GET query the `data_uri` with your api key to get the results data. This is the same as passing the `execution_id` into [get execution result](/api-reference/executions/endpoint/get-execution-result).

In the case the query errors out on its scheduled run, you won’t receive anything to the webhook.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/webhooks/webhook)

[Refresh Materialized View](/api-reference/materialized-views/refresh)[Overview](/api-reference/tables/endpoint/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.