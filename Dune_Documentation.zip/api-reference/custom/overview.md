[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Custom Endpoints

Custom Endpoints

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

On this page

* [How to Create a Custom Endpoint](#how-to-create-a-custom-endpoint)
* [Credits Consumption](#credits-consumption)

Custom Endpoints

# Custom Endpoints

Create custom API endpoints from Dune queries

Custom Endpoints allow developers to create and manage API endpoints from Dune queries. By selecting a query and scheduling it to run at a specified frequency, developers can call a custom URL to consume data. This flexible alternative to [Preset Endpoints](.././overview/introduction#preset-endpoints) provides greater customization without the complexities of [SQL Endpoints](.././overview/introduction#sql-endpoints).

## [​](#how-to-create-a-custom-endpoint) How to Create a Custom Endpoint

  

* The custom endpoint shares the same refresh schedule as the underlying query. Changing the query schedule will also change the endpoint schedule, and vice versa. See [scheduling queries](../../web-app/query-editor/query-scheduler) for more info.
* All your custom endpoints can be found in `Library` > `Custom endpoints`.

You can only create endpoints from queries you own. Creating endpoints from others’ queries can lead to changes in the logic without notification, breaking your data consumption pipeline.

* Leverage [Filtering](../executions/filtering), [Sorting](../executions/sorting), and [Sampling](../executions/sampling) to flexibly grab query results.
* Use [Pagination](../executions/pagination) to handle large results.

### [​](#credits-consumption) Credits Consumption

Custom endpoints consume credits in two ways:

1. **Refresh schedule:** Credits are consumed based on the engine size (e.g., 10 credits per refresh for medium, 20 credits for large). The monthly credit consumption is shown during endpoint creation.
2. **Data fetch:** Credits are charged based on the datapoints read from the endpoint. Utilize result filtering to consume fewer credits by reading fewer datapoints.

For more information on credits, visit [this page](../../learning/how-tos/credit-system-on-dune).

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/custom/overview)

[FAQ](/api-reference/overview/faq)[Overview](/api-reference/executions/execution-object)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.