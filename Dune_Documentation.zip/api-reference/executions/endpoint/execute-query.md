[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Executions and Results

Execute Query

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results

  + [Overview](/api-reference/executions/execution-object)
  + [POST

    Execute Query](/api-reference/executions/endpoint/execute-query)
  + [POST

    Cancel Execution](/api-reference/executions/endpoint/cancel-execution)
  + [GET

    Get Execution Status](/api-reference/executions/endpoint/get-execution-status)
  + [GET

    Get Execution Result](/api-reference/executions/endpoint/get-execution-result)
  + [GET

    Get Execution Result in CSV](/api-reference/executions/endpoint/get-execution-result-csv)
  + [GET

    Get Latest Query Result](/api-reference/executions/endpoint/get-query-result)
  + [GET

    Get Latest Query Result in CSV](/api-reference/executions/endpoint/get-query-result-csv)
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

cURL

Python SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```
curl -X POST "https://api.dune.com/api/v1/query/{{query_id}}/execute"   \
  -H "X-Dune-API-Key: {{api_key}}"                                       \
  -H "Content-Type: application/json"                                   \
  -d '{"query_parameters": {"param1":24}, "performance": "large"}'

```

200

400

401

402

403

404

500

Copy

Ask AI

```
{
  "execution_id": "01HKZJ2683PHF9Q9PHHQ8FW4Q1",
  "state": "QUERY_STATE_PENDING"
}
```

Executions and Results

# Execute Query

Execute, or run a query for the specified query ID

POST

/

v1

/

query

/

{query\_id}

/

execute

Try it

cURL

Python SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```
curl -X POST "https://api.dune.com/api/v1/query/{{query_id}}/execute"   \
  -H "X-Dune-API-Key: {{api_key}}"                                       \
  -H "Content-Type: application/json"                                   \
  -d '{"query_parameters": {"param1":24}, "performance": "large"}'

```

200

400

401

402

403

404

500

Copy

Ask AI

```
{
  "execution_id": "01HKZJ2683PHF9Q9PHHQ8FW4Q1",
  "state": "QUERY_STATE_PENDING"
}
```

Execute query and get result in one call

If you are using the [Python SDK](https://github.com/duneanalytics/dune-client/tree/d2195b2a9577e2dcae5d2600cb3eddce20987f38), you can directly executes and fetches result in one function call, like below:

Use `run_query` to get result in JSON,
`run_query_csv` to get result in CSV format,
and `run_query_dataframe` to get result in Pandas dataframe

Python SDK

Copy

Ask AI

```

import dotenv, os, json
from dune_client.types import QueryParameter
from dune_client.client import DuneClient
from dune_client.query import QueryBase

# change the current working directory where .env file lives
os.chdir("/Users/abc/local-Workspace/python-notebook-examples")
# load .env file
dotenv.load_dotenv(".env")
# setup Dune Python client
dune = DuneClient.from_env()

query = QueryBase(
    name="Sample Query",
    query_id=1215383,
)

result = dune.run_query(
    query = query,
    performance = 'large' # optionally define which tier to run the execution on (default is "medium")
)

# go over the results returned
for row in result.result.rows: 
    print (row) # as an example we print the rows

```

If the query has parameters and you don’t add them in your API call, it will just run with the default params. You may add query parameters as part of the POST params data.
You can choose to include a `performance` parameter, by default it will use the “medium” performance tier which consumes 10 credits. “large” will use 20 credits and are faster.
Returns an execution\_id associated with the triggered query execution and the state of the execution.

cURL

Python SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```
curl -X POST "https://api.dune.com/api/v1/query/{{query_id}}/execute"   \
  -H "X-Dune-API-Key: {{api_key}}"                                       \
  -H "Content-Type: application/json"                                   \
  -d '{"query_parameters": {"param1":24}, "performance": "large"}'

```

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Path Parameters

[​](#parameter-query-id)

query\_id

integer

required

Unique identifier of the query

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

Alternative to using the X-Dune-Api-Key header

[​](#parameter-performance)

performance

enum<string>

The performance engine tier the execution will be run on. Can be either `medium` or `large`. Medium consumes 10 credits, and large consumes 20 credits, per run. Default is `medium`.

Available options:

`medium`,

`large`

[​](#parameter-query-parameters)

query\_parameters

string

SQL Query parameters in json key-value pairs. Each parameter is to be provided in key-value pairs. This enables you to execute a parameterized query with the provided values for your parameter keys. Partial submission of parameters is allowed. For example, if the query expects three parameters and you only pass in two, the third one will automatically use its default value as defined in the Query Parameter Editor page.

#### Response

200

200400401402403404500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/executions/endpoint/execute-query)

[Overview](/api-reference/executions/execution-object)[Cancel Execution](/api-reference/executions/endpoint/cancel-execution)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.