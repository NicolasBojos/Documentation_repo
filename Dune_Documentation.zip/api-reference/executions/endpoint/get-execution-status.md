[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Executions and Results

Get Execution Status

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results

  + [Overview](/api-reference/executions/execution-object)
  + [POST

    Execute Query](/api-reference/executions/endpoint/execute-query)
  + [POST

    Cancel Execution](/api-reference/executions/endpoint/cancel-execution)
  + [GET

    Get Execution Status](/api-reference/executions/endpoint/get-execution-status)
  + [GET

    Get Execution Result](/api-reference/executions/endpoint/get-execution-result)
  + [GET

    Get Execution Result in CSV](/api-reference/executions/endpoint/get-execution-result-csv)
  + [GET

    Get Latest Query Result](/api-reference/executions/endpoint/get-query-result)
  + [GET

    Get Latest Query Result in CSV](/api-reference/executions/endpoint/get-query-result-csv)
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

cURL

Python SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```

curl -X GET "https://api.dune.com/api/v1/execution/{{execution_id}}/status" -H x-dune-api-key:{{api_key}}


```

200

400

401

404

500

Copy

Ask AI

```
{
  "cancelled_at": "2024-12-20T11:04:18.724658237Z",
  "execution_ended_at": "2024-12-20T11:04:18.724658237Z",
  "execution_id": "01HKZJ2683PHF9Q9PHHQ8FW4Q1",
  "execution_started_at": "2024-12-20T11:04:18.724658237Z",
  "expires_at": "2024-12-20T11:04:18.724658237Z",
  "is_execution_finished": true,
  "max_inflight_interactive_executions": 3,
  "max_inflight_interactive_reached": 5,
  "query_id": 1234,
  "queue_position": 1,
  "result_metadata": {
    "column_names": [
      "Rank",
      "Project",
      "Volume"
    ],
    "column_types": [
      "double",
      "varchar",
      "bigint"
    ],
    "datapoint_count": 1000,
    "execution_time_millis": 1000,
    "pending_time_millis": 1000,
    "result_set_bytes": 1000,
    "row_count": 10,
    "total_result_set_bytes": 10000,
    "total_row_count": 1000
  },
  "state": "QUERY_STATE_COMPLETED",
  "submitted_at": "2024-12-20T11:04:18.724658237Z"
}
```

Executions and Results

# Get Execution Status

Check the status of an execution request

GET

/

v1

/

execution

/

{execution\_id}

/

status

Try it

cURL

Python SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```

curl -X GET "https://api.dune.com/api/v1/execution/{{execution_id}}/status" -H x-dune-api-key:{{api_key}}


```

200

400

401

404

500

Copy

Ask AI

```
{
  "cancelled_at": "2024-12-20T11:04:18.724658237Z",
  "execution_ended_at": "2024-12-20T11:04:18.724658237Z",
  "execution_id": "01HKZJ2683PHF9Q9PHHQ8FW4Q1",
  "execution_started_at": "2024-12-20T11:04:18.724658237Z",
  "expires_at": "2024-12-20T11:04:18.724658237Z",
  "is_execution_finished": true,
  "max_inflight_interactive_executions": 3,
  "max_inflight_interactive_reached": 5,
  "query_id": 1234,
  "queue_position": 1,
  "result_metadata": {
    "column_names": [
      "Rank",
      "Project",
      "Volume"
    ],
    "column_types": [
      "double",
      "varchar",
      "bigint"
    ],
    "datapoint_count": 1000,
    "execution_time_millis": 1000,
    "pending_time_millis": 1000,
    "result_set_bytes": 1000,
    "row_count": 10,
    "total_result_set_bytes": 10000,
    "total_row_count": 1000
  },
  "state": "QUERY_STATE_COMPLETED",
  "submitted_at": "2024-12-20T11:04:18.724658237Z"
}
```

You must pass the `execution_id` obtained from making an [execute query](/api-reference/executions/endpoint/execute-query) POST request.
Returns the status of a query execution along with relevant metadata of the results if the execution is completed.

## [​](#execution-states) Execution States

Once an execution is triggered, it can be in one of the following states:

* `QUERY_STATE_PENDING`: The query execution is waiting for an execution slot.
* `QUERY_STATE_EXECUTING`: The query is currently executing.
* `QUERY_STATE_FAILED`: The query execution failed. This is a terminal state.
* `QUERY_STATE_COMPLETED`: The query execution completed successfully. You can retrieve the query result for this execution\_id.
* `QUERY_STATE_CANCELED`: The query execution was canceled by the user.
* `QUERY_STATE_EXPIRED`: The query execution expired, and the result is no longer available.
* `QUERY_STATE_COMPLETED_PARTIAL`: The query execution was successful, but the result was truncated because it was too large. To receive the truncated result, set the `allow_partial_results` flag to `true` in the API request to fetch result.

cURL

Python SDK

Python

Javascript

Go

PHP

Java

Copy

Ask AI

```

curl -X GET "https://api.dune.com/api/v1/execution/{{execution_id}}/status" -H x-dune-api-key:{{api_key}}


```

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Path Parameters

[​](#parameter-execution-id)

execution\_id

string

required

Execution ID

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

Alternative to using the X-Dune-Api-Key header

#### Response

200

200400401404500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/executions/endpoint/get-execution-status)

[Cancel Execution](/api-reference/executions/endpoint/cancel-execution)[Get Execution Result](/api-reference/executions/endpoint/get-execution-result)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.