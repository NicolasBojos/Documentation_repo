[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Farcaster

Farcaster Memecoins

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster

  + [Dune Farcaster Endpoints](/api-reference/farcaster/introduction)
  + [GET

    Farcaster Channels](/api-reference/farcaster/endpoint/farcaster_channels)
  + [GET

    Farcaster Memecoins](/api-reference/farcaster/endpoint/farcaster_memecoins)
  + [GET

    Farcaster Users](/api-reference/farcaster/endpoint/farcaster_users)
* Markets
* Projects

Farcaster Memecoins

cURL

Copy

Ask AI

```
curl --request GET \
  --url https://api.dune.com/api/v1/farcaster/trends/memecoins \
  --header 'X-Dune-Api-Key: <x-dune-api-key>'
```

200

400

401

402

403

404

500

Copy

Ask AI

```
{
  "cancelled_at": "2024-12-20T11:04:18.724658237Z",
  "execution_ended_at": "2024-12-20T11:04:18.724658237Z",
  "execution_id": "01HKZJ2683PHF9Q9PHHQ8FW4Q1",
  "execution_started_at": "2024-12-20T11:04:18.724658237Z",
  "expires_at": "2024-12-20T11:04:18.724658237Z",
  "is_execution_finished": true,
  "next_offset": 100,
  "next_uri": "https://api.dune.com/api/v1/execution/01HKZJ2683PHF9Q9PHHQ8FW4Q1/results?offset=100&limit=100",
  "query_id": 1234,
  "result": {
    "metadata": {
      "column_names": [
        "Rank",
        "Project",
        "Volume"
      ],
      "column_types": [
        "double",
        "varchar",
        "bigint"
      ],
      "datapoint_count": 1000,
      "execution_time_millis": 1000,
      "pending_time_millis": 1000,
      "result_set_bytes": 1000,
      "row_count": 10,
      "total_result_set_bytes": 10000,
      "total_row_count": 1000
    },
    "rows": [
      {}
    ]
  },
  "state": "QUERY_STATE_COMPLETED",
  "submitted_at": "2024-12-20T11:04:18.724658237Z"
}
```

Farcaster

# Farcaster Memecoins

Get trending farcaster memecoins that have been casted

GET

/

v1

/

farcaster

/

trends

/

memecoins

Try it

Farcaster Memecoins

cURL

Copy

Ask AI

```
curl --request GET \
  --url https://api.dune.com/api/v1/farcaster/trends/memecoins \
  --header 'X-Dune-Api-Key: <x-dune-api-key>'
```

200

400

401

402

403

404

500

Copy

Ask AI

```
{
  "cancelled_at": "2024-12-20T11:04:18.724658237Z",
  "execution_ended_at": "2024-12-20T11:04:18.724658237Z",
  "execution_id": "01HKZJ2683PHF9Q9PHHQ8FW4Q1",
  "execution_started_at": "2024-12-20T11:04:18.724658237Z",
  "expires_at": "2024-12-20T11:04:18.724658237Z",
  "is_execution_finished": true,
  "next_offset": 100,
  "next_uri": "https://api.dune.com/api/v1/execution/01HKZJ2683PHF9Q9PHHQ8FW4Q1/results?offset=100&limit=100",
  "query_id": 1234,
  "result": {
    "metadata": {
      "column_names": [
        "Rank",
        "Project",
        "Volume"
      ],
      "column_types": [
        "double",
        "varchar",
        "bigint"
      ],
      "datapoint_count": 1000,
      "execution_time_millis": 1000,
      "pending_time_millis": 1000,
      "result_set_bytes": 1000,
      "row_count": 10,
      "total_result_set_bytes": 10000,
      "total_row_count": 1000
    },
    "rows": [
      {}
    ]
  },
  "state": "QUERY_STATE_COMPLETED",
  "submitted_at": "2024-12-20T11:04:18.724658237Z"
}
```

* Query can be found [here](https://dune.com/queries/3662242)
* Scheduled to update every 30 minutes
* You can apply [filters](../../executions/filtering) like WHERE, IN, AND/OR upon results
* Learn about memecoins and categories [in this article](https://read.cryptodatabytes.com/p/a-social-and-financial-study-of-memecoins)

# [​](#use-cases) Use Cases

* Recommend trending memecoins based on farcaster engagement, liquidity, volume, or other onchain activity

# [​](#column-descriptions) Column Descriptions

Learn more about the score and methodology [in this article](https://read.cryptodatabytes.com/p/a-social-and-financial-study-of-memecoins).

| Column | Description | Type |
| --- | --- | --- |
| word\_raw | Ticker symbol of the token | string |
| related\_symbol | any symbol or word that is related to the token (i.e. the degen hat or higher arrow) | string |
| token\_contract\_address | Contract address of the token | string |
| blockchain | Blockchain on which the token is deployed | string |
| deployed\_days\_ago | Number of days since the token was deployed | integer |
| social\_score | Social score of the token | integer |
| financial\_score | Financial score of the token | integer |
| meme\_category | category of meme based off of social and financial score values | string |
| casters | Number of users who have casted the token ticker | integer |
| casters\_wow | Change in the number of casters week over week | integer |
| percent\_recipient\_casters | Percentage of casters this week that have received the token before | integer |
| percent\_recipient\_wow | Change in the percentage of recipient casters week over week | integer |
| recipient\_casters | Number of casters this week that have received the token before | integer |
| recipient\_casters\_wow | Change in the number of recipient casters week over week | integer |
| casts | Number of times the token ticker has been casted | integer |
| casts\_wow | Change in the number of casts week over week | integer |
| channels | Number of channels the token ticker has been casted in | integer |
| channels\_wow | Change in the number of channels week over week | integer |
| activity\_level | Activity level of the token | integer |
| activity\_wow | Change in the activity level week over week | integer |
| total\_supply | Total supply of the token | integer |
| fdv | Fully diluted valuation of the token | integer |
| median\_price | Median price of the token | integer |
| day\_pnl | Profit and loss of the token price in the last 24 hours | integer |
| week\_pnl | Profit and loss of the token price in the last 7 days | integer |
| month\_pnl | Profit and loss of the token price in the last 30 days | integer |
| liquidity\_usd | Liquidity of the token in USD | integer |
| liquidity\_wow | Change in liquidity week over week | integer |
| rolling\_one\_months\_trades | Number of trades in the last month | integer |
| transfers\_one\_month | Number of token transfers in the last month | integer |
| total\_volume\_week | Total trading volume of the token in the last 7 days | integer |
| total\_volume\_wow | Change in total trading volume week over week | integer |
| buy\_volume\_week | Total buying volume of the token in the last 7 days | integer |
| buy\_volume\_wow | Change in total buying volume week over week | integer |
| sell\_volume\_week | Total selling volume of the token in the last 7 days | integer |
| sell\_volume\_wow | Change in total selling volume week over week | integer |

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

API Key, alternative to using the HTTP header X-Dune-Api-Key

[​](#parameter-allow-partial-results)

allow\_partial\_results

boolean

This enables returning a query result that was too large and only a partial result is
available. By default allow\_partial\_results is set to false and a failed state is returned.

[​](#parameter-columns)

columns

string

Specifies a comma-separated list of column names to return. If omitted, all columns are included.
Tip: use this to limit the result to specific columns, reducing datapoints cost of the call.

[​](#parameter-filters)

filters

string

Expression to filter out rows from the results to return. This expression is similar to
a SQL WHERE clause. More details about it in the Filtering section of the doc.
This parameter is incompatible with sample\_count.

[​](#parameter-ignore-max-datapoints-per-request)

ignore\_max\_datapoints\_per\_request

boolean

There is a default 250,000 datapoints limit to make sure you don't accidentally spend all
your credits in one call. To ignore the max limit, you can add
ignore\_max\_datapoints\_per\_request=true

[​](#parameter-limit)

limit

integer

Limit number of rows to return. This together with 'offset' allows easy pagination through
results in an incremental and efficient way. This parameter is incompatible
with sampling (sample\_count).

[​](#parameter-offset)

offset

integer

Offset row number to start (inclusive, first row means offset=0) returning results
from. This together with 'limit' allows easy pagination through results in an
incremental and efficient way. This parameter is incompatible with sampling (sample\_count).

[​](#parameter-query-id)

queryID

integer

required

[​](#parameter-sample-count)

sample\_count

integer

Number of rows to return from the result by sampling the data. This is useful when you
want to get a uniform sample instead of the entire result. If the result has less
than the sample count, the entire result is returned. Note that this will return a
randomized sample, so not every call will return the same result. This parameter is
incompatible with `offset`, `limit`, and `filters` parameters.

[​](#parameter-sort-by)

sort\_by

string

Expression to define the order in which the results should be returned. This expression
is similar to a SQL ORDER BY clause. More details about it in the Sorting section of the doc.

#### Response

200

200400401402403404500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/farcaster/endpoint/farcaster_memecoins)

[Farcaster Channels](/api-reference/farcaster/endpoint/farcaster_channels)[Farcaster Users](/api-reference/farcaster/endpoint/farcaster_users)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.