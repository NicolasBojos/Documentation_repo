[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Farcaster

Dune Farcaster Endpoints

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster

  + [Dune Farcaster Endpoints](/api-reference/farcaster/introduction)
  + [GET

    Farcaster Channels](/api-reference/farcaster/endpoint/farcaster_channels)
  + [GET

    Farcaster Memecoins](/api-reference/farcaster/endpoint/farcaster_memecoins)
  + [GET

    Farcaster Users](/api-reference/farcaster/endpoint/farcaster_users)
* Markets
* Projects

Farcaster

# Dune Farcaster Endpoints

While you can create/use any query as an API endpoint, we’ve defined three popular queries as custom endpoints (so you don’t need to worry about executions or editing SQL). You should use these endpoints to provide better data to inform your algorithims, recomendations, or UI elements.

[## Trending Farcaster Users

Get trending users, based on farcaster engagement and onchain activity](/api-reference/farcaster/endpoint/farcaster_users)[## Trending Farcaster Channels

Get trending channels, based on user tiers, onchain activity, and engagement.](/api-reference/farcaster/endpoint/farcaster_channels)[## Trending Farcaster Memecoins

Get trending memecoins, based on engagement, holders, liquidity, volume, and more.](/api-reference/farcaster/endpoint/farcaster_memecoins)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/farcaster/introduction)

[Trending Contracts](/api-reference/evm/endpoint/contracts)[Farcaster Channels](/api-reference/farcaster/endpoint/farcaster_channels)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.