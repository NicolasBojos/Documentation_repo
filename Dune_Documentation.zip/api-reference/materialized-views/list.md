[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Materialized Views

List Materialized Views

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views

  + [GET

    Get Materialized View](/api-reference/materialized-views/get)
  + [POST

    Upsert Materialized View](/api-reference/materialized-views/create)
  + [DEL

    Delete Materialized View](/api-reference/materialized-views/delete)
  + [GET

    List Materialized Views](/api-reference/materialized-views/list)
  + [POST

    Refresh Materialized View](/api-reference/materialized-views/refresh)
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

This lists all materialized view owned by the account tied to the API key

cURL

Copy

Ask AI

```
curl --request GET \
  --url https://api.dune.com/api/v1/materialized-views \
  --header 'X-Dune-Api-Key: <x-dune-api-key>'
```

200

400

401

500

Copy

Ask AI

```
{
  "materialized_views": [
    {
      "id": "<string>",
      "is_private": true,
      "query_id": 123,
      "sql_id": "<string>",
      "table_size_bytes": 123
    }
  ],
  "next_offset": 123
}
```

Materialized Views

# List Materialized Views

This lists all materialized view owned by the account tied to the API key

GET

/

v1

/

materialized-views

Try it

This lists all materialized view owned by the account tied to the API key

cURL

Copy

Ask AI

```
curl --request GET \
  --url https://api.dune.com/api/v1/materialized-views \
  --header 'X-Dune-Api-Key: <x-dune-api-key>'
```

200

400

401

500

Copy

Ask AI

```
{
  "materialized_views": [
    {
      "id": "<string>",
      "is_private": true,
      "query_id": 123,
      "sql_id": "<string>",
      "table_size_bytes": 123
    }
  ],
  "next_offset": 123
}
```

* This endpoint will list all the materialized views under the ownership of the account tied to the API key used

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

API Key, alternative to using the HTTP header X-Dune-Api-Key

[​](#parameter-limit)

limit

string

Number of materialized views to return on a page. Default and max 10000

[​](#parameter-offset)

offset

string

Offset used for pagination. Use the value provided on a previous response under next\_offset

#### Response

200

200400401500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/materialized-views/list)

[Delete Materialized View](/api-reference/materialized-views/delete)[Refresh Materialized View](/api-reference/materialized-views/refresh)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.