[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Materialized Views

Get Materialized View

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views

  + [GET

    Get Materialized View](/api-reference/materialized-views/get)
  + [POST

    Upsert Materialized View](/api-reference/materialized-views/create)
  + [DEL

    Delete Materialized View](/api-reference/materialized-views/delete)
  + [GET

    List Materialized Views](/api-reference/materialized-views/list)
  + [POST

    Refresh Materialized View](/api-reference/materialized-views/refresh)
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

This fetches a materialized view given a name

cURL

Copy

Ask AI

```
curl --request GET \
  --url https://api.dune.com/api/v1/materialized-views/{name} \
  --header 'X-Dune-Api-Key: <x-dune-api-key>'
```

200

400

401

403

404

500

Copy

Ask AI

```
{
  "id": "<string>",
  "is_private": true,
  "last_execution_ids": [
    "<string>"
  ],
  "owner_team_id": 123,
  "owner_user_id": 123,
  "query_id": 123,
  "sql_id": "<string>",
  "table_size_bytes": 123
}
```

Materialized Views

# Get Materialized View

This fetches a materialized view given a name

GET

/

v1

/

materialized-views

/

{name}

Try it

This fetches a materialized view given a name

cURL

Copy

Ask AI

```
curl --request GET \
  --url https://api.dune.com/api/v1/materialized-views/{name} \
  --header 'X-Dune-Api-Key: <x-dune-api-key>'
```

200

400

401

403

404

500

Copy

Ask AI

```
{
  "id": "<string>",
  "is_private": true,
  "last_execution_ids": [
    "<string>"
  ],
  "owner_team_id": 123,
  "owner_user_id": 123,
  "query_id": 123,
  "sql_id": "<string>",
  "table_size_bytes": 123
}
```

* The name must be the full name qualifier for the matview, i.e. `dune.<your_team>.<name>`

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Path Parameters

[​](#parameter-name)

name

string

required

Matview Name

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

API Key, alternative to using the HTTP header X-Dune-Api-Key

#### Response

200

200400401403404500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/materialized-views/get)

[Unprivate Query](/api-reference/queries/endpoint/unprivate)[Upsert Materialized View](/api-reference/materialized-views/create)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.