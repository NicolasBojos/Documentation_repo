[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Materialized Views

Refresh Materialized View

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views

  + [GET

    Get Materialized View](/api-reference/materialized-views/get)
  + [POST

    Upsert Materialized View](/api-reference/materialized-views/create)
  + [DEL

    Delete Materialized View](/api-reference/materialized-views/delete)
  + [GET

    List Materialized Views](/api-reference/materialized-views/list)
  + [POST

    Refresh Materialized View](/api-reference/materialized-views/refresh)
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

This refreshes a materialized view

cURL

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/materialized-views/{name}/refresh \
  --header 'Content-Type: */*' \
  --header 'X-Dune-Api-Key: <x-dune-api-key>' \
  --data '{
  "performance": "<string>"
}'
```

200

400

401

404

500

Copy

Ask AI

```
{
  "execution_id": "01HZ065JVE23C23FM2HKWQP2RT",
  "sql_id": "dune.dune.result_erc_20_token_summary"
}
```

Materialized Views

# Refresh Materialized View

This refreshes a materialized view

POST

/

v1

/

materialized-views

/

{name}

/

refresh

Try it

This refreshes a materialized view

cURL

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/materialized-views/{name}/refresh \
  --header 'Content-Type: */*' \
  --header 'X-Dune-Api-Key: <x-dune-api-key>' \
  --data '{
  "performance": "<string>"
}'
```

200

400

401

404

500

Copy

Ask AI

```
{
  "execution_id": "01HZ065JVE23C23FM2HKWQP2RT",
  "sql_id": "dune.dune.result_erc_20_token_summary"
}
```

* By default, the refresh runs on the `medium` engine, costing 10 credits per refresh. To boost performance, pass in a JSON body with `{"performance": "large"}`, which consumes 20 credits per refresh.
* If you prefer `medium` performance, you can omit the `performance` parameter.
* You must own the materialized view to refresh it.

* After triggering the refresh, you can check the status by passing the returned `execution_id` into the [Get Execution Status endpoint](/api-reference/executions/endpoint/get-execution-status).
* To find the name of a materialized view:

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Path Parameters

[​](#parameter-name)

name

string

required

Matview Name

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

API Key, alternative to using the HTTP header X-Dune-Api-Key

#### Body

\*/\*

MatviewsRefreshRequest

The body is of type `object`.

#### Response

200

200400401404500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/materialized-views/refresh)

[List Materialized Views](/api-reference/materialized-views/list)[Create Webhook](/api-reference/webhooks/webhook)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.