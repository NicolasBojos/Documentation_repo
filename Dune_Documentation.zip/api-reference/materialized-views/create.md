[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Materialized Views

Upsert Materialized View

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Dune API Overview](/api-reference/overview/introduction)
* API Quickstart
* [Authentication](/api-reference/overview/authentication)
* [Client SDKs](/api-reference/overview/sdks)
* Result Filtering
* [Rate Limits](/api-reference/overview/rate-limits)
* [Troubleshooting Errors](/api-reference/overview/troubleshooting)
* [Billing](/api-reference/overview/billing)
* [FAQ](/api-reference/overview/faq)

##### Custom Endpoints

* [Overview](/api-reference/custom/overview)

##### SQL Endpoints

* Executions and Results
* Queries
* Materialized Views

  + [GET

    Get Materialized View](/api-reference/materialized-views/get)
  + [POST

    Upsert Materialized View](/api-reference/materialized-views/create)
  + [DEL

    Delete Materialized View](/api-reference/materialized-views/delete)
  + [GET

    List Materialized Views](/api-reference/materialized-views/list)
  + [POST

    Refresh Materialized View](/api-reference/materialized-views/refresh)
* Webhooks

##### Data Management Endpoints

* Tables

##### Preset Endpoints

* DEX
* EigenLayer
* EVM Contracts
* Farcaster
* Markets
* Projects

This upserts (create or replace) a materialized view from an existing query

cURL

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/materialized-views \
  --header 'Content-Type: */*' \
  --header 'X-Dune-Api-Key: <x-dune-api-key>' \
  --data '{
  "cron_expression": "<string>",
  "is_private": true,
  "name": "<string>",
  "performance": "<string>",
  "query_id": 123
}'
```

200

400

401

404

500

Copy

Ask AI

```
{
  "execution_id": "01HZ065JVE23C23FM2HKWQP2RT",
  "name": "dune.dune.result_erc_20_token_summary"
}
```

Materialized Views

# Upsert Materialized View

This upserts a materialized view from an existing query. If the materialized view with the given name

POST

/

v1

/

materialized-views

Try it

This upserts (create or replace) a materialized view from an existing query

cURL

Copy

Ask AI

```
curl --request POST \
  --url https://api.dune.com/api/v1/materialized-views \
  --header 'Content-Type: */*' \
  --header 'X-Dune-Api-Key: <x-dune-api-key>' \
  --data '{
  "cron_expression": "<string>",
  "is_private": true,
  "name": "<string>",
  "performance": "<string>",
  "query_id": 123
}'
```

200

400

401

404

500

Copy

Ask AI

```
{
  "execution_id": "01HZ065JVE23C23FM2HKWQP2RT",
  "name": "dune.dune.result_erc_20_token_summary"
}
```

* This endpoint will create a new matview if none exists for the gven query ID, or update an existing one if the query ID matches.
* It will fail to create a matview with the same name as an existing one, but for a different query ID
* The name of the matview is just the last part of the matview, not including `dune.<your_team>.` and must be prefixed with `result_`
* The `cron_expression` parameter must be passed in as a valid 5 section cron expression. [See here](https://crontab.guru/) for how to write them.

* The cron expression interval must be at least 15 minutes and at most weekly

#### Headers

[​](#parameter-x-dune-api-key)

X-Dune-Api-Key

string

required

API Key for the service

#### Path Parameters

[​](#parameter-name)

name

string

required

Matview Name

#### Query Parameters

[​](#parameter-api-key)

api\_key

string

API Key, alternative to using the HTTP header X-Dune-Api-Key

#### Body

\*/\*

MatviewsUpsertRequest

The body is of type `object`.

#### Response

200

200400401404500

application/json

OK

The response is of type `object`.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /api-reference/materialized-views/create)

[Get Materialized View](/api-reference/materialized-views/get)[Delete Materialized View](/api-reference/materialized-views/delete)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.