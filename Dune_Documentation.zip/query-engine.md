[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

DuneSQL Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Overview](/query-engine/overview)

##### Functionality

* [Executions](/query-engine/query-executions)
* [Query Views](/query-engine/query-a-query)
* [Materialized Views](/query-engine/materialized-views)

##### DuneSQL

* [Writing Efficient Queries](/query-engine/writing-efficient-queries)
* [Datatypes](/query-engine/datatypes)
* [Reserved keywords](/query-engine/reserved-keywords)

##### Functions and Operators

* [Overview](/query-engine/Functions-and-operators)
* [Aggregate functions](/query-engine/Functions-and-operators/aggregate)
* [Array functions and operators](/query-engine/Functions-and-operators/array)
* [Base58 functions](/query-engine/Functions-and-operators/base58)
* [Binary](/query-engine/Functions-and-operators/binary)
* [Bitwise](/query-engine/Functions-and-operators/bitwise)
* [Chain Utility Functions](/query-engine/Functions-and-operators/chain-utility-functions)
* [Comparisons](/query-engine/Functions-and-operators/comparison)
* [Conditional expressions](/query-engine/Functions-and-operators/conditional)
* [Conversions](/query-engine/Functions-and-operators/conversion)
* [Date and time functions and operators](/query-engine/Functions-and-operators/datetime)
* [Decimal functions and operators](/query-engine/Functions-and-operators/decimal)
* [EVM Decoding Functions](/query-engine/Functions-and-operators/evm-decoding-functions)
* [HyperLogLog functions](/query-engine/Functions-and-operators/hyperloglog)
* [JSON functions](/query-engine/Functions-and-operators/json)
* [Lambda expressions](/query-engine/Functions-and-operators/lambda)
* [LiveFetch functions](/query-engine/Functions-and-operators/live-fetch)
* [Logical operators](/query-engine/Functions-and-operators/logical)
* [Map functions and operators](/query-engine/Functions-and-operators/map)
* [Mathematical functions and operators](/query-engine/Functions-and-operators/math)
* [Machine learning functions](/query-engine/Functions-and-operators/ml)
* [Quantile digest functions](/query-engine/Functions-and-operators/qdigest)
* [Regular expression functions](/query-engine/Functions-and-operators/regexp)
* [Set Digest functions](/query-engine/Functions-and-operators/setdigest)
* [SS58 functions](/query-engine/Functions-and-operators/ss58)
* [TON address functions](/query-engine/Functions-and-operators/tonaddress)
* [Tron address functions](/query-engine/Functions-and-operators/tronaddress)
* [String functions and operators](/query-engine/Functions-and-operators/string)
* [System information](/query-engine/Functions-and-operators/system)
* [T-Digest functions](/query-engine/Functions-and-operators/tdigest)
* [Teradata functions](/query-engine/Functions-and-operators/teradata)
* [URL functions](/query-engine/Functions-and-operators/url)
* [UUID functions](/query-engine/Functions-and-operators/uuid)
* [Varbinary functions (DuneSQL)](/query-engine/Functions-and-operators/varbinary)
* [Varchar Utility Functions](/query-engine/Functions-and-operators/varchar-utility-functions)
* [Window functions](/query-engine/Functions-and-operators/window)

On this page

* [Functions and Operators](#functions-and-operators)
* [Data Types](#data-types)
* [SQL Statement Syntax](#sql-statement-syntax)
* [Reserved Keywords](#reserved-keywords)
* [Querying Capabilities](#querying-capabilities)

# DuneSQL Overview

Explore the capabilities of DuneSQL, a custom query engine optimized for blockchain data, leveraging a TrinoSQL fork.

DuneSQL stands out as a specialized query engine crafted for blockchain data analytics, deriving its foundation from the TrinoSQL engine but with significant enhancements for blockchain-specific demands.

## [​](#functions-and-operators) Functions and Operators

DuneSQL extends a comprehensive suite of functions and operators facilitating a broad spectrum of operations on data, including arithmetic operations, string manipulation, and date-time computations, tailored to blockchain analytics needs.

[## Functions and Operators

Dive into the extensive range of functions and operators in DuneSQL for data
manipulation and analysis.](/query-engine/Functions-and-operators)

## [​](#data-types) Data Types

With support for standard data types and unique blockchain-specific types like varbinary for addresses and hashes, along with int256 and uint256 for large numeric values, DuneSQL is adept at handling the intricacies of blockchain data.

[## Data Types

Explore the diverse data types in DuneSQL, designed to cater to the unique
requirements of blockchain data.](/query-engine/datatypes.mdx)

## [​](#sql-statement-syntax) SQL Statement Syntax

Adhering to standard SQL syntax with clauses like SELECT, FROM, WHERE, DuneSQL enables complex queries for data retrieval and analysis while restricting data modification operations to preserve database integrity.

## [​](#reserved-keywords) Reserved Keywords

DuneSQL designates specific reserved keywords for internal functions, ensuring these are not used as identifiers, thus maintaining the engine’s operational integrity.

[## Reserved Keywords

Familiarize yourself with the reserved keywords in DuneSQL to avoid
conflicts in query syntax.](/query-engine/reserved-keywords)

## [​](#querying-capabilities) Querying Capabilities

Although DuneSQL limits data modification commands to safeguard data integrity, it offers innovative solutions like query queries for creating views and tables, enhancing data analysis flexibility.

[## Querying Queries

Utilize the query queries feature in DuneSQL to compensate for the
restricted ability to create views and tables, enriching data analysis
possibilities.](/query-engine/query-a-query)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /query-engine)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.