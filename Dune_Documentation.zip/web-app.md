[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Analytics Studio

Web App

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

##### Analytics Studio

* [Overview](/web-app/overview)
* Create Queries
* Create Visualizations
* Decoding Contracts
* [Create Dashboards](/web-app/dashboards)
* [Mint Dashboards](/web-app/dashboard-minting)
* [Teams on Dune](/web-app/teams)
* [Dune AI](/web-app/dune-ai)
* [Upload Data](/web-app/upload-data)
* [Share your work](/web-app/embeds)
* [Search content](/web-app/search)
* [Alerts](/web-app/alerts)
* [Bug Bounty](/web-app/bug-bounty)
* [Measuring User Activity](/web-app/user-activity)

On this page

* [Dune Web App](#dune-web-app)

Analytics Studio

# Web App

Dune has built the perfect tools to efficiently extract information from blockchain data.

Explore the foundational elements of Dune through the Dune Web App and Query Engine. Each feature is designed to streamline your access to and analysis of complex blockchain data.

### [​](#dune-web-app) Dune Web App

Explore the multitude of features within the Dune Web App that streamline your journey from data to insights. Whether it’s crafting a custom dashboard, decoding smart contracts, or collaborating with your team, the Web App is your one-stop solution for blockchain analytics.

[## Query Editor

Harness the power of SQL in the Query Editor to dissect and analyze blockchain data with precision.](/web-app/query-editor)[## Visualizations

Transform data into compelling visual narratives with a suite of visualization tools.](/web-app/visualizations)[## Create a Dashboard

Craft interactive dashboards to monitor and present your key metrics at a glance.](/web-app/dashboards)[## Teams on Dune

Collaborate effectively with your team members on shared projects and analyses.](/web-app/teams)[## Dune AI

Leverage artificial intelligence to gain deeper insights and predictions from your data.](/web-app/dune-ai)[## Upload Data

Integrate your datasets into Dune with our straightforward data upload tools.](/web-app/upload-data)[## Share Your Work

Spread your findings and dashboards with the community or stakeholders seamlessly.](/web-app/embeds)[## Search Content

Quickly locate the data you need with our powerful search capabilities.](/web-app/search)[## Alerts

Stay informed with custom alerts that notify you of important data changes and trends.](/web-app/alerts)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /web-app/overview)

[Writing Queries](/web-app/query-editor/query-window)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.