[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Dune Index

Transactions

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Overview](#overview)
* [Methodology](#methodology)
* [Technical Considerations](#technical-considerations)
* [Limitations](#limitations)
* [Usage Guidelines](#usage-guidelines)

Dune Index

# Transactions

Understanding transactions as a foundational component of the Dune Index

## [​](#overview) Overview

The transaction component of the Dune Index measures blockchain activity by counting transactions that transfer at least 1 USD in value. This filtered approach helps focus on meaningful economic activity while maintaining a simple, verifiable methodology.

## [​](#methodology) Methodology

The transaction metric employs a straightforward filtering approach:

1. Base Criteria
   * Count only transactions with transfers of $1 or more
   * Convert all token transfers to USD value at time of transaction
   * Include both native token and token contract transfers
2. Rationale
   * $1 threshold excludes dust transactions and spam
   * Low threshold maintains inclusivity of meaningful activity
   * Simple criteria enables consistent cross-chain comparison
3. Implementation
   * Track successful transfers only
   * Calculate USD value at transaction time
   * Aggregate across all supported token types

[## Transactions Metrics Code

For specifics on how this is implemented, refer to the transactions metrics code in the Spellbook repository.](https://github.com/duneanalytics/spellbook/tree/main/dbt_subprojects/daily_spellbook/models/_metrics/transactions)

## [​](#technical-considerations) Technical Considerations

Several factors influence transaction counting:

1. Value Calculation
   * Use time-weighted token prices
   * Account for token decimals and precision
   * Handle cases of missing price data
2. Cross-Chain Standardization
   * Apply consistent $1 threshold across networks
   * Account for different token value representations
   * Handle multi-token transactions appropriately

## [​](#limitations) Limitations

Understanding the metric’s limitations is crucial:

1. Threshold Effects
   * May exclude some meaningful sub-$1 activity
   * Still includes some non-meaningful activity above $1
   * Value threshold is nominal, not inflation-adjusted
2. Technical Constraints
   * Requires reliable price data for all tokens
   * Must handle complex transaction types consistently
   * Network upgrades may affect transaction classification

## [​](#usage-guidelines) Usage Guidelines

When analyzing transaction data:

1. Trend Analysis
   * Focus on directional changes over time
   * Compare across similar time periods
   * Consider seasonal and cyclical patterns
2. Context
   * Use alongside other Dune Index components
   * Consider network-specific factors
   * Account for major protocol changes

The transaction count provides a foundational measure of blockchain adoption while the $1 threshold helps filter out noise, making it a valuable component of the Dune Index despite its inherent limitations.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/dune-index/transactions)

[Net Transfers](/data-catalog/dune-index/net-transfers)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.