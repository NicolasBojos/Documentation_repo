[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Dune Index

Transactions Fees

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Overview](#overview)
* [EVM Networks](#evm-networks)
* [Non-EVM Networks](#non-evm-networks)
* [Solana](#solana)
* [Bitcoin](#bitcoin)

Dune Index

# Transactions Fees

Understanding transaction fees and their relationship to transaction costs in blockchain networks

## [​](#overview) Overview

Transaction fees represent the dollar costs of executing operations on blockchain networks. By measuring transaction fees, we can understand the demand for resources on the network and the incentives that drive user behavior.
Gas fee calculations are more complex than they may seem at first glance. This is because different networks have different fee structures, and some even have multiple components to their fees. We are aggregating the data from multiple sources to provide a comprehensive view of the fees paid for each network.
You can explore the daily gas fee data via `metrics.gas_fees_daily`

### [​](#evm-networks) EVM Networks

For EVM networks, we have developed a unified model to calculate transaction fees consistently across different types of chains. The data is accessible through the `gas.fees` table, which standardizes the fee components into `l1_fee`, `base_fee`, and `priority_fee`. This model elegantly unifies the fee structures of rollups, L1s, and L2s, providing a coherent view of gas costs across the EVM ecosystem. However, it’s important to note that the specific fee components and their calculations may vary depending on the unique characteristics and design choices of each network. You can find the fee components for each network below.

* Arbitrum
* Avalanche C-Chain
* Base
* Blast
* BNB Chain
* Celo
* Ethereum
* Fantom
* Gnosis
* Linea
* Mantle
* Optimism
* Polygon
* Scroll
* Sei
* Tron
* zkEVM
* zkSync
* Zora

Arbitrum uses a custom L1/L2 fee model that ignores priority fees (tips) in calculations and uses effective\_gas\_price instead of standard gas\_price. This helps account for the actual costs of posting data to the L1 chain.

Copy

Ask AI

```
-- Two component fee structure
l1_fee = gas_used_for_l1 * effective_gas_price
base_fee = (gas_used - gas_used_for_l1) * effective_gas_price

```

[## Fee Metrics Code

For more details on the implementation, check out the fees metrics code in the Spellbook repository.](https://github.com/duneanalytics/spellbook/tree/main/dbt_subprojects/daily_spellbook/models/_metrics/fees)

### [​](#non-evm-networks) Non-EVM Networks

For non-EVM networks we haven’t yet found a consistent way to model the fee structure, so we are not yet able to provide a unified model for non-EVM networks. However all the data is included in the `metrics.gas_fees_daily` table.

#### [​](#solana) Solana

Solana has two “types” of transactions: *transactions* and *votes*. We track the fees for each type separately in `gas_solana.tx_fees` and `gas_solana.vote_fees`.

* Solana Transactions
* Solana Votes

Solana uses a custom fee structure with a base fee and an optional prioritization fee for transactions. The base fee is calculated based on the number of signatures required for the transaction, while the prioritization fee depends on the compute unit price and compute budget limit.

Copy

Ask AI

```
-- Two component fee structure
base_fee = # of signatures * 0.000005
priority_fee = compute_unit_price * compute_budget_limit

```

This data is standardized in `gas_solana.tx_fees`.

We consider both `gas_solana.tx_fees` and `gas_solana.vote_fees` when calculating the total transaction fees for solana in `metrics.gas_fees_daily`.

#### [​](#bitcoin) Bitcoin

Bitcoin uses a simple fee structure where each transaction has a fee paid to the miner. Miners pick the transactions with the highest fees to include in the next block.

Copy

Ask AI

```
-- Single component fee structure
fee = fee

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/dune-index/gas-fees)

[Introduction](/data-catalog/dune-index/introduction)[Net Transfers](/data-catalog/dune-index/net-transfers)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.