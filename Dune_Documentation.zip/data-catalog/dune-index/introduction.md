[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Dune Index

Dune Index

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is the Dune Index?](#what-is-the-dune-index%3F)
* [Why the Dune Index?](#why-the-dune-index%3F)
* [Components](#components)
* [Component Selection Rationale](#component-selection-rationale)
* [Implementation Guide](#implementation-guide)
* [Excluded Metrics](#excluded-metrics)
* [Price and Market Capitalization](#price-and-market-capitalization)
* [Total Value Locked (TVL)](#total-value-locked-tvl)
* [Active Addresses](#active-addresses)

Dune Index

# Dune Index

The Dune Index is a comprehensive indicator of blockchain adoption across the industry.

## [​](#what-is-the-dune-index%3F) What is the Dune Index?

The Dune Index serves as a comprehensive measurement framework for blockchain adoption, designed to capture meaningful usage while filtering out speculative activity. By combining multiple standardized metrics, it provides an objective view of how blockchain technology is being utilized across different networks and use cases.

## [​](#why-the-dune-index%3F) Why the Dune Index?

Traditional blockchain metrics often fall short of measuring genuine adoption. Market capitalization and token prices primarily reflect speculative sentiment, while metrics like Total Value Locked (TVL) can be manipulated by large holders. The Dune Index addresses these limitations by focusing on actual network usage and economic activity.
The index was specifically designed to track meaningful adoption that indicates real-world utility. This approach helps stakeholders distinguish between speculative bubbles and sustainable growth in blockchain usage.

## [​](#components) Components

The Dune Index aggregates three fundamental metrics, each normalized to a baseline value of 10 to enable meaningful comparison:

[## Transaction Fees

Measures real demand for blockspace](/data-catalog/dune-index/gas-fees)[## Net USD Transferred

Tracks genuine value movement](/data-catalog/dune-index/net-transfers)[## Transactions

Indicates breadth of usage](/data-catalog/dune-index/transactions)

### [​](#component-selection-rationale) Component Selection Rationale

These metrics were carefully chosen to provide a comprehensive view of blockchain usage. Transaction fees demonstrate users’ willingness to pay for block space, serving as a market-driven indicator of demand. Net transfers capture actual economic activity while filtering out artificial volume. Transaction count provides context about the breadth of network usage.
Together, these metrics create a robust framework that resists artificial inflation and captures different aspects of blockchain utility.

[## Dune Index Metrics Code

For implementation details, see the Dune Index metrics code in the Spellbook repository.](https://github.com/duneanalytics/spellbook/tree/main/dbt_subprojects/daily_spellbook/models/_metrics/dune_index)

## [​](#implementation-guide) Implementation Guide

The Dune Index can be utilized in several ways:

* Track industry trends by monitoring long-term adoption patterns and growth trajectories across the blockchain space.
* Enable detailed blockchain breakdowns to compare adoption metrics between different networks.
* Through component analysis, users can evaluate the relative impact of each metric on overall adoption.
* The index methodology can also be extended for specialized research and custom analysis needs.

## [​](#excluded-metrics) Excluded Metrics

The index intentionally excludes several common blockchain metrics due to their limitations:

### [​](#price-and-market-capitalization) Price and Market Capitalization

Market-based metrics were excluded as they primarily reflect speculative activity rather than actual usage. Price movements often diverge significantly from underlying adoption patterns and can be heavily influenced by market sentiment rather than utility.

### [​](#total-value-locked-tvl) Total Value Locked (TVL)

While TVL provides insight into DeFi activity, it has significant limitations as an adoption metric. The metric can be manipulated by large holders, doesn’t account for capital efficiency, and automatically increases with asset prices regardless of actual usage.

### [​](#active-addresses) Active Addresses

Address-based metrics prove problematic due to the ease of address creation and the common practice of users maintaining multiple addresses. These metrics fail to distinguish between meaningful activity and artificial inflation through address generation.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/dune-index/introduction)

[Follows Dataset](/data-catalog/community/snapshot/follows)[Transactions Fees](/data-catalog/dune-index/gas-fees)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.