[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Dune Index

Net USD Transferred

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Overview](#overview)
* [Technical Significance](#technical-significance)
* [Calculation Methodology](#calculation-methodology)
* [Analytical Framework](#analytical-framework)

Dune Index

# Net USD Transferred

Understanding net USD transferred as a component of the Dune Index

## [​](#overview) Overview

Net USD transferred provides a measure of genuine economic activity across blockchain networks by tracking the actual movement of value between distinct entities. This metric implements sophisticated filtering mechanisms to distinguish meaningful transfers from artificial activity, offering insight into real economic impact.

## [​](#technical-significance) Technical Significance

Net transfers serve as a crucial indicator of blockchain utility by measuring actual value movement while filtering out noise. Unlike gross transfer volumes, which can be inflated through wash trading or circular transactions, net transfers focus on the ultimate economic impact of blockchain activity.
The metric is particularly valuable because it requires significant economic resources to manipulate, making it a more reliable indicator of genuine activity compared to metrics like transaction count or total volume.

## [​](#calculation-methodology) Calculation Methodology

The computation of net transfers follows a rigorous process:

1. Address-Level Aggregation
   * Track all value movements between addresses
   * Calculate daily net position changes per address (inflows minus outflows)
2. Filtering Criteria
   * Minimum threshold of $1 to exclude dust transactions
   * Removal of internal transactions from known contracts and protocols
   * Exclusion of identified wash trading patterns
   * Filtering of exploit-related transfers and known scam addresses
3. Standardization
   * Conversion to USD equivalent values using time-weighted average prices
   * Normalization against baseline metrics for cross-chain comparison

[## Transfers Metrics Code

See the transfers metrics code for the technical implementation details.](https://github.com/duneanalytics/spellbook/tree/main/dbt_subprojects/daily_spellbook/models/_metrics/transfers)

## [​](#analytical-framework) Analytical Framework

When interpreting net transfer data, consider several key aspects:

1. Volume Patterns
   * Analyze sustained periods of high net transfer volume
   * Identify unusual spikes that may indicate large-scale events or anomalies
2. Comparative Analysis
   * Compare net transfers against gross transfer volume to detect wash trading
   * Evaluate relationships with transaction counts and fee levels
   * Monitor distribution patterns across different blockchain networks
3. Network Effects
   * Consider how network upgrades or protocol changes impact transfer patterns
   * Analyze the impact of new DeFi protocols or applications on transfer volumes

This metric provides valuable insight into blockchain adoption when analyzed alongside other components of the Dune Index, offering a more complete picture of meaningful network usage.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/dune-index/net-transfers)

[Transactions Fees](/data-catalog/dune-index/gas-fees)[Transactions](/data-catalog/dune-index/transactions)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.