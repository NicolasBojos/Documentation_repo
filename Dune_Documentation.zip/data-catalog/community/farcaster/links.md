[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Farcaster

Links

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster

  + [Overview](/data-catalog/community/farcaster/overview)
  + [Casts](/data-catalog/community/farcaster/casts)
  + [Fids](/data-catalog/community/farcaster/fids)
  + [Fnames](/data-catalog/community/farcaster/fnames)
  + [Links](/data-catalog/community/farcaster/links)
  + [Profile with addresses](/data-catalog/community/farcaster/profile_with_addresses)
  + [Reactions](/data-catalog/community/farcaster/reactions)
  + [Signers](/data-catalog/community/farcaster/signers)
  + [Storage](/data-catalog/community/farcaster/storage)
  + [User Data](/data-catalog/community/farcaster/user_data)
  + [Verifications](/data-catalog/community/farcaster/verifications)
  + [Power Badge Fids](/data-catalog/community/farcaster/power_badge)
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [dune.neynar.dataset\_farcaster\_links](#dune-neynar-dataset-farcaster-links)

Farcaster

# Links

### [​](#dune-neynar-dataset-farcaster-links) **dune.neynar.dataset\_farcaster\_links**

This table contains data about follower and following relationships on the Farcaster protocol.

| **Column name** | **Type** | **Description** |
| --- | --- | --- |
| id | bigint | Row id |
| created\_at | timestamp without timezone | Timestamp of creation within database |
| updated\_at | timestamp without timezone | Timestamp of update within database |
| deleted\_at | timestamp without timezone | Timestamp of deletion on Farcaster protocol |
| timestamp | timestamp without timezone | Timestamp of creation on Farcaster protocol |
| fid | bigint | User ID of user on Farcaster protocol |
| target\_fid | bigint | FID of the user who is link target |
| hash | bytea | Link hash on the protocol |
| type | text | Link type, usually this is a “follow” |

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/community/farcaster/links)

[Fnames](/data-catalog/community/farcaster/fnames)[Profile with addresses](/data-catalog/community/farcaster/profile_with_addresses)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.