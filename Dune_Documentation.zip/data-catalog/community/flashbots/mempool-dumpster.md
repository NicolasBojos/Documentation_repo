[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Flashbots

dune.flashbots.dataset\_mempool\_dumpster

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots

  + [Overview](/data-catalog/community/flashbots/overview)
  + [Mempool Dumpster Dataset](/data-catalog/community/flashbots/mempool-dumpster)
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table description](#table-description)
* [Column descriptions](#column-descriptions)
* [Table Sample](#table-sample)

Flashbots

# dune.flashbots.dataset\_mempool\_dumpster

Description of the dune.flashbots.dataset\_mempool\_dumpster table on Dune

## [​](#table-description) Table description

This table captures detailed transaction data from the Ethereum mempool. It includes transactions that might attempt to extract value through reordering, sandwiching, or other MEV strategies.

## [​](#column-descriptions) Column descriptions

| Column Name | Description | Data Type |
| --- | --- | --- |
| `to` | The recipient address of the transaction. | varchar |
| `from` | The sender address of the transaction. | Varchar |
| `hash` | The unique transaction hash. | Varchar |
| `nonce` | The nonce of the transaction, a counter of the sender’s transactions. | Integer |
| `value` | The value transferred in the transaction, in wei. | BigInt |
| `gas` | The gas limit set for the transaction. | Integer |
| `gas_price` | The gas price set for the transaction, in wei. | BigInt |
| `data_size` | The size of the data payload in the transaction, in bytes. | Integer |
| `data_4bytes` | The first four bytes of the transaction data, typically the method identifier in a contract call. | Varchar |
| `sources` | The sources that captured the transaction data. | Varchar |
| `chain_id` | The identifier for the blockchain network (e.g., 1 for Ethereum Mainnet). | Integer |
| `gas_fee_cap` | The maximum amount of gas fee the sender is willing to pay (EIP-1559). | BigInt |
| `gas_tip_cap` | The maximum tip the sender is willing to pay miners (EIP-1559). | BigInt |
| `timestamp_ms` | The timestamp when the transaction was first seen, in milliseconds. | BigInt |
| `inclusion_delay_ms` | The delay in milliseconds from when the transaction was first seen to when it was included in a block. | Integer |
| `included_at_block_height` | The block height at which the transaction was included. | Integer |
| `included_block_timestamp_ms` | The timestamp of the block at which the transaction was included, in milliseconds. | BigInt |

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/community/flashbots/mempool-dumpster)

[Overview](/data-catalog/community/flashbots/overview)[Overview](/data-catalog/community/farcaster/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.