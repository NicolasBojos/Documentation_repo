[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Reservoir

Bids

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir

  + [Overview](/data-catalog/community/reservoir/overview)
  + [Ask Events](/data-catalog/community/reservoir/ask-events)
  + [Asks](/data-catalog/community/reservoir/asks)
  + [Attribute Keys](/data-catalog/community/reservoir/attribute-keys)
  + [Attributes](/data-catalog/community/reservoir/attributes)
  + [Bid Events](/data-catalog/community/reservoir/bid-events)
  + [Bids](/data-catalog/community/reservoir/bids)
  + [Collection Floor Ask Events](/data-catalog/community/reservoir/collection-floor-ask-events)
  + [Collection Top Bid Events](/data-catalog/community/reservoir/collection-top-bid-events)
  + [Collections](/data-catalog/community/reservoir/collections)
  + [Sales](/data-catalog/community/reservoir/sales)
  + [Token Attributes](/data-catalog/community/reservoir/token-attributes)
  + [Token Floor Ask Events](/data-catalog/community/reservoir/token-floor-ask-events)
  + [Tokens](/data-catalog/community/reservoir/tokens)
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [reservoir.bids](#reservoir-bids)

Reservoir

# Bids

## [​](#reservoir-bids) **reservoir.bids**

This table contains records with information about each bid.

| **Column name** | **Type** | **Description** |
| --- | --- | --- |
| id | string | Internal order id |
| kind | string | Protocol name (e.g. seaport) |
| status | string | Order status (active, inactive) |
| contract | string | Contract address |
| token\_set\_id | string | Id of the token set |
| maker | string | Maker wallet address |
| taker | string | Taker wallet address |
| price | string | The current price (native currency) |
| value | string | The current value (native currency) |
| currency\_address | string | Currency address |
| currency\_symbol | string | Currency symbol |
| currency\_price | string | Currency price |
| quantity | bigint | Amount of tokens that is listed |
| quantity\_filled | bigint | Amount of tokens that was filled |
| quantity\_remaining | bigint | Amount of tokens remaining |
| valid\_from | bigint | Listing start time |
| valid\_until | bigint | Listing end time |
| nonce | bigint | The order nonce of the maker |
| source | string | Source of the listing (e.g. opensea.io) |
| fee\_bps | bigint | Listing fee |
| expiration | bigint | Associated transaction hash |
| raw\_data | string | Raw order data (format will vary per source) |
| created\_at | timestamp | Timestamp the listing was created |
| updated\_at | timestamp | Timestamp the listing was updated |

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/community/reservoir/bids)

[Bid Events](/data-catalog/community/reservoir/bid-events)[Collection Floor Ask Events](/data-catalog/community/reservoir/collection-floor-ask-events)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.