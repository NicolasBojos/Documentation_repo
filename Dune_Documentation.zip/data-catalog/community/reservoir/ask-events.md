[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Reservoir

Ask Events

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir

  + [Overview](/data-catalog/community/reservoir/overview)
  + [Ask Events](/data-catalog/community/reservoir/ask-events)
  + [Asks](/data-catalog/community/reservoir/asks)
  + [Attribute Keys](/data-catalog/community/reservoir/attribute-keys)
  + [Attributes](/data-catalog/community/reservoir/attributes)
  + [Bid Events](/data-catalog/community/reservoir/bid-events)
  + [Bids](/data-catalog/community/reservoir/bids)
  + [Collection Floor Ask Events](/data-catalog/community/reservoir/collection-floor-ask-events)
  + [Collection Top Bid Events](/data-catalog/community/reservoir/collection-top-bid-events)
  + [Collections](/data-catalog/community/reservoir/collections)
  + [Sales](/data-catalog/community/reservoir/sales)
  + [Token Attributes](/data-catalog/community/reservoir/token-attributes)
  + [Token Floor Ask Events](/data-catalog/community/reservoir/token-floor-ask-events)
  + [Tokens](/data-catalog/community/reservoir/tokens)
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [reservoir.ask\_events](#reservoir-ask-events)

Reservoir

# Ask Events

## [​](#reservoir-ask-events) **reservoir.ask\_events**

This table contains records with information about each ask change.
Query examples can be found here:
<https://dune.com/queries/1302858/2232178>
<https://dune.com/queries/1302863/2232189>

| **Column name** | **Type** | **Description** |
| --- | --- | --- |
| id | bigint | Internal event id |
| kind | string | Event type (new-order, expiry, sale, cancel, balance-change, approval-change, bootstrap, revalidation, reprice) |
| contract | string | Contract address |
| token\_id | string | Id of the token in the collection |
| order\_id | string | Associated ask id |
| maker | string | Associated ask maker wallet address |
| price | decimal | Associated ask price (native currency) |
| quantity\_remaining | bigint | Associated ask tokens remaining |
| valid\_from | bigint | Associated ask validity start |
| valid\_until | bigint | Associated ask validity expiration |
| source | string | Source of the order (e.g. opensea.io) |
| tx\_hash | string | Associated transaction hash |
| tx\_timestamp | bigint | Associated transaction timestamp |
| created\_at | timestamp | Timestamp the event was recorded |

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/community/reservoir/ask-events)

[Overview](/data-catalog/community/reservoir/overview)[Asks](/data-catalog/community/reservoir/asks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.