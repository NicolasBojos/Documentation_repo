[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Reservoir

Collections

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir

  + [Overview](/data-catalog/community/reservoir/overview)
  + [Ask Events](/data-catalog/community/reservoir/ask-events)
  + [Asks](/data-catalog/community/reservoir/asks)
  + [Attribute Keys](/data-catalog/community/reservoir/attribute-keys)
  + [Attributes](/data-catalog/community/reservoir/attributes)
  + [Bid Events](/data-catalog/community/reservoir/bid-events)
  + [Bids](/data-catalog/community/reservoir/bids)
  + [Collection Floor Ask Events](/data-catalog/community/reservoir/collection-floor-ask-events)
  + [Collection Top Bid Events](/data-catalog/community/reservoir/collection-top-bid-events)
  + [Collections](/data-catalog/community/reservoir/collections)
  + [Sales](/data-catalog/community/reservoir/sales)
  + [Token Attributes](/data-catalog/community/reservoir/token-attributes)
  + [Token Floor Ask Events](/data-catalog/community/reservoir/token-floor-ask-events)
  + [Tokens](/data-catalog/community/reservoir/tokens)
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [reservoir.collections](#reservoir-collections)

Reservoir

# Collections

## [​](#reservoir-collections) **reservoir.collections**

This table contains records with information about each NFT collection.
Query examples can be found here:
<https://dune.com/queries/1302781/2232054>
<https://dune.com/queries/1302788/2232065>

| **Column name** | **Type** | **Description** |  |
| --- | --- | --- | --- |
| id | string | Internal collection id |  |
| slug | string | Collection slug |  |
| name | string | Collection name |  |
| description | string | Collection description |  |
| token\_count | bigint | Id of the token in the collection |  |
| contract | string | Contract address |  |
| day1\_rank | bigint | Ranking in the previous day |  |
| day7\_rank | bigint | Ranking in the previous 7 days |  |
| day30\_rank | bigint | Ranking in the previous 30 days |  |
| all\_time\_rank | bigint | All time ranking |  |
| day1\_volume | decimal | Trade volume in the previous day |  |
| day7\_volume | decimal | Trade volume in the previous 7 days |  |
| day30\_volume | decimal | Trade volume in the previous 30 days |  |
| all\_time\_volume | decimal | All time trade volume |  |
| day1\_volume\_change | double | Trade volume change in the previous day |  |
| day7\_volume\_change | double | Trade volume change in the previous 7 days |  |
| day30\_volume\_change | double | Trade volume change in the previous 30 days |  |
| floor\ask\_value | decimal | Current floor sale price (native currency) |  |
| day1\_floor\_sale\_value | decimal | Floor sale price in the previous day |  |
| day7\_floor\_sale\_value | decimal | Floor sale price 7 days ago |  |
| day30\_floor\_sale\_value | decimal | Floor sale price 30 days ago |  |
| day1\_floor\_sale\_change | double | Floor sale price change from previous day |  |
| day7\_floor\_sale\_change | double | Floor sale price change from 7 days ago |  |
| day30\_floor\_sale\_change | double | Floor sale price change from 30 days ago |  |
| created\_at | timestamp | Timestamp the collection was created |  |
| updated\_at | timestamp | Timestamp the collection was updated |  |

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/community/reservoir/collections)

[Collection Top Bid Events](/data-catalog/community/reservoir/collection-top-bid-events)[Sales](/data-catalog/community/reservoir/sales)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.