[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Reservoir

Token Attributes

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir

  + [Overview](/data-catalog/community/reservoir/overview)
  + [Ask Events](/data-catalog/community/reservoir/ask-events)
  + [Asks](/data-catalog/community/reservoir/asks)
  + [Attribute Keys](/data-catalog/community/reservoir/attribute-keys)
  + [Attributes](/data-catalog/community/reservoir/attributes)
  + [Bid Events](/data-catalog/community/reservoir/bid-events)
  + [Bids](/data-catalog/community/reservoir/bids)
  + [Collection Floor Ask Events](/data-catalog/community/reservoir/collection-floor-ask-events)
  + [Collection Top Bid Events](/data-catalog/community/reservoir/collection-top-bid-events)
  + [Collections](/data-catalog/community/reservoir/collections)
  + [Sales](/data-catalog/community/reservoir/sales)
  + [Token Attributes](/data-catalog/community/reservoir/token-attributes)
  + [Token Floor Ask Events](/data-catalog/community/reservoir/token-floor-ask-events)
  + [Tokens](/data-catalog/community/reservoir/tokens)
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [reservoir.token\_attributes](#reservoir-token-attributes)

Reservoir

# Token Attributes

## [​](#reservoir-token-attributes) **reservoir.token\_attributes**

This table contains records with information about each NFT token attribute.
Query examples can be found here:
<https://dune.com/queries/1302940/2232326>

| **Column name** | **Type** | **Description** |  |
| --- | --- | --- | --- |
| id | bigint | Internal token attribute id |  |
| contract | string | Contract address |  |
| token\_id | string | Id of the token in the collection |  |
| attribute\_id | bigint | Internal attribute id |  |
| collection\_id | string | Internal collection id |  |
| key | string | Attribute name |  |
| value | string | Attribute value |  |
| created\_at | timestamp | Timestamp the token attribute was created |  |
| updated\_at | timestamp | Timestamp the token attribute was updated |  |

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/community/reservoir/token-attributes)

[Sales](/data-catalog/community/reservoir/sales)[Token Floor Ask Events](/data-catalog/community/reservoir/token-floor-ask-events)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.