[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Lens

dune.lens.profile\_follow\_module

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens

  + [Lens Overview](/data-catalog/community/lens/overview)
  + [Namespace Handle](/data-catalog/community/lens/namespace-handle)
  + [Handle Links](/data-catalog/community/lens/namespace-handle-link)
  + [Profile Follower](/data-catalog/community/lens/profile-follower)
  + [Profile Follow Module](/data-catalog/community/lens/profile-follow-module)
  + [Profile Follow Module Record](/data-catalog/community/lens/profile-follow-module-record)
  + [Profile Metadata](/data-catalog/community/lens/profile-metadata)
  + [Profile Record](/data-catalog/community/lens/profile-record)
  + [Publication Metadata](/data-catalog/community/lens/publication-metadata)
  + [Publication Open Action Module](/data-catalog/community/lens/publication-open-action-module)
  + [Publication Open Action Module Acted Record](/data-catalog/community/lens/publication-open-action-module-acted-recorded)
  + [Publication Open Action Module Multi-Recipient](/data-catalog/community/lens/publication-open-action-module-acted-multirecipient)
  + [Publication Reaction](/data-catalog/community/lens/publication-reaction)
  + [Publication Record](/data-catalog/community/lens/publication-record)
  + [Publication Reference Module](/data-catalog/community/lens/publication-reference-module)
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table description](#table-description)
* [Table Sample](#table-sample)

Lens

# dune.lens.profile\_follow\_module

Description of the dune.lens.profile\_follow\_module table on Dune

## [​](#table-description) Table description

This holds any follow module the profile has turned on.

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/community/lens/profile-follow-module)

[Profile Follower](/data-catalog/community/lens/profile-follower)[Profile Follow Module Record](/data-catalog/community/lens/profile-follow-module-record)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.