[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Bring your Data

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Upload](#data-upload)
* [LiveFetch Functions](#livefetch-functions)
* [Adding new blockchains](#adding-new-blockchains)
* [Adding other relevant data](#adding-other-relevant-data)

# Bring your Data

Dune offers several ways to bring your data to the platform.

## [​](#data-upload) Data Upload

You can upload your data to Dune via the API or the UI. This allows you to combine your data with the data available on Dune.

[## Upload data via the User Interface

Upload data via dune.com](/web-app/upload-data)[## Upload data via the API

Programmatically upload data via the API](/api-reference/tables/endpoint/upload)

## [​](#livefetch-functions) LiveFetch Functions

You can also use the LiveFetch functions to fetch data from external APIs directly within your queries. This allows you to combine your data with external data sources in real-time and without having to upload the data to Dune.

[## LiveFetch Functions

Fetch data from external APIs directly within your queries](/query-engine/Functions-and-operators/live-fetch)

## [​](#adding-new-blockchains) Adding new blockchains

If you are a representative of a blockchain you would like to see supported on Dune, please reach out to us. We are always looking to expand our data catalog.

[## Request a new blockchain integration!](https://dune.com/enterprise)

## [​](#adding-other-relevant-data) Adding other relevant data

If you have other relevant web3 data that you would like to see on Dune, please reach out to us. We are always looking to expand our data catalog.
Data in this category could include web3 social, enriched blockchain data, tradfi data, pricing data and more.
A few examples of data we already have in this category are:

* [**farcaster.xyz**](https://www.farcaster.xyz/) data is supplied by [**Neynar**](https://www.neynar.xyz/)
* the [**Lens protocol**](https://lens.xyz) team uploads their data
* [**Snapshot**](https://snapshot.org/#/) team uploads their data
* [**Reservoir**](https://reservoir.api) provides enriched and cleaned NFT trading data
* etc…

The Criteria for adding data in this category is that it should be relevant to the web3 ecosystem and should be of high quality.

[## Request a new data integration!](https://dune.com/enterprise)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/bring-your-own-data)

[Data Freshness](/data-catalog/data-freshness)[Overview](/data-catalog/curated/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.