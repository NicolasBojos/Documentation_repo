[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Bitcoin

bitcoin.transactions

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin

  + [Overview](/data-catalog/bitcoin/overview)
  + [Blocks](/data-catalog/bitcoin/blocks)
  + [Inputs](/data-catalog/bitcoin/inputs)
  + [Outputs](/data-catalog/bitcoin/outputs)
  + [Transactions](/data-catalog/bitcoin/transactions)
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table description](#table-description)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)
* [Struct definitions](#struct-definitions)

Bitcoin

# bitcoin.transactions

Description of the bitcoin.transactions table on Dune

## [​](#table-description) Table description

This table represents the transactions on the Bitcoin blockchain. A transaction is a transfer of Bitcoin value that is broadcast to the network and collected into blocks. A transaction typically references previous transaction outputs as new transaction inputs and dedicates all input Bitcoin values to new outputs. Transactions are not encrypted, so it is possible to browse and view every transaction ever collected into a block.

## [​](#column-descriptions) Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#table-sample) Table Sample

### [​](#struct-definitions) Struct definitions

Within several of these columns is a data type of STRUCT which allows for representing nested hierarchical data and has key-value pairs. It’s similar to a dictionary in python and can be used to group fields together to make them more accessible.
Note that you can work with these columns with the syntax `input[1].witness_data[2]` or `input[3].script_pub_key.address` depending on lengths of arrays within each value. It is an `array(row(map))` type, and while it looks like just an array in the returned table - it is more than that!
**input**

| Field | Data type | Description |
| --- | --- | --- |
| value | double | The number of Satoshis attached to this output |
| height | bigint | The height of the output |
| tx\_id | string | The transaction id of the output that is here used as input |
| output\_number | bigint | The number (index) of the output in transaction `tx_id`’s outputs |
| coinbase | string | The data specified in this transaction, if it was a coinbase transaction |
| sequence | bigint | Sequence number |
| witness\_data | `array<string>` | Array of hex encoded witness data |
| script\_signature | struct | The script signature |
| script\_pub\_key | struct | The script public key |

---

**input.script\_signature**

| Field | Data type | Description |
| --- | --- | --- |
| hex | string | The transaction’s script operations, in hex |
| asm | string | The transaction’s script operations, in symbolic representation |

---

**input.script\_pub\_key**

| Field | Data type | Description |
| --- | --- | --- |
| asm | string | The transaction’s script operations, in symbolic representation |
| desc | string | The transaction’s script operations, in symbolic representation |
| address | string | The transaction’s script operations, in symbolic representation |
| hex | string | The transaction’s script operations, in hex |
| type | string | The address type of the output |

---

**output**

| Field | Data type | Description |
| --- | --- | --- |
| index | bigint | 0-indexed number of an output within a transaction used by a later transaction to refer to that specific output |
| value | double | The number of Satoshis attached to this output |
| script\_pub\_key | struct | The public key |

---

**output.script\_pub\_key**

| Field | Data type | Description |
| --- | --- | --- |
| asm | string | The transaction’s script operations, in symbolic representation |
| hex | string | The transaction’s script operations, in hex |
| address | string | The address the BTC came from |
| type | string | The address type of the output |

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/bitcoin/transactions)

[Outputs](/data-catalog/bitcoin/outputs)[Overview](/data-catalog/fuel/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.