[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Aptos

Aptos data

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos

  + [Overview](/data-catalog/aptos/overview)
  + [Blocks](/data-catalog/aptos/blocks)
  + [Events](/data-catalog/aptos/events)
  + [Move Modules](/data-catalog/aptos/move_modules)
  + [Move Resources](/data-catalog/aptos/move_resources)
  + [Move Table Items](/data-catalog/aptos/move_table_items)
  + [Signatures](/data-catalog/aptos/signatures)
  + [Transactions](/data-catalog/aptos/transactions)
  + [User Transactions](/data-catalog/aptos/user_transactions)
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Available](#data-available)

Aptos

# Aptos data

Aptos is a next-generation blockchain designed for scalability, security, and reliability.

Aptos utilizes the Move programming language, focusing on flexibility, safety, and efficiency in smart contract execution. It employs a ledger model that is built to support highly scalable and reliable decentralized applications and financial infrastructure. Aptos is distinguished by its state-of-the-art consensus protocol, aiming to achieve high transaction throughput without compromising security or decentralization.
You can learn more about Aptos by visiting the [official documentation](https://aptos.dev/).

## [​](#data-available) Data Available

[## Blocks

Represents the collection of transactions in a single block within the Aptos
blockchain.](/data-catalog/aptos/blocks)[## Transactions

Includes all user and system transactions processed by the Aptos network.](/data-catalog/aptos/transactions)[## User Transactions

Specifically tracks transactions initiated by users, including smart
contract interactions.](/data-catalog/aptos/user_transactions)[## Events

Captures events emitted by smart contracts, logging significant actions and
changes.](/data-catalog/aptos/events)[## Move Resources

Details Move resources, representing structured data owned by accounts on
the Aptos blockchain.](/data-catalog/aptos/move_resources)[## Move Modules

Contains metadata and code for Move modules, defining the functionality of
smart contracts.](/data-catalog/aptos/move_modules)[## Move Table Items

Tracks items stored in Move’s table data structures, used for efficient data
access within smart contracts.](/data-catalog/aptos/move_table_items)[## Signatures

Signatures are associated with transactions, which are essential for
security and authentication.](/data-catalog/aptos/signatures)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/aptos/overview)

[NFT Trades](/data-catalog/evm/zora/curated-data/nft/nft-trades)[Blocks](/data-catalog/aptos/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.