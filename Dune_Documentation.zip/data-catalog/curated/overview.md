[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Curated Data

Curated Data Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Overview](#overview)
* [Available Categories](#available-categories)
* [Cross-Chain Coverage](#cross-chain-coverage)
* [Benefits of curated data Tables](#benefits-of-curated-data-tables)
* [Resources](#resources)

Curated Data

# Curated Data Overview

Curated data Tables are the easiest way to gain insights on Dune

## [​](#overview) Overview

Dune and its community are building a collection of curated data tables that make it easier to query and analyze blockchain data. These tables are built using dbt, a tool that allows you to transform data in your warehouse using SQL and Jinja templating. We sometimes refer to these tables as *spells* and the collection of them as *spellbook*.
The curated data tables are built on top of raw data tables and provide a high-level view of the data across multiple blockchain networks. For example, the `dex.trades` table aggregates data from multiple sources to provide a comprehensive view of all trades on decentralized exchanges across EVM networks, while `dex_solana.trades` provides similar coverage for Solana DEXs.
The curated data tables are maintained in the [Spellbook repository](https://github.com/duneanalytics/spellbook) and are available for anyone to use.

## [​](#available-categories) Available Categories

Our curated data is organized by use case to make it easier to find the data you need:

[## DEX Trades

Comprehensive DEX trading data across EVM and Solana networks](/data-catalog/curated/dex-trades/overview)[## NFT Trades

NFT trading, minting, and metadata across multiple blockchains](/data-catalog/curated/nft-trades/overview)[## Token Transfers

Token transfers, balances, and metadata across EVM and Solana](/data-catalog/curated/token-transfers/overview)[## Address Labels

Identify and categorize blockchain addresses](/data-catalog/curated/labels/overview)[## Token Prices

Historical and real-time token pricing data](/data-catalog/curated/prices/overview)

## [​](#cross-chain-coverage) Cross-Chain Coverage

Our curated data covers multiple blockchain ecosystems:

* **EVM Networks**: Ethereum, Arbitrum, Polygon, Base, Optimism, and 40+ other EVM chains
* **Solana**: Comprehensive coverage of Solana DeFi and NFT ecosystems

Here is a non-exhaustive list of some of the curated data tables available in Spellbook:

## [​](#benefits-of-curated-data-tables) Benefits of curated data Tables

Curated data tables provide several benefits:

* **Simplified Queries**: curated data tables make it easier to query and analyze blockchain data by providing a high-level view of the data.
* **Cross-Chain Analysis**: Consistent data models enable easy comparison between different blockchain networks.
* **Consistent Data Models**: The curated data tables follow a consistent data model, making it easier to combine data from different sources.
* **Community Contributions**: The curated data tables are maintained by the Dune community, so anyone can contribute to them and improve the data quality.

## [​](#resources) Resources

[## Spellbook Repo

Go to the dbt github repo with over 400+ contributors. All models live here.](https://github.com/duneanalytics/spellbook)[## Model Docs

Find the native dbt documentation for all models in spellbook.](https://spellbook-docs.dune.com/)[## dbt practices in Spellbook

Docs for contributing to spellbook and dbt best practices.](https://github.com/duneanalytics/spellbook/tree/main/docs)[## Adding to Sector Models

Learn to contribute to sector models like dex.trades and nft.trades tables](https://github.com/duneanalytics/spellbook/blob/main/dbt_subprojects/dex/README.md)[## Adding a token to prices

Learn to add a token to our prices.usd tracking in a PR](https://github.com/duneanalytics/spellbook/blob/main/models/prices/README.md)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/overview)

[Bring your Data](/data-catalog/bring-your-own-data)[Overview](/data-catalog/curated/dex-trades/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.