[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EVM Token Transfers

Token Transfers

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers

  + [Overview](/data-catalog/curated/token-transfers/overview)
  + EVM Token Transfers

    - [Token & NFT Balances](/data-catalog/curated/token-transfers/evm/balances)
    - [Token Transfers](/data-catalog/curated/token-transfers/evm/token-transfers)
    - [ERC20 Token Metadata](/data-catalog/curated/token-transfers/evm/tokens-metadata)
  + Solana Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Utility](#utility)
* [Network Coverage](#network-coverage)
* [Sample Queries](#sample-queries)

EVM Token Transfers

# Token Transfers

Curated and enriched token transfer events across all EVM networks for fungible tokens.

The `tokens.transfers` table contains token transfer events across ERC20 tokens and native tokens for all EVM-compatible networks indexed on Dune. This dataset encompasses:

* Transfer events for ERC20 tokens
* WETH deposits and withdrawals
* Native currency transfers
  + Transaction value transfers
  + Trace value transfers
  + Gas used transfers

Some erc20 tokens and native currencies have non-standard ways of being transferred and might not be included in the transfers table.
You can check the logic for the transfers table [here](https://github.com/duneanalytics/spellbook/tree/main/dbt_subprojects/tokens/models/transfers_and_balances). The level of detail of the transfers table will vary by chain.

### [​](#utility) Utility

The transfers table provides a comprehensive view of token movement across networks, enabling you to:

* Track token flows between addresses
* Analyze transaction volumes and patterns
* Identify significant token movements
* Monitor exchange and DeFi protocol activity

The table contains the following columns:

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

### [​](#network-coverage) Network Coverage

Transfer data is available for the following EVM-compatible networks:

## [​](#sample-queries) Sample Queries

**Query recent token transfers for a specific address**
This query returns the most recent token transfers (both incoming and outgoing) for a specified address:

Copy

Ask AI

```
SELECT
    block_time,
    symbol,
    CASE 
        WHEN "from" = 0x5DD596C901987A2b28C38A9C1DfBf86fFFc15d77 THEN 'Outgoing'
        WHEN "to" = 0x5DD596C901987A2b28C38A9C1DfBf86fFFc15d77 THEN 'Incoming'
    END AS direction,
    amount,
    amount_usd
FROM tokens.transfers
WHERE ("from" = 0x5DD596C901987A2b28C38A9C1DfBf86fFFc15d77 OR "to" = 0x5DD596C901987A2b28C38A9C1DfBf86fFFc15d77)
    AND block_time > now() - interval '30' day
ORDER BY block_time DESC
LIMIT 100

```

**Calculate daily transfer volume for a specific token**
This query calculates the daily transfer volume for a specific ERC20 token.
Please be aware that token volumes are not necessarily indicative of anything. These metric can be misleading if the token is not well-known or if there are a lot of small transfers. Token transfers can be mints, burns, transfers, flashloans and anything in between, trying to read into the data can lead to misleading results.

Copy

Ask AI

```
SELECT
    block_date,
    COUNT(*) AS num_transfers,
    SUM(amount) AS total_amount,
    SUM(amount_usd) AS total_amount_usd
FROM tokens.transfers
WHERE contract_address = 0x1f9840a85d5af5bf1d1762f925bdaddc4201f984
    AND block_time > now() - interval '30' day
    and blockchain = 'ethereum'
GROUP BY 1
ORDER BY 1 DESC

```

**Identify largest transfers in the last 24 hours**
This query finds the largest token transfers by USD value in the last 24 hours:

Copy

Ask AI

```
SELECT
    block_time,
    token_symbol,
    "from",
    "to",
    amount,
    amount_usd
FROM tokens.transfers
WHERE block_time > now() - interval '1' day
    AND amount_usd IS NOT NULL
ORDER BY amount_usd DESC
LIMIT 50

```

**Find the circulating supply of a token over time**
This query calculates the circulating supply of a token over time by summing the amount of tokens in circulation at each time interval.
Please be aware that this won’t work for tokens that have non-standard transfer mechanisms or minting/burning mechanisms.

Copy

Ask AI

```
WITH tx AS (
    SELECT
        DATE_TRUNC('hour', evt_block_time) AS event_hour,
        value / 1e18 AS tokens_delta
    FROM erc20_ethereum.evt_transfer
    WHERE contract_address = 0x5bae9a5d67d1ca5b09b14c91935f635cfbf3b685
      AND "from" = 0x0000000000000000000000000000000000000000

    UNION ALL

    SELECT
        DATE_TRUNC('hour', evt_block_time) AS event_hour,
        -value / 1e18 AS tokens_delta
    FROM erc20_ethereum.evt_transfer
    WHERE contract_address = 0x5bae9a5d67d1ca5b09b14c91935f635cfbf3b685
      AND "to" = 0x0000000000000000000000000000000000000000
),
tx_hourly AS (
    SELECT
        event_hour,
        SUM(tokens_delta) AS net_tokens
    FROM tx
    GROUP BY event_hour
    ORDER BY event_hour DESC
)
SELECT
    event_hour,
    SUM(net_tokens) OVER (ORDER BY event_hour) AS circulating_supply
FROM tx_hourly
ORDER BY event_hour DESC;

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/token-transfers/evm/token-transfers)

[Token & NFT Balances](/data-catalog/curated/token-transfers/evm/balances)[ERC20 Token Metadata](/data-catalog/curated/token-transfers/evm/tokens-metadata)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.