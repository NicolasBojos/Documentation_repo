[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EVM Token Transfers

ERC20 Token Metadata

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers

  + [Overview](/data-catalog/curated/token-transfers/overview)
  + EVM Token Transfers

    - [Token & NFT Balances](/data-catalog/curated/token-transfers/evm/balances)
    - [Token Transfers](/data-catalog/curated/token-transfers/evm/token-transfers)
    - [ERC20 Token Metadata](/data-catalog/curated/token-transfers/evm/tokens-metadata)
  + Solana Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Coverage](#coverage)
* [Data Sources](#data-sources)
* [Utility](#utility)
* [Sample Queries](#sample-queries)

EVM Token Transfers

# ERC20 Token Metadata

Metadata like symbol, name, decimals, and contract address for ERC20 tokens across EVM networks.

The `tokens.erc20` table contains metadata for ERC20 tokens across all EVM-compatible networks indexed on Dune. This dataset provides essential information about ERC20 tokens, including:

* The blockchain on which the token exists
* The contract address of the token
* The token symbol
* The token name
* The number of decimals used by the token

### [​](#coverage) Coverage

This table covers tokens across all EVM chains on Dune. Tokens are automatically detected and included when they meet the following criteria:

* Have emitted ERC20 Transfer events
* Have at least 1 transfer recorded on-chain

New tokens meeting these criteria are added to the table within approximately 1 hour of detection.

### [​](#data-sources) Data Sources

We use [Sim API](https://docs.sim.dune.com/evm/token-info) to retrieve token metadata for all qualifying contracts. For chains not supported on Sim API, we fall back to [DefinedFi](https://docs.defined.fi/reference/token) as our metadata provider.
Native tokens are also included in this dataset, using metadata info from `dune.blockchains`.

### [​](#utility) Utility

The ERC20 metadata table offers valuable information for token analysis and integration, allowing you to:

* Identify tokens across different blockchains
* Retrieve essential token information for calculations and display

The table contains the following columns:

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#sample-queries) Sample Queries

**Query ERC20 tokens on a specific blockchain**
This query returns ERC20 tokens on the Ethereum blockchain:

Copy

Ask AI

```
SELECT
    contract_address,
    symbol,
    decimals
FROM tokens.erc20
WHERE blockchain = 'ethereum'
LIMIT 100

```

**Find tokens with a specific symbol across blockchains**
This query finds all tokens with the symbol “USDC” across different blockchains:

Copy

Ask AI

```
SELECT
    blockchain,
    contract_address,
    symbol,
    decimals
FROM tokens.erc20
WHERE symbol = 'USDC'

```

**List tokens with non-standard decimal places**
This query lists tokens that don’t use the standard 18 decimal places:

Copy

Ask AI

```
SELECT
    blockchain,
    contract_address,
    symbol,
    decimals
FROM tokens.erc20
WHERE decimals != 18
ORDER BY decimals DESC
LIMIT 50

```

**Count tokens by blockchain**
This query shows the distribution of tokens across different blockchains:

Copy

Ask AI

```
SELECT
    blockchain,
    COUNT(*) as token_count
FROM tokens.erc20
GROUP BY blockchain
ORDER BY token_count DESC

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/token-transfers/evm/tokens-metadata)

[Token Transfers](/data-catalog/curated/token-transfers/evm/token-transfers)[Overview](/data-catalog/curated/token-transfers/solana/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.