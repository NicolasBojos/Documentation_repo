[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EVM Token Transfers

Token Balances

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers

  + [Overview](/data-catalog/curated/token-transfers/overview)
  + EVM Token Transfers

    - [Token & NFT Balances](/data-catalog/curated/token-transfers/evm/balances)
    - [Token Transfers](/data-catalog/curated/token-transfers/evm/token-transfers)
    - [ERC20 Token Metadata](/data-catalog/curated/token-transfers/evm/tokens-metadata)
  + Solana Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Utility](#utility)
* [Network Coverage](#network-coverage)
* [Balance Calculation Methodology](#balance-calculation-methodology)
* [Granular balances](#granular-balances)
* [Table Sample](#table-sample)
* [Sample Queries](#sample-queries)
* [Querying for the latest fungible Token Balances for a specific Address](#querying-for-the-latest-fungible-token-balances-for-a-specific-address)
* [Querying for daily fungible Token Balances for a specific Address](#querying-for-daily-fungible-token-balances-for-a-specific-address)
* [Find the top 50 token holders for a specific token](#find-the-top-50-token-holders-for-a-specific-token)

EVM Token Transfers

# Token Balances

Balances for addresses on EVM networks.

This dataset is currently in open beta. We are working on adding more chains and methods to detect balance changes. We are also working on improving the query performance. We currently recommend using the `tokens_<chain>.balances` table for queries.
Mirroring the approach of [this query](https://dune.com/queries/3702725) is currently the fastest way to get started with the token balances dataset.

The `tokens_<chain>.balances_daily` table contains all daily token balances across all addresses and on EVM-compatible networks. This dataset encompasses:

* **Native currency balances** (such as ETH, MATIC)
* **ERC-20 token balances**
* **ERC-721 (NFT) balances**
* **ERC-1155 token balances**

The table contains the following columns:

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

### [​](#utility) Utility

Leveraging the balance tables equips analysts and developers with a foundational dataset for diverse applications, enabling you to:

* **Evaluate token distribution patterns**
* **Identify leading token holders**
* **Examine an address’s token portfolio**
* **Review multi-signature wallet holdings**

and much more, offering a granular view into the dynamics of token economics.

### [​](#network-coverage) Network Coverage

Balances are available for the following EVM-compatible networks:

* Arbitrum
* Avalanche C-Chain
* Base
* Ethereum Mainnet
* Gnosis Chain
* Optimism
* Scroll
* ZkSync

### [​](#balance-calculation-methodology) Balance Calculation Methodology

Our approach to storing balances is the following: We store token balances for each address. This process involves querying the blockchain for the balance of each address at the end of the day. The balance is then stored in the `tokens_<chain>.balances` table, which is updated . For the balance to be queried, the address must have appeared in any of the following tables:

* **For native currencies**: Transactions and traces `to`/`from` addresses, Ethereum-specific withdrawals, and block mining/validator activities.
* **For ERC20**: Analysis is based on token transfer events detailed in the [tokens\_ethereum\_base\_transfers](https://github.com/duneanalytics/spellbook/blob/main/models/_sector/tokens/ethereum/tokens_ethereum_base_transfers.sql). The address balance is updated based on the `to`/`from` addresses in the transfer events. If the token is a non-standard ERC20 token, the balance might not be updated until we detect a standard ERC20 transfer event. Known issues currently include ERC4626 tokens and rebasing tokens like stETH or $ampleforth. We are working on improving the range of balance changes that we detect.
* **For ERC721 and ERC1155**: Inspection of NFT transfer activities via the [nft\_ethereum\_transfers](https://github.com/duneanalytics/spellbook/blob/main/models/_sector/nft/transfers/chains/nft_ethereum_transfers.sql), focusing on the `to`/`from` addresses.

These dependencies on transfer and NFT event tables introduce a delay to balance updates, contingent on the latency inherent in the Spellbook’s processing.
This also means that if an address has not been involved in any of the above activities, its balance will not be updated.
This might be the case for non-standard erc20 contracts that do not emit the `Transfer` event, or for addresses that have not been involved in any transactions or NFT transfers. If there is a specific token that does not emit the `Transfer` event, but has a different event for token transfers, please let us know and we will see if we can include it in our balance calculations.

### [​](#granular-balances) Granular balances

We also provide a more granular view of token balances in the `tokens_<chain>.balances` table, which contains granular balance changes for each address, token combination per block. This table is updated in near real-time and is used to calculate the daily balances. This table is useful for more granular analysis, such as tracking the balance changes of a specific address over time.
However, the `tokens_<chain>.balances` table is very large and is not suitable for querying large time ranges or for querying balances for many addresses at once. For these use cases, the `tokens_<chain>.balances_daily` table is more suitable.
The `tokens_<chain>.balances` table adds a new row every time a balance changes but does not carry the balance forward for every block. Instead, it only creates a new row for a balance change of an address and token combination.

## [​](#table-sample) Table Sample

## [​](#sample-queries) Sample Queries

#### [​](#querying-for-the-latest-fungible-token-balances-for-a-specific-address) Querying for the latest fungible Token Balances for a specific Address

This query will return the latest fungible token balances for the specified address. Fungible tokens refer to erc20 and native tokens. Please keep in mind that the balance table lags behind the real state by approximately 2 hours.

Copy

Ask AI

```
select 
    address
    ,token_symbol as symbol
    ,balance
    ,balance_usd
    ,token_address
from tokens_{{blockchain}}.balances_daily
where address = {{wallet_address}} and day = date_trunc('day', now())
    and (token_standard = 'erc20' or token_standard = 'native')
    and balance_usd > 1
order by balance_usd desc

```

#### [​](#querying-for-daily-fungible-token-balances-for-a-specific-address) Querying for daily fungible Token Balances for a specific Address

This query will return the daily fungible token balances for the specified address over time. Fungible tokens refer to erc20 and native tokens.

Copy

Ask AI

```
select
     b.day
    ,b.token_symbol
    ,b.token_address
    ,b.balance
    ,b.balance_usd
from tokens_{{blockchain}}.balances_daily  b
where address = {{wallet_address}} 
    and (token_standard = 'erc20' or token_standard = 'native')
    and b.day > date_trunc('day',now()) - interval '{{months}}' month
    and balance_usd > 1
order by day desc, balance_usd desc

```

#### [​](#find-the-top-50-token-holders-for-a-specific-token) Find the top 50 token holders for a specific token

This query will return the top 50 token holders for a specific ERC20 token on the Ethereum Mainnet.

Copy

Ask AI

```
WITH RankedBalances AS (
    SELECT
        b.address,
        b.balance,
        ROW_NUMBER() OVER(PARTITION BY b.day ORDER BY b.balance DESC) AS rank
    FROM tokens_ethereum.balances_daily b
    WHERE token_address = 0xbaac2b4491727d78d2b78815144570b9f2fe8899
    AND b.day = date_trunc('day', current_date)
)
SELECT
    address,
    balance
FROM RankedBalances
WHERE rank <= 50;

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/token-transfers/evm/balances)

[Overview](/data-catalog/curated/token-transfers/overview)[Token Transfers](/data-catalog/curated/token-transfers/evm/token-transfers)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.