[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Token Transfers

Token Transfers

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers

  + [Overview](/data-catalog/curated/token-transfers/overview)
  + EVM Token Transfers
  + Solana Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Cross-Chain Token Transfer Coverage](#cross-chain-token-transfer-coverage)
* [Available Datasets](#available-datasets)
* [EVM Token Transfers](#evm-token-transfers)
* [Solana Token Transfers](#solana-token-transfers)
* [Key Features](#key-features)
* [Sample Cross-Chain Analysis](#sample-cross-chain-analysis)

Token Transfers

# Token Transfers

Comprehensive token and asset tracking across multiple blockchain networks

Blockchain networks have become popular platforms for creating, managing, and trading digital assets. These assets are often represented as tokens, which can be transferred between addresses and owned by users. Dune provides comprehensive asset tracking capabilities across multiple blockchain networks through curated tables that simplify the process of monitoring and analyzing token transfers, balances, and metadata across both EVM and Solana ecosystems.

## [​](#cross-chain-token-transfer-coverage) Cross-Chain Token Transfer Coverage

Our token transfer data covers multiple blockchain ecosystems:

* **EVM Networks**: Ethereum, Arbitrum, Polygon, Base, Optimism, and 40+ other EVM chains
* **Solana**: Comprehensive coverage of SPL tokens and native SOL transfers

## [​](#available-datasets) Available Datasets

### [​](#evm-token-transfers) EVM Token Transfers

[## Token Transfers

Transfer events for ERC20 tokens and native currencies on EVM networks](/data-catalog/curated/token-transfers/evm/token-transfers)[## NFT Transfers

Transfer events for ERC721 and ERC1155 tokens on EVM networks](/data-catalog/curated/nft-trades/evm/nft-transfers)[## Balances

Current token balances held by addresses on EVM networks](/data-catalog/curated/token-transfers/evm/balances)[## Token Metadata

Comprehensive metadata for ERC20 tokens including name, symbol, decimals](/data-catalog/curated/token-transfers/evm/tokens-metadata)[## NFT Metadata

Metadata and attributes for ERC721 and ERC1155 tokens](/data-catalog/curated/nft-trades/evm/nft-metadata)

### [​](#solana-token-transfers) Solana Token Transfers

[## Token Accounts

Information about token accounts on the Solana blockchain](/data-catalog/curated/token-transfers/solana/solana-token-accounts)[## Token Transfers

Transfer events for SPL tokens and native SOL on Solana](/data-catalog/curated/token-transfers/solana/solana-token-transfers)[## Token Metadata

Comprehensive metadata for Solana SPL tokens](/data-catalog/curated/token-transfers/solana/solana-token-metadata)

## [​](#key-features) Key Features

* **Multi-Chain Coverage**: Track token transfers across EVM and Solana ecosystems
* **Standardized Schema**: Consistent data structure for cross-chain analysis
* **Real-time Balances**: Current token holdings and historical balance changes
* **Comprehensive Metadata**: Token names, symbols, decimals, and additional attributes
* **Transfer Analytics**: Detailed transfer events with sender, receiver, and amounts
* **Real-time Updates**: Data is updated continuously as new blocks are processed

## [​](#sample-cross-chain-analysis) Sample Cross-Chain Analysis

Compare token transfer activity across different blockchain networks:

Copy

Ask AI

```
-- EVM token transfers
SELECT 
    'EVM' as ecosystem,
    blockchain,
    DATE_TRUNC('day', block_time) as date,
    COUNT(*) as num_transfers,
    COUNT(DISTINCT from_address) as unique_senders
FROM tokens.transfers
WHERE block_time >= NOW() - INTERVAL '30' day
GROUP BY 1, 2, 3

UNION ALL

-- Solana token transfers
SELECT 
    'Solana' as ecosystem,
    'solana' as blockchain,
    DATE_TRUNC('day', block_time) as date,
    COUNT(*) as num_transfers,
    COUNT(DISTINCT from_address) as unique_senders
FROM solana.token_transfers
WHERE block_time >= NOW() - INTERVAL '30' day
GROUP BY 1, 2, 3

ORDER BY date DESC, num_transfers DESC

```

These datasets enable users to perform a wide range of analyses across multiple blockchain networks, providing valuable insights into the dynamics of digital assets across various blockchain ecosystems.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/token-transfers/overview)

[Solana DEX Trades](/data-catalog/curated/dex-trades/solana/solana-dex-trades)[Token & NFT Balances](/data-catalog/curated/token-transfers/evm/balances)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.