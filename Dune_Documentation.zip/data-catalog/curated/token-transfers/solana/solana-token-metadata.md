[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Solana Token Transfers

Solana Fungible Token Metadata

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers

  + [Overview](/data-catalog/curated/token-transfers/overview)
  + EVM Token Transfers
  + Solana Token Transfers

    - [Overview](/data-catalog/curated/token-transfers/solana/overview)
    - [Token Accounts](/data-catalog/curated/token-transfers/solana/solana-token-accounts)
    - [Token Metadata](/data-catalog/curated/token-transfers/solana/solana-token-metadata)
    - [Token Transfers](/data-catalog/curated/token-transfers/solana/solana-token-transfers)
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Utility](#utility)
* [Network Coverage](#network-coverage)
* [Sample Queries](#sample-queries)

Solana Token Transfers

# Solana Fungible Token Metadata

Metadata for fungible tokens on the Solana blockchain.

The `tokens_solana.fungible` table contains metadata for fungible tokens on the Solana blockchain indexed on Dune. This dataset provides essential information about Solana tokens, including:

* The token mint address
* The token name and symbol
* The number of decimals used by the token
* Additional metadata such as token URI and creation details

### [​](#utility) Utility

The Solana fungible token metadata table offers valuable information for token analysis and integration, allowing you to:

* Identify tokens on the Solana blockchain
* Retrieve essential token information for calculations and display
* Access additional metadata for more comprehensive token analysis

The table contains the following columns:

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

### [​](#network-coverage) Network Coverage

This table covers fungible token metadata for the Solana blockchain.

## [​](#sample-queries) Sample Queries

**Query Solana fungible tokens**
This query returns fungible tokens on the Solana blockchain:

Copy

Ask AI

```
SELECT
    token_mint_address,
    symbol,
    name,
    decimals
FROM tokens_solana.fungible
LIMIT 100

```

**Find tokens with a specific symbol**
This query finds all tokens with the symbol “USDC” on Solana:

Copy

Ask AI

```
SELECT
    token_mint_address,
    symbol,
    name,
    decimals,
    created_at
FROM tokens_solana.fungible
WHERE symbol = 'USDC'

```

**List tokens with non-standard decimal places**
This query lists tokens that don’t use the standard 9 decimal places on Solana:

Copy

Ask AI

```
SELECT
    token_mint_address,
    symbol,
    name,
    decimals
FROM tokens_solana.fungible
WHERE decimals != 9
ORDER BY decimals DESC
LIMIT 50

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/token-transfers/solana/solana-token-metadata)

[Token Accounts](/data-catalog/curated/token-transfers/solana/solana-token-accounts)[Token Transfers](/data-catalog/curated/token-transfers/solana/solana-token-transfers)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.