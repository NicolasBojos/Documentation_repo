[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Solana Token Transfers

Solana Token Accounts

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers

  + [Overview](/data-catalog/curated/token-transfers/overview)
  + EVM Token Transfers
  + Solana Token Transfers

    - [Overview](/data-catalog/curated/token-transfers/solana/overview)
    - [Token Accounts](/data-catalog/curated/token-transfers/solana/solana-token-accounts)
    - [Token Metadata](/data-catalog/curated/token-transfers/solana/solana-token-metadata)
    - [Token Transfers](/data-catalog/curated/token-transfers/solana/solana-token-transfers)
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Utility](#utility)
* [Sample Query](#sample-query)

Solana Token Transfers

# Solana Token Accounts

Information about token accounts on the Solana blockchain.

The `solana_utils.token_accounts` table contains information about token accounts on the Solana blockchain. Token accounts are used to hold balances of specific tokens for Solana wallets.
This table provides essential data about token accounts, including:

* The token account address
* The owner of the token balance
* The mint address of the token
* The type of account (e.g., associated token account or regular token account)

### [​](#utility) Utility

The Solana token accounts table is useful for:

* Tracking token balances for specific wallets
* Analyzing the distribution of token holdings
* Identifying associated token accounts for wallets
* Understanding the relationship between token mints and token accounts

This table can be joined with other Solana tables to provide rich insights into token ownership and transfers on the Solana blockchain.

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#sample-query) Sample Query

**Query token accounts for a specific wallet**
This query returns all token accounts associated with a specific wallet address:

Copy

Ask AI

```
SELECT
    address AS token_account_address,
    token_balance_owner AS wallet_address,
    token_mint_address,
    account_type
FROM solana_utils.token_accounts
WHERE token_balance_owner = 'FG4Y3yX4AAchp1HvNZ7LfzFTewF2f6nDoMDCohTFrdpk'
LIMIT 10

```

This query will show you the token accounts owned by the specified wallet, including the specific token mint addresses and account types.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/token-transfers/solana/solana-token-accounts)

[Overview](/data-catalog/curated/token-transfers/solana/overview)[Token Metadata](/data-catalog/curated/token-transfers/solana/solana-token-metadata)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.