[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EVM DEX

dex.sandwiches

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades

  + [Overview](/data-catalog/curated/dex-trades/overview)
  + EVM DEX

    - [DEX Trades](/data-catalog/curated/dex-trades/evm/dex-trades)
    - [Aggregator Trades](/data-catalog/curated/dex-trades/evm/dex-aggregator-trades)
    - [Sandwich Victims](/data-catalog/curated/dex-trades/evm/dex-sandwiched)
    - [Sandwich Attacks](/data-catalog/curated/dex-trades/evm/dex-sandwiches)
  + Solana DEX
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Functional Overview](#functional-overview)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)
* [Examples](#examples)
* [Related Tables](#related-tables)

EVM DEX

# dex.sandwiches

The `dex.sandwiches` table captures detailed data on the outer trades of sandwich attacks in decentralized exchanges (DEXs), recording front-running and back-running trades across various EVM networks.

## [​](#table-description) Table Description

The `dex.sandwiches` table captures detailed data on the outer trades of sandwich attacks executed via decentralized exchanges (DEXs). This table records the trades that constitute the “bread” of the sandwich attack, which can include both front-running and back-running trades, as well as more complex patterns. It provides a comprehensive view of sandwich attack patterns across various EVM networks.

## [​](#functional-overview) Functional Overview

The `dex.sandwiches` table provides an in-depth view of the outer trades in sandwich attacks on decentralized exchanges. A sandwich attack typically occurs when a searcher spots a pending transaction in the mempool, quickly executes a trade before it (front-running), and then immediately after it (back-running) to profit from the price movement caused by the victim’s trade.
However, this table also captures more complex sandwich attack patterns. For example:
bot1: ETH>USDC
victim1: USDC>ETH
bot1: USDC>ETH
victim2: ETH>USDC
bot1: ETH>USDC
In this scenario, the bot executes trades on both sides of the liquidity pool, sandwiching multiple victim trades in a single sequence.
This table includes entries for all bot trades involved in these attack patterns.
Note that the victim trades sandwiched between these outer trades are captured in a separate table, `dex.sandwiched`.
This detailed approach allows for granular analysis of sandwich attack patterns, enabling users to:

* **Identify Sandwich Attacks**: Easily spot instances of sandwich attacks across different DEXs and networks, including complex multi-trade patterns.
* **Analyze Attack Patterns**: Understand the frequency, size, and potential profitability of sandwich attacks, including sophisticated strategies that target multiple victims in a single sequence.
* **Monitor Market Manipulation**: Gain insights into various forms of market manipulation across different DEXs and EVM networks.

By providing comprehensive details of the trades involved in sandwich attacks, the `dex.sandwiches` table supports advanced analytics and research into DEX trading behavior, market manipulation, and potential areas for improved trade execution or protocol design.

## [​](#column-descriptions) Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#table-sample) Table Sample

## [​](#examples) Examples

The following query demonstrates how to use the dex.sandwiches table to calculate the total volume of sandwich attack trades on a weekly basis.

## [​](#related-tables) Related Tables

* `dex.sandwiched`: This complementary table captures the victim trades that are sandwiched between the trades recorded in `dex.sandwiches`.
* `dex.trades`: This table captures all trades and is the basis for the `dex.sandwiches` table.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/dex-trades/evm/dex-sandwiches)

[Sandwich Victims](/data-catalog/curated/dex-trades/evm/dex-sandwiched)[Overview](/data-catalog/curated/dex-trades/solana/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.