[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EVM DEX

dex\_aggregator.trades

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades

  + [Overview](/data-catalog/curated/dex-trades/overview)
  + EVM DEX

    - [DEX Trades](/data-catalog/curated/dex-trades/evm/dex-trades)
    - [Aggregator Trades](/data-catalog/curated/dex-trades/evm/dex-aggregator-trades)
    - [Sandwich Victims](/data-catalog/curated/dex-trades/evm/dex-sandwiched)
    - [Sandwich Attacks](/data-catalog/curated/dex-trades/evm/dex-sandwiches)
  + Solana DEX
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Functional Overview](#functional-overview)
* [Coverage](#coverage)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)

EVM DEX

# dex\_aggregator.trades

The `dex_aggregator.trades` table captures data on actions taken on aggregators - recording all events across various aggregators and blockchains.

This table stores data on aggregator trades across protocols...

... and chains

## [​](#table-description) Table Description

The `dex_aggregator.trades` table captures high-level trade data executed via decentralized exchange (DEX) aggregators. These aggregators aggregate liquidity from multiple DEXs to provide users with the best possible trade execution. Unlike the `dex.trades` table, which records each intermediary step of a trade, `dex_aggregator.trades` condenses the trade data to reflect the user’s intended trade, presenting it as a single entry.

## [​](#functional-overview) Functional Overview

Users can expect the `dex_aggregator.trades` table to provide a high-level view of DEX trades facilitated by aggregators. This table simplifies trade records by showing a single entry for trades that may involve multiple DEXs and liquidity pools.  
For instance, a user might initiate a trade to swap USDC for PEPE via a DEX aggregator. The aggregator might route this trade through several liquidity pools such as WETH-USDC and WETH-PEPE, but `dex_aggregator.trades` will record it as a single USDC -> PEPE trade.
Complimentary to `dex_aggregator.trades` is the `dex.trades` table, where detailed trade executions are recorded. This table captures the granular steps of each trade, including interactions with different liquidity pools. The volume routed through aggregators is also recorded in the `dex.trades` table. One row in `dex_aggregator.trades` corresponds to one or more rows in `dex.trades`, providing a comprehensive view of the detailed execution path that aggregated trades take.

## [​](#coverage) Coverage

The table covers the following decentralized exchanges and their versions:

## [​](#column-descriptions) Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/dex-trades/evm/dex-aggregator-trades)

[DEX Trades](/data-catalog/curated/dex-trades/evm/dex-trades)[Sandwich Victims](/data-catalog/curated/dex-trades/evm/dex-sandwiched)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.