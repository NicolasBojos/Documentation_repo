[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EVM DEX

dex.trades

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades

  + [Overview](/data-catalog/curated/dex-trades/overview)
  + EVM DEX

    - [DEX Trades](/data-catalog/curated/dex-trades/evm/dex-trades)
    - [Aggregator Trades](/data-catalog/curated/dex-trades/evm/dex-aggregator-trades)
    - [Sandwich Victims](/data-catalog/curated/dex-trades/evm/dex-sandwiched)
    - [Sandwich Attacks](/data-catalog/curated/dex-trades/evm/dex-sandwiches)
  + Solana DEX
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Functional Overview](#functional-overview)
* [Coverage](#coverage)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)
* [Examples](#examples)

EVM DEX

# dex.trades

The `dex.trades` table captures detailed data on decentralized exchange (DEX) trades, recording all raw trade events across various protocols and blockchains.

This table stores data on dex trades across protocols...

... and chains

## [​](#table-description) Table Description

The `dex.trades` table captures detailed data on trades executed via decentralized exchanges (DEXs). This table captures all raw trade events that happen across all liqudity pools. It provides a comprehensive view of the entire trade execution process, detailing the specific paths and liquidity sources utilized.

## [​](#functional-overview) Functional Overview

The `dex.trades` table provides an in-depth view of trades on decentralized exchanges like uniswap or curve. This table includes entries for each segment of a trade that passes through different liquidity pools, as well as single-step trades. For example, a user may initiate a trade to swap USDC for PEPE. If this trade is executed through multiple liquidity pools, such as USDC-WETH and WETH-PEPE, the `dex.trades` table will record each segment of the trade as a separate entry. Conversely, a single-step trade, such as directly swapping USDC for ETH, will be recorded as a single entry.
This detailed approach allows for granular analysis of trade execution paths, enabling users to:

* **Analyze Liquidity Sources**: Understand which liquidity pools are used and how they interact in both single-step and multi-step trades.
* **Track Trade Execution Paths**: Follow the exact route a trade takes across different DEXs and liquidity pools.
* **Assess Slippage and Execution Quality**: Evaluate the impact of each step on the overall trade execution, including slippage and price changes.
* **Monitor Market Dynamics**: Gain insights into the behavior and dynamics of different liquidity pools and DEXs over time.

By providing comprehensive trade details, the `dex.trades` table supports advanced analytics and research into DEX trading behavior and liquidity management.
Complimentary tables include `dex_aggregator.trades`, in which trade-intents that are routed through aggregators are recorded. The volume routed through aggregators is also recorded in the dex.trades table, one row in dex\_aggregator trades corresponds to one or more rows in dex.trades.

## [​](#coverage) Coverage

The table covers the following decentralized exchanges and their versions:

## [​](#column-descriptions) Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#table-sample) Table Sample

## [​](#examples) Examples

The following query demonstrates how to use the dex.trades table to calculate the total volume of trades on a weekly basis.

Copy

Ask AI

```
SELECT
  blockchain,
  DATE_TRUNC('week', block_time),
  SUM(CAST(amount_usd AS DOUBLE)) AS usd_volume
FROM
  dex."trades" AS t
WHERE
 block_time > NOW() - INTERVAL '365' day
GROUP BY 1,2

```

[## Dex Dashboard

For more examples of how to use the `dex.trades` table, check out this dashboard.](https://dune.com/dune/dex-metrics)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/dex-trades/evm/dex-trades)

[Overview](/data-catalog/curated/dex-trades/overview)[Aggregator Trades](/data-catalog/curated/dex-trades/evm/dex-aggregator-trades)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.