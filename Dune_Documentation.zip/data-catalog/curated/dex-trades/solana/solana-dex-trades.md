[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Solana DEX

dex\_solana.trades

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades

  + [Overview](/data-catalog/curated/dex-trades/overview)
  + EVM DEX
  + Solana DEX

    - [Overview](/data-catalog/curated/dex-trades/solana/overview)
    - [Jupiter Aggregator Swaps](/data-catalog/curated/dex-trades/solana/jupiter-aggregator-trades)
    - [Solana DEX Trades](/data-catalog/curated/dex-trades/solana/solana-dex-trades)
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Functional Overview](#functional-overview)
* [Coverage](#coverage)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)
* [Examples](#examples)

Solana DEX

# dex\_solana.trades

The `dex_solana.trades` table captures detailed data on decentralized exchange (DEX) trades on the Solana blockchain, recording all raw trade events across various protocols.

## [​](#table-description) Table Description

The `dex_solana.trades` table captures detailed data on trades executed via decentralized exchanges (DEXs) on the Solana blockchain. This table records all raw trade events that occur across all liquidity pools on Solana DEXs, providing a comprehensive view of the entire trade execution process and detailing the specific paths and liquidity sources utilized.

## [​](#functional-overview) Functional Overview

The `dex_solana.trades` table provides an in-depth view of trades on Solana-based decentralized exchanges like Raydium, Orca, or Serum. This table includes entries for each segment of a trade that passes through different liquidity pools, as well as single-step trades. For example, a user may initiate a trade to swap USDC for RAY. If this trade is executed through multiple liquidity pools, such as USDC-SOL and SOL-RAY, the `dex_solana.trades` table will record each segment of the trade as a separate entry. Conversely, a single-step trade, such as directly swapping USDC for SOL, will be recorded as a single entry.
This detailed approach allows for granular analysis of trade execution paths on Solana, enabling users to:

* **Analyze Liquidity Sources**: Understand which liquidity pools are used and how they interact in both single-step and multi-step trades on Solana DEXs.
* **Track Trade Execution Paths**: Follow the exact route a trade takes across different Solana DEXs and liquidity pools.
* **Assess Slippage and Execution Quality**: Evaluate the impact of each step on the overall trade execution, including slippage and price changes in the Solana ecosystem.
* **Monitor Market Dynamics**: Gain insights into the behavior and dynamics of different liquidity pools and DEXs over time on the Solana blockchain.

By providing comprehensive trade details, the `dex_solana.trades` table supports advanced analytics and research into DEX trading behavior and liquidity management specific to the Solana ecosystem.

## [​](#coverage) Coverage

## [​](#column-descriptions) Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#table-sample) Table Sample

## [​](#examples) Examples

The following query demonstrates how to use the dex\_solana.trades table to calculate the total volume of trades on a weekly basis for Solana DEXs.

Copy

Ask AI

```
SELECT
  DATE_TRUNC('week', block_time) AS week,
  SUM(CAST(amount_usd AS DOUBLE)) AS usd_volume
FROM
  dex_solana.trades
WHERE
  block_time > NOW() - INTERVAL '365' day
GROUP BY 1
ORDER BY 1

```

[## DEX Dashboard

For more examples of how to use the `dex_solana.trades` table, check out this dashboard.](https://dune.com/hagaetc/dex-metrics)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/dex-trades/solana/solana-dex-trades)

[Jupiter Aggregator Swaps](/data-catalog/curated/dex-trades/solana/jupiter-aggregator-trades)[Overview](/data-catalog/curated/token-transfers/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.