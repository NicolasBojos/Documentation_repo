[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Solana DEX

Trading

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades

  + [Overview](/data-catalog/curated/dex-trades/overview)
  + EVM DEX
  + Solana DEX

    - [Overview](/data-catalog/curated/dex-trades/solana/overview)
    - [Jupiter Aggregator Swaps](/data-catalog/curated/dex-trades/solana/jupiter-aggregator-trades)
    - [Solana DEX Trades](/data-catalog/curated/dex-trades/solana/solana-dex-trades)
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Tables](#tables)
* [Key Features](#key-features)
* [Common Use Cases](#common-use-cases)
* [Sample Query](#sample-query)

Solana DEX

# Trading

Analyzing trading activity across Solana’s decentralized exchanges.

The Solana blockchain hosts various decentralized exchanges (DEXs) and trading protocols that facilitate token swaps and trading activities. Dune provides comprehensive trading data through prepared tables that capture trades across different DEX protocols and aggregators on the Solana network.

## [​](#tables) Tables

[## DEX Trades

Detailed trade data across Solana DEX protocols](/data-catalog/curated/dex-trades/solana/solana-dex-trades)[## Jupiter Aggregator

Trades executed through the Jupiter aggregator](/data-catalog/curated/dex-trades/solana/jupiter-aggregator-trades)

## [​](#key-features) Key Features

The trading tables provide essential data for analyzing Solana’s DEX ecosystem:

* Comprehensive coverage of major DEX protocols
* Detailed trade execution data including amounts, prices, and USD values
* Aggregator-specific data for Jupiter trades
* Transaction and block details for each trade

## [​](#common-use-cases) Common Use Cases

These datasets enable various types of trading analysis:

* Track trading volume across different DEX protocols
* Monitor market activity for specific token pairs
* Analyze price impact and slippage in trades
* Compare performance between different DEXs and aggregators
* Identify trading patterns and trends

## [​](#sample-query) Sample Query

Here’s a simple query to get started analyzing DEX trading volume:

Copy

Ask AI

```
SELECT 
    DATE_TRUNC('day', block_time) as date,
    project,
    COUNT(*) as num_trades,
    SUM(amount_usd) as volume_usd
FROM dex_solana.trades
WHERE block_time >= NOW() - INTERVAL '30' day
GROUP BY 1, 2
ORDER BY 1 DESC, 4 DESC

```

These datasets provide valuable insights into trading activity across the Solana ecosystem, enabling users to understand market dynamics and analyze trading patterns on the network.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/dex-trades/solana/overview)

[Sandwich Attacks](/data-catalog/curated/dex-trades/evm/dex-sandwiches)[Jupiter Aggregator Swaps](/data-catalog/curated/dex-trades/solana/jupiter-aggregator-trades)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.