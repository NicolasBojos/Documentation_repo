[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Solana DEX

jupiter\_solana.aggregator\_swaps

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades

  + [Overview](/data-catalog/curated/dex-trades/overview)
  + EVM DEX
  + Solana DEX

    - [Overview](/data-catalog/curated/dex-trades/solana/overview)
    - [Jupiter Aggregator Swaps](/data-catalog/curated/dex-trades/solana/jupiter-aggregator-trades)
    - [Solana DEX Trades](/data-catalog/curated/dex-trades/solana/solana-dex-trades)
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Functional Overview](#functional-overview)
* [Coverage](#coverage)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)

Solana DEX

# jupiter\_solana.aggregator\_swaps

The `jupiter_solana.aggregator_swaps` table captures data on trades executed through the Jupiter aggregator on Solana.

## [​](#table-description) Table Description

The `jupiter_solana.aggregator_swaps` table captures high-level trade data executed via the Jupiter decentralized exchange (DEX) aggregator on Solana. Jupiter is the most important and only relevant aggregator on Solana, providing users with the best possible trade execution by aggregating liquidity from multiple DEXs.

## [​](#functional-overview) Functional Overview

Users can expect the `jupiter_solana.aggregator_swaps` table to provide a comprehensive view of DEX trades facilitated by Jupiter on Solana. This table records each trade as a single entry, showing the user’s intended swap from input token to output token.
For instance, a user might initiate a trade to swap USDC for SOL via Jupiter. The aggregator might route this trade through several liquidity pools, but `jupiter_solana.aggregator_swaps` will record it as a single USDC -> SOL trade, including details such as the amounts, USD values, and the specific AMM used for the swap.

## [​](#coverage) Coverage

This table covers all trades executed through the Jupiter aggregator on Solana, which includes liquidity from various Solana-based DEXs and AMMs.

## [​](#column-descriptions) Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/dex-trades/solana/jupiter-aggregator-trades)

[Overview](/data-catalog/curated/dex-trades/solana/overview)[Solana DEX Trades](/data-catalog/curated/dex-trades/solana/solana-dex-trades)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.