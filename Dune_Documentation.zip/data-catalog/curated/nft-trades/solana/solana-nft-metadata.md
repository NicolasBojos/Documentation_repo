[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Solana NFT

Solana NFT Metadata

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

  + [Overview](/data-catalog/curated/nft-trades/overview)
  + EVM NFT
  + Solana NFT

    - [NFT Metadata](/data-catalog/curated/nft-trades/solana/solana-nft-metadata)
    - [Solana NFT Transfers](/data-catalog/curated/nft-trades/solana/solana-nft-transfers)

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Utility](#utility)
* [Network Coverage](#network-coverage)
* [Sample Queries](#sample-queries)

Solana NFT

# Solana NFT Metadata

Metadata for non-fungible tokens (NFTs) on the Solana blockchain.

The `tokens_solana.nft` table contains metadata for non-fungible tokens (NFTs) on the Solana blockchain indexed on Dune. This dataset provides essential information about Solana NFTs, including:

* The NFT mint address and associated accounts
* Token details such as name, symbol, and URI
* Creator and collection information
* Transaction details of the NFT creation

### [​](#utility) Utility

The Solana NFT metadata table offers valuable information for NFT analysis and integration, allowing you to:

* Identify and track NFTs on the Solana blockchain
* Retrieve essential NFT information for display and analysis
* Access creator and collection data for comprehensive NFT insights

The table contains the following columns:

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

### [​](#network-coverage) Network Coverage

This table covers NFT metadata for the Solana blockchain.

## [​](#sample-queries) Sample Queries

**Query Solana NFTs**
This query returns NFTs on the Solana blockchain:

Copy

Ask AI

```
SELECT
    account_mint,
    token_name,
    token_symbol,
    token_uri
FROM tokens_solana.nft
LIMIT 100

```

**Find NFTs from a specific collection**
This query finds all NFTs from a specific collection on Solana:

Copy

Ask AI

```
SELECT
    account_mint,
    token_name,
    token_symbol,
    token_uri
FROM tokens_solana.nft
WHERE collection_mint = 'your_collection_mint_address_here'
LIMIT 50

```

**List NFTs by a specific creator**
This query lists NFTs created by a specific verified creator on Solana:

Copy

Ask AI

```
SELECT
    account_mint,
    token_name,
    token_symbol,
    token_uri,
    call_block_time
FROM tokens_solana.nft
WHERE verified_creator = 'your_creator_address_here'
ORDER BY call_block_time DESC
LIMIT 50

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/nft-trades/solana/solana-nft-metadata)

[NFT Transfers](/data-catalog/curated/nft-trades/evm/nft-transfers)[Solana NFT Transfers](/data-catalog/curated/nft-trades/solana/solana-nft-transfers)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.