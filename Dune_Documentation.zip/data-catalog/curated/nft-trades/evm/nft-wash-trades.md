[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

EVM NFT

nft.wash\_trades

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

  + [Overview](/data-catalog/curated/nft-trades/overview)
  + EVM NFT

    - [NFT Trades](/data-catalog/curated/nft-trades/evm/nft-trades)
    - [NFT Mints](/data-catalog/curated/nft-trades/evm/nft-mints)
    - [NFT Wash Trades](/data-catalog/curated/nft-trades/evm/nft-wash-trades)
    - [NFT Metadata](/data-catalog/curated/nft-trades/evm/nft-metadata)
    - [NFT Transfers](/data-catalog/curated/nft-trades/evm/nft-transfers)
  + Solana NFT

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Usage](#usage)
* [Coverage](#coverage)
* [Mechanism](#mechanism)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)

EVM NFT

# nft.wash\_trades

Dataset for identifying and analyzing potential wash trading activities in NFT transactions across various marketplaces and blockchains

## [​](#table-description) Table Description

The nft.wash\_trades table on Dune is crucial for identifying and analyzing potential wash trading activities in Non-Fungible Token (NFT) transactions across various marketplaces. It provides insights into the authenticity of NFT trades and helps in understanding market manipulation within the NFT space.

## [​](#usage) Usage

The nft.wash\_trades table serves as an essential tool for analyzing the integrity of NFT market activities. It offers a detailed view of each NFT transaction, including data points such as blockchain, project, buyer and seller addresses, and various filters to detect potential wash trades. This table allows analysts to identify suspicious trading patterns, assess the prevalence of wash trading in different NFT projects, and gain insights into the overall health and authenticity of the NFT market.

## [​](#coverage) Coverage

The `nft.wash_trades` table is maintained by Dune and its community of contributors. We strive to ensure the data is as accurate and up-to-date as possible. However, Dune does not guarantee the accuracy or completeness of the data provided. The table covers various blockchains and NFT projects, with a focus on identifying potential wash trading activities.

## [​](#mechanism) Mechanism

The nft.wash\_trades table employs a multi-faceted approach to identify potential wash trades:

1. Basic Trade Information: Each entry includes details such as blockchain, project, NFT contract address, token ID, buyer, seller, and transaction specifics.
2. Funding Source Analysis: The table tracks the first funding sources for both buyers and sellers (buyer\_first\_funded\_by, seller\_first\_funded\_by) to identify potential connections between trading parties.
3. Wash Trade Filters: Several filters are applied to flag suspicious activities:
   * filter\_1\_same\_buyer\_seller: Identifies trades where the buyer and seller are the same.
   * filter\_2\_back\_and\_forth\_trade: Detects repetitive trading between the same parties.
   * filter\_3\_bought\_or\_sold\_3x: Flags NFTs that have been traded frequently in a short period.
   * filter\_4\_first\_funded\_by\_same\_wallet: Identifies trades where both parties were initially funded by the same wallet.
   * filter\_5\_flashloan: Detects trades potentially facilitated by flash loans.
4. Wash Trade Classification: The is\_wash\_trade column provides a final verdict on whether a trade is considered a wash trade based on the applied filters.

This mechanism allows for a comprehensive analysis of NFT trades, helping to distinguish genuine market activity from potential manipulation.

## [​](#column-descriptions) Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/nft-trades/evm/nft-wash-trades)

[NFT Mints](/data-catalog/curated/nft-trades/evm/nft-mints)[NFT Metadata](/data-catalog/curated/nft-trades/evm/nft-metadata)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.