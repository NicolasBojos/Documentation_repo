[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Prices

Daily Prices

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices

  + [Prices](/data-catalog/curated/prices/overview)
  + [Minute Prices](/data-catalog/curated/prices/prices_minute)
  + [Hourly Prices](/data-catalog/curated/prices/prices_hour)
  + [Daily Prices](/data-catalog/curated/prices/prices_day)
  + [USD Prices (Legacy)](/data-catalog/curated/prices/prices_usd)
  + [Latest Prices](/data-catalog/curated/prices/prices_latest)
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [prices.day](#prices-day)
* [Overview](#overview)
* [Table Schema](#table-schema)
* [Implementation Details](#implementation-details)
* [Usage](#usage)
* [Latency and Update Frequency](#latency-and-update-frequency)
* [Usage Examples](#usage-examples)
* [Get ETH price history for the last month:](#get-eth-price-history-for-the-last-month%3A)
* [Calculate monthly average price for multiple tokens:](#calculate-monthly-average-price-for-multiple-tokens%3A)
* [Get native token price using dune.blockchains:](#get-native-token-price-using-dune-blockchains%3A)
* [Data Quality Notes](#data-quality-notes)

Prices

# Daily Prices

Historical daily price data for tokens across all supported blockchains, aggregated at 00:00 UTC

# [​](#prices-day) prices.day

## [​](#overview) Overview

The `prices.day` table provides daily token price data across all supported blockchains. It contains the last known price for each day, ensuring a continuous time series for price analysis.

## [​](#table-schema) Table Schema

| Column | Type | Description |
| --- | --- | --- |
| blockchain | varchar | Blockchain identifier (e.g., ‘ethereum’, ‘arbitrum’) |
| contract\_address | varbinary | Token contract address (fixed address for native tokens) |
| symbol | varchar | Token symbol (e.g., ‘ETH’, ‘USDC’) |
| timestamp | timestamp | Date timestamp (00:00 UTC of each day) |
| price | double | Token price in USD |
| decimals | int | Token decimals |
| volume | double | Trading volume in USD (from price source) |
| source | varchar | Data source (‘coinpaprika’ or ‘dex.trades’) |
| source\_timestamp | timestamp | Exact timestamp of the source data point |

## [​](#implementation-details) Implementation Details

The daily prices are built through these steps:

1. Collect sparse price observations from different sources
2. Group by day, taking the most recent price observation per day
3. Fill missing days with the previous day’s price (forward filling)
4. Set a 30-day expiration for forward filling to avoid stale data

## [​](#usage) Usage

This table is ideal for analyzing daily price trends and performing day-over-day comparisons. It provides a good balance between data granularity and query performance for longer-term analyses.

## [​](#latency-and-update-frequency) Latency and Update Frequency

The `prices.day` table is updated daily at 00:00 UTC, providing the closing price for the previous day. Data is typically available within 30 minutes of the daily close.

## [​](#usage-examples) Usage Examples

### [​](#get-eth-price-history-for-the-last-month%3A) Get ETH price history for the last month:

Copy

Ask AI

```
SELECT
  timestamp,
  price
FROM prices.day
WHERE blockchain = 'ethereum'
AND contract_address = 0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2 -- WETH
AND timestamp >= NOW() - INTERVAL '30' DAY
ORDER BY timestamp

```

### [​](#calculate-monthly-average-price-for-multiple-tokens%3A) Calculate monthly average price for multiple tokens:

Copy

Ask AI

```
SELECT
  blockchain,
  symbol, -- Symbol included for readable output only
  date_trunc('month', timestamp) as month,
  avg(price) as avg_price
FROM prices.day
WHERE blockchain = 'ethereum'
AND contract_address IN (
  0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2, -- WETH
  0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48, -- USDC
  0x2260fac5e5542a773aa44fbcfedf7c193bc2c599  -- WBTC
)
AND timestamp >= NOW() - INTERVAL '90' DAY
GROUP BY 1,2,3
ORDER BY 1,2,3

```

### [​](#get-native-token-price-using-dune-blockchains%3A) Get native token price using dune.blockchains:

Copy

Ask AI

```
-- First get the native token address
WITH native_token AS (
  SELECT token_address
  FROM dune.blockchains
  WHERE name = 'ethereum'
)
-- Then use it to query the price
SELECT
  timestamp,
  price
FROM prices.day, native_token
WHERE blockchain = 'ethereum'
AND contract_address = token_address
AND timestamp >= NOW() - INTERVAL '30' DAY
ORDER BY timestamp

```

## [​](#data-quality-notes) Data Quality Notes

* Prices older than 30 days will not be forward-filled to avoid using stale data
* Native tokens (like ETH, BNB) are assigned fixed addresses for consistency
* For native tokens, use `dune.blockchains` table to get the standardized address for each blockchain
* The same token may have different prices on different blockchains due to bridging inefficiencies
* Always use `contract_address` and `blockchain` for precise token identification, never use `symbol` for joins or filters

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/prices/prices_day)

[Hourly Prices](/data-catalog/curated/prices/prices_hour)[USD Prices (Legacy)](/data-catalog/curated/prices/prices_usd)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.