[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Prices

Prices

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices

  + [Prices](/data-catalog/curated/prices/overview)
  + [Minute Prices](/data-catalog/curated/prices/prices_minute)
  + [Hourly Prices](/data-catalog/curated/prices/prices_hour)
  + [Daily Prices](/data-catalog/curated/prices/prices_day)
  + [USD Prices (Legacy)](/data-catalog/curated/prices/prices_usd)
  + [Latest Prices](/data-catalog/curated/prices/prices_latest)
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Prices (Token Price Data)](#prices-token-price-data)
* [Key Features](#key-features)
* [Available Tables](#available-tables)
* [Implementation Details](#implementation-details)
* [Coverage](#coverage)
* [Schema](#schema)
* [Technical Notes](#technical-notes)
* [Methodology](#methodology)
* [Step 1: Importing Trusted Token Prices](#step-1%3A-importing-trusted-token-prices)
* [Step 2: DEX-Derived Prices](#step-2%3A-dex-derived-prices)
* [Usage Examples](#usage-examples)
* [Basic query to get the latest ETH price:](#basic-query-to-get-the-latest-eth-price%3A)
* [Getting historical price data:](#getting-historical-price-data%3A)
* [Finding the right native token address:](#finding-the-right-native-token-address%3A)
* [Legacy Tables](#legacy-tables)

Prices

# Prices

Token price data across multiple blockchains

# [​](#prices-token-price-data) Prices (Token Price Data)

Dune provides reliable token price data for use in your queries across 40+ blockchains. This implementation is a complete rewrite of the price aggregation system with significant improvements.

## [​](#key-features) Key Features

* **Multi-blockchain support**: Prices for tokens across 40+ blockchains
* **Standardized native token addresses**: Native tokens (like ETH, BNB) have fixed contract addresses for consistency
* **Multiple time granularities**: hourly, daily, and latest price data
* **Source transparency**: Each price point includes its data source
* **Data quality**: Comprehensive filters to ensure price reliability

## [​](#available-tables) Available Tables

The `prices` schema exposes these main tables:

| Table | Description |
| --- | --- |
| `prices.latest` | The most recent price for each token |
| `prices.day` | Daily token prices (most recent price of each day) |
| `prices.hour` | Hourly token prices |
| `prices.minute` | Minute-by-minute token prices |

For best performance, use the table with the coarsest granularity that meets your analytical needs. Querying minute-level data over long time periods can be very resource-intensive.

## [​](#implementation-details) Implementation Details

The price system works in multiple layers:

1. **Base data sources**:
   * External price feeds (Coinpaprika)
   * DEX trading data (from `dex.trades`)
2. **Data processing pipeline**:
   * Sparse minute data collected from both sources
   * Aggregated to hourly and daily sparse records
   * Filled into continuous time series for steady time intervals
3. **Token handling**:
   * Native tokens are assigned fixed addresses instead of NULL or 0xeeee…
   * You can find the correct native token address for each blockchain in the `dune.blockchains` table
   * Trusted tokens (major stablecoins, wrapped assets) serve as price anchors
   * Non-trusted tokens derive prices through DEX trades against trusted tokens
   * Simply put: We use prices from trusted tokens to calculate prices of other tokens based on the data from DEX trades

## [​](#coverage) Coverage

* 900,000 unique tokens
* 40+ blockchains
* new tokens are automatically added when they exceed a $10k volume threshold

[## Check Price Coverage

You can test the coverage of the prices tables on this dashboard.](https://dune.com/dune/does-dune-have-price-for-token)

## [​](#schema) Schema

All price tables share the following schema (with slight variations):

| Column | Type | Description |
| --- | --- | --- |
| `blockchain` | *varchar* | Blockchain identifier (e.g., ‘ethereum’, ‘arbitrum’) |
| `contract_address` | *varbinary* | Token contract address (fixed address for native tokens) |
| `symbol` | *varchar* | Token symbol (e.g., ‘ETH’, ‘USDC’) |
| `price` | *double* | USD price |
| `timestamp` | *timestamp* | Timestamp (start of minute, hour, or day) |
| `decimals` | *int* | Token decimals |
| `volume` | *double* | Trading volume in USD (from price source) |
| `source` | *varchar* | Data source (‘coinpaprika’ or ‘dex.trades’) |
| `source_timestamp` | *timestamp* | Exact timestamp of the source data point |

## [​](#technical-notes) Technical Notes

* Prices are calculated independently per blockchain
* Token identification requires both `contract_address` AND `blockchain`
* `symbol` is not unique - do not use for token identification or joins
* For native tokens, use the standardized addresses from `dune.blockchains` table
* If there are no trades for a token, we use the last available price and carry it forward for a limited time period:
  + 30 days for daily prices
  + 7 days for hourly prices
  + 2 days for minute prices

## [​](#methodology) Methodology

### [​](#step-1%3A-importing-trusted-token-prices) Step 1: Importing Trusted Token Prices

Dune sources trusted token prices from [Coin Paprika](https://coinpaprika.com/). These prices:

* Cover major tokens that are defined in the `prices.trusted_tokens` table
* Serve as base prices for calculating prices of other tokens traded against them in DEX pairs

### [​](#step-2%3A-dex-derived-prices) Step 2: DEX-Derived Prices

For details on how Dune processes DEX trade data to derive accurate token prices, see the [DEX Trade Processing](/data-catalog/curated/dex-trades/evm/dex-trades):

* We start by collecting raw trading data from the `dex.trades` table
* We calculate prices for trading pairs where one token is from our trusted token list
* The data then goes through our processing pipeline which:
  + Excludes trades with less than $10,000 USD in total volume
  + Takes the median price from each minute to reduce outlier impact
  + Calculates USD prices using our trusted token prices as reference
  + Uses forward-filling to handle periods without valid trades, with time limits
  + 30 days for daily prices
  + 7 days for hourly prices
  + 2 days for minute prices

## [​](#usage-examples) Usage Examples

Here are some examples of how to use the prices tables.

### [​](#basic-query-to-get-the-latest-eth-price%3A) Basic query to get the latest ETH price:

Copy

Ask AI

```
SELECT price
FROM prices.latest
WHERE blockchain = 'ethereum' 
AND contract_address = 0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2 -- WETH

```

### [​](#getting-historical-price-data%3A) Getting historical price data:

Copy

Ask AI

```
SELECT
  timestamp,
  price
FROM prices.day
WHERE blockchain = 'ethereum'
AND contract_address = 0x1f9840a85d5af5bf1d1762f925bdaddc4201f984 -- UNI
AND timestamp >= NOW() - INTERVAL '30' DAY

```

### [​](#finding-the-right-native-token-address%3A) Finding the right native token address:

Copy

Ask AI

```
-- Query to get the native token address for a specific blockchain
SELECT 
  name,
  token_address,
  token_symbol
FROM dune.blockchains
WHERE name = 'arbitrum'

```

## [​](#legacy-tables) Legacy Tables

The following tables are maintained for historical compatibility but we no longer add tokens to them:

* `prices.usd`
* `prices.usd_daily`
* `prices.usd_latest`

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/prices/overview)

[Details](/data-catalog/curated/labels/owner-details)[Minute Prices](/data-catalog/curated/prices/prices_minute)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.