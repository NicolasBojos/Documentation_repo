[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Prices

Minute Prices

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices

  + [Prices](/data-catalog/curated/prices/overview)
  + [Minute Prices](/data-catalog/curated/prices/prices_minute)
  + [Hourly Prices](/data-catalog/curated/prices/prices_hour)
  + [Daily Prices](/data-catalog/curated/prices/prices_day)
  + [USD Prices (Legacy)](/data-catalog/curated/prices/prices_usd)
  + [Latest Prices](/data-catalog/curated/prices/prices_latest)
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [prices.minute](#prices-minute)
* [Overview](#overview)
* [Table Schema](#table-schema)
* [Implementation Details](#implementation-details)
* [Usage](#usage)
* [Latency and Update Frequency](#latency-and-update-frequency)
* [Usage Examples](#usage-examples)
* [Get minute-by-minute ETH prices during a specific event:](#get-minute-by-minute-eth-prices-during-a-specific-event%3A)
* [Analyze price volatility within short time frames:](#analyze-price-volatility-within-short-time-frames%3A)
* [Data Quality Notes](#data-quality-notes)

Prices

# Minute Prices

Real-time minute-by-minute price data for tokens across all supported blockchains

# [​](#prices-minute) prices.minute

## [​](#overview) Overview

The `prices.minute` table provides the most granular price data for tokens across multiple blockchains, with minute-level precision. This is the highest resolution price data available in the Dune platform.

## [​](#table-schema) Table Schema

| Column | Type | Description |
| --- | --- | --- |
| blockchain | varchar | Blockchain identifier (e.g., ‘ethereum’, ‘arbitrum’) |
| contract\_address | varbinary | Token contract address (fixed address for native tokens) |
| symbol | varchar | Token symbol (e.g., ‘ETH’, ‘USDC’) |
| timestamp | timestamp | Minute timestamp |
| price | double | Token price in USD |
| decimals | int | Token decimals |
| volume | double | Trading volume in USD (from price source) |
| source | varchar | Data source (‘coinpaprika’ or ‘dex.trades’) |
| source\_timestamp | timestamp | Exact timestamp of the source data point |

## [​](#implementation-details) Implementation Details

The minute prices are built through these steps:

1. Collect sparse price observations from different sources
2. Take the most recent price observation per minute
3. Fill missing minutes with the previous minute’s price (forward filling)
4. Set an expiration time of 48h for forward filling to avoid stale data

## [​](#usage) Usage

This table is ideal for high-frequency analysis and examining short-term price movements. It’s particularly useful for studying price impacts of specific events or transactions with high temporal precision.

## [​](#latency-and-update-frequency) Latency and Update Frequency

The `prices.minute` table is updated hourly based on the upstream data pipeline. As a result, prices typically have a latency of approximately 1 hour from real-time.

## [​](#usage-examples) Usage Examples

Here are some examples of how to use the prices tables.

### [​](#get-minute-by-minute-eth-prices-during-a-specific-event%3A) Get minute-by-minute ETH prices during a specific event:

Copy

Ask AI

```
SELECT
  timestamp,
  price
FROM prices.minute
WHERE
  blockchain = 'ethereum'
  AND contract_address = 0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2 -- WETH
  AND timestamp >= NOW() - INTERVAL '2' HOUR
  AND timestamp <= NOW() - INTERVAL '1' HOUR
ORDER BY timestamp

```

### [​](#analyze-price-volatility-within-short-time-frames%3A) Analyze price volatility within short time frames:

Copy

Ask AI

```
SELECT
  date_trunc('hour', timestamp) as hour,
  max(price) - min(price) as price_range,
  (max(price) - min(price)) / min(price) * 100 as volatility_pct
FROM prices.minute
WHERE
  blockchain = 'ethereum'
  AND contract_address = 0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2 -- WETH
  AND timestamp >= NOW() - INTERVAL '1' DAY
GROUP BY 1
ORDER BY 1

```

## [​](#data-quality-notes) Data Quality Notes

* Due to its high granularity, queries on this table may be more resource-intensive
* Consider using `prices.hour` or `prices.day` for longer time ranges if minute-level precision is not required
* Native tokens (like ETH, BNB) are assigned fixed addresses for consistency
* Always use `contract_address` and `blockchain` for precise token identification, never use `symbol` for joins or filters

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/prices/prices_minute)

[Prices](/data-catalog/curated/prices/overview)[Hourly Prices](/data-catalog/curated/prices/prices_hour)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.