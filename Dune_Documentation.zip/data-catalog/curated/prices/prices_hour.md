[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Prices

Hourly Prices

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices

  + [Prices](/data-catalog/curated/prices/overview)
  + [Minute Prices](/data-catalog/curated/prices/prices_minute)
  + [Hourly Prices](/data-catalog/curated/prices/prices_hour)
  + [Daily Prices](/data-catalog/curated/prices/prices_day)
  + [USD Prices (Legacy)](/data-catalog/curated/prices/prices_usd)
  + [Latest Prices](/data-catalog/curated/prices/prices_latest)
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [prices.hour](#prices-hour)
* [Overview](#overview)
* [Table Schema](#table-schema)
* [Implementation Details](#implementation-details)
* [Usage](#usage)
* [Latency and Update Frequency](#latency-and-update-frequency)
* [Usage Examples](#usage-examples)
* [Get hourly ETH prices for the last day:](#get-hourly-eth-prices-for-the-last-day%3A)
* [Calculate volatility by hour of day:](#calculate-volatility-by-hour-of-day%3A)
* [Data Quality Notes](#data-quality-notes)

Prices

# Hourly Prices

Historical hourly price data for tokens across all supported blockchains

# [​](#prices-hour) prices.hour

## [​](#overview) Overview

The `prices.hour` table provides hourly token price data across all supported blockchains. It contains the last known price for each hour, ensuring a continuous time series for more granular price analysis than daily data.

## [​](#table-schema) Table Schema

| Column | Type | Description |
| --- | --- | --- |
| blockchain | varchar | Blockchain identifier (e.g., ‘ethereum’, ‘arbitrum’) |
| contract\_address | varbinary | Token contract address (fixed address for native tokens) |
| symbol | varchar | Token symbol (e.g., ‘ETH’, ‘USDC’) |
| timestamp | timestamp | Hour timestamp (00:00, 01:00, etc. UTC of each hour) |
| price | double | Token price in USD |
| decimals | int | Token decimals |
| volume | double | Trading volume in USD (from price source) |
| source | varchar | Data source (‘coinpaprika’ or ‘dex.trades’) |
| source\_timestamp | timestamp | Exact timestamp of the source data point |

## [​](#implementation-details) Implementation Details

The hourly prices are built through these steps:

1. Collect sparse price observations from different sources
2. Group by hour, taking the most recent price observation per hour
3. Fill missing hours with the previous hour’s price (forward filling)
4. Set a 7-day (168 hour) expiration for forward filling to avoid stale data

## [​](#usage) Usage

This table is useful for intraday analysis and tracking price movements with higher granularity than daily data. It’s suitable for examining price patterns within a day or across multiple days.

## [​](#latency-and-update-frequency) Latency and Update Frequency

The `prices.hour` table is updated hourly based on the upstream data pipeline. As a result, prices typically have a latency of approximately 1 hour from real-time.

## [​](#usage-examples) Usage Examples

Here are some examples of how to use the prices tables.

### [​](#get-hourly-eth-prices-for-the-last-day%3A) Get hourly ETH prices for the last day:

Copy

Ask AI

```
SELECT
  timestamp,
  price
FROM prices.hour
WHERE blockchain = 'ethereum'
AND contract_address = 0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2 -- WETH
AND timestamp >= NOW() - INTERVAL '1' DAY
ORDER BY timestamp

```

### [​](#calculate-volatility-by-hour-of-day%3A) Calculate volatility by hour of day:

Copy

Ask AI

```
SELECT
  extract(hour from timestamp) as hour_of_day,
  avg(abs(price - lag(price) OVER (PARTITION BY blockchain, contract_address ORDER BY timestamp))
      / lag(price) OVER (PARTITION BY blockchain, contract_address ORDER BY timestamp)) as avg_hourly_change
FROM prices.hour
WHERE blockchain = 'ethereum'
AND contract_address = 0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2 -- WETH
AND timestamp >= NOW() - INTERVAL '30' DAY
GROUP BY 1
ORDER BY 1

```

## [​](#data-quality-notes) Data Quality Notes

* Prices older than 7 days (168 hours) will not be forward-filled to avoid using stale data
* Native tokens (like ETH, BNB) are assigned fixed addresses for consistency
* Hourly data is useful for analyzing intraday patterns and short-term price movements
* Always use `contract_address` and `blockchain` for precise token identification, never use `symbol` for joins or filters

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/prices/prices_hour)

[Minute Prices](/data-catalog/curated/prices/prices_minute)[Daily Prices](/data-catalog/curated/prices/prices_day)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.