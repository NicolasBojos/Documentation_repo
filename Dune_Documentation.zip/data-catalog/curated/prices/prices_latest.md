[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Prices

Latest Prices

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices

  + [Prices](/data-catalog/curated/prices/overview)
  + [Minute Prices](/data-catalog/curated/prices/prices_minute)
  + [Hourly Prices](/data-catalog/curated/prices/prices_hour)
  + [Daily Prices](/data-catalog/curated/prices/prices_day)
  + [USD Prices (Legacy)](/data-catalog/curated/prices/prices_usd)
  + [Latest Prices](/data-catalog/curated/prices/prices_latest)
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [prices.latest](#prices-latest)
* [Overview](#overview)
* [Table Schema](#table-schema)
* [Implementation Details](#implementation-details)
* [Usage](#usage)
* [Usage Examples](#usage-examples)
* [Get current prices for major tokens:](#get-current-prices-for-major-tokens%3A)
* [Calculate total USD value of token holdings:](#calculate-total-usd-value-of-token-holdings%3A)
* [Get prices for native tokens across multiple blockchains:](#get-prices-for-native-tokens-across-multiple-blockchains%3A)
* [Data Quality Notes](#data-quality-notes)

Prices

# Latest Prices

Most recent price data for tokens across all supported blockchains

# [​](#prices-latest) prices.latest

## [​](#overview) Overview

The `prices.latest` table provides the most recently available price for each token across all supported blockchains. This table is ideal for calculating current token values or displaying up-to-date prices.

## [​](#table-schema) Table Schema

| Column | Type | Description |
| --- | --- | --- |
| blockchain | varchar | Blockchain identifier (e.g., ‘ethereum’, ‘arbitrum’) |
| contract\_address | varbinary | Token contract address (fixed address for native tokens) |
| symbol | varchar | Token symbol (e.g., ‘ETH’, ‘USDC’) |
| price | double | Most recent token price in USD |
| decimals | int | Token decimals |
| timestamp | timestamp | Timestamp when this price was recorded |
| volume | double | Trading volume in USD (from price source) |
| source | varchar | Data source (‘coinpaprika’ or ‘dex.trades’) |
| source\_timestamp | timestamp | Exact timestamp of the source data point |

## [​](#implementation-details) Implementation Details

The latest prices are built by:

1. Taking the most recent price observation from each data source
2. Selecting the latest observation per token across all sources
3. Refreshed hourly to ensure prices stay current

## [​](#usage) Usage

This table is perfect for querying the current price of tokens without needing to filter by timestamp or perform additional aggregations. It’s designed for efficiency when you just need the most recent price.

## [​](#usage-examples) Usage Examples

Here are some examples of how to use the prices tables.

### [​](#get-current-prices-for-major-tokens%3A) Get current prices for major tokens:

Copy

Ask AI

```
SELECT
  blockchain,
  symbol, -- Symbol included for readable output only
  price,
  timestamp
FROM prices.latest
WHERE (blockchain, contract_address) IN (
  ('ethereum', 0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2), -- WETH
  ('ethereum', 0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48), -- USDC
  ('ethereum', 0x2260fac5e5542a773aa44fbcfedf7c193bc2c599), -- WBTC
  ('arbitrum', 0x82af49447d8a07e3bd95bd0d56f35241523fbab1), -- WETH on Arbitrum
  ('optimism', 0x4200000000000000000000000000000000000006)  -- WETH on Optimism
)

```

### [​](#calculate-total-usd-value-of-token-holdings%3A) Calculate total USD value of token holdings:

Copy

Ask AI

```
WITH token_balances AS (
  SELECT
    token_address,
    sum(amount) as total_tokens
  FROM my_token_balance_table
  GROUP BY 1
)

SELECT
  b.token_address,
  p.symbol, -- Symbol included for readable output only
  b.total_tokens,
  b.total_tokens * p.price as usd_value
FROM token_balances b
JOIN prices.latest p
  ON p.blockchain = 'ethereum'
  AND p.contract_address = b.token_address

```

### [​](#get-prices-for-native-tokens-across-multiple-blockchains%3A) Get prices for native tokens across multiple blockchains:

Copy

Ask AI

```
-- Join with dune.blockchains to get native token prices
SELECT
  b.name as blockchain,
  b.token_symbol as native_token_symbol,
  p.price as native_token_price,
  p.timestamp
FROM dune.blockchains b
JOIN prices.latest p
  ON p.blockchain = b.name
  AND p.contract_address = b.token_address
WHERE b.name IN ('ethereum', 'arbitrum', 'optimism', 'polygon','gnosis','solana')

```

## [​](#data-quality-notes) Data Quality Notes

* Native tokens (like ETH, BNB) are assigned fixed addresses for consistency
* For native tokens, use `dune.blockchains` table to get the standardized address for each blockchain
* The timestamp column shows when the price was last updated, useful for determining freshness
* For historical analysis, use `prices.day`, `prices.hour`, or `prices.minute` instead
* Always use `contract_address` and `blockchain` for precise token identification, never use `symbol` for joins or filters

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/prices/prices_latest)

[USD Prices (Legacy)](/data-catalog/curated/prices/prices_usd)[Overview](/data-catalog/curated/nft-trades/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.