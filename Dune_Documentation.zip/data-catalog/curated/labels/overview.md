[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Labels

Labels Data

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels

  + [Overview](/data-catalog/curated/labels/overview)
  + [All labels](/data-catalog/curated/labels/address-labels)
  + [ENS](/data-catalog/curated/labels/ens-labels)
  + [Addresses](/data-catalog/curated/labels/owner-addresses)
  + [Details](/data-catalog/curated/labels/owner-details)
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Why Labels Matter](#why-labels-matter)
* [Labels datasets](#labels-datasets)

Labels

# Labels Data

Labels provide valuable context and clarity to blockchain addresses, enhancing the readability and understanding of blockchain transaction data.

## [​](#why-labels-matter) Why Labels Matter

Labels are more than just simple tags or annotations. They provide valuable context and clarity to blockchain addresses, enhancing the readability and understanding of blockchain transaction data.
In the world of blockchain analysis, labels play a crucial role in identifying and categorizing different entities and activities. They act as signposts, guiding analysts through the complex web of transactions and addresses, making it easier to identify the parties involved and their roles.
By mapping blockchain addresses to **known entities**, labels bring transparency to transaction analysis. They help distinguish between individuals, organizations, smart contracts, and other important actors in the blockchain ecosystem. This clarity is essential for compliance, risk assessment, and investigative purposes.
Labels also provide insights into the roles and functions of addresses, helping analysts understand the nature of transactions and the relationships between different entities in the blockchain ecosystem.

## [​](#labels-datasets) Labels datasets

We provide several label datasets that can be used to enrich your analysis:

[## All Labels

A comprehensive collection of labeled addresses across various categories and blockchains, serving as a central repository for all labeled entities on Dune.](/data-catalog/curated/labels/address-labels)[## ENS Labels

Ethereum Name Service (ENS) data linking human-readable names with blockchain addresses, facilitating easier interactions and identifications within the Ethereum ecosystem.](/data-catalog/curated/labels/ens-labels)[## Owner Addresses

Detailed mapping of blockchain addresses to their owners and custodians, providing insights into ownership and custody of assets across blockchains.](/data-catalog/curated/labels/owner-addresses)[## Owner Details

Comprehensive information about entities within the ecosystem, including their operational profiles, categories, and online presence.](/data-catalog/curated/labels/owner-details)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/labels/overview)

[Token Transfers](/data-catalog/curated/token-transfers/solana/solana-token-transfers)[All labels](/data-catalog/curated/labels/address-labels)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.