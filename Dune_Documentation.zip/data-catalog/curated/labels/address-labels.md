[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Labels

labels.addresses

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels

  + [Overview](/data-catalog/curated/labels/overview)
  + [All labels](/data-catalog/curated/labels/address-labels)
  + [ENS](/data-catalog/curated/labels/ens-labels)
  + [Addresses](/data-catalog/curated/labels/owner-addresses)
  + [Details](/data-catalog/curated/labels/owner-details)
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Available Categories](#available-categories)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)
* [Example Query](#example-query)

Labels

# labels.addresses

Description of the labels.addresses table on Dune

The `labels.addresses` table on Dune catalogs specific blockchain addresses, associating them with descriptive labels, categories, and usage metrics. This table is a superset of many other `labels.<category>` tables, providing a comprehensive overview of labeled addresses across various categories and blockchains.
You can use the `category` column to filter labels for the specific type of address you are interested in.

The `labels.addresses` table serves as a central repository for all labeled addresses on Dune, offering a consolidated view of labeled entities across different categories and blockchains.

## [​](#available-categories) Available Categories

Here are all the distinct category values available in the `labels.addresses` table:

## [​](#column-descriptions) Column Descriptions

| Column Name | Description |
| --- | --- |
| `blockchain` | The blockchain network where the address is located (e.g., Ethereum, Binance Chain). |
| `address` | The blockchain address being labeled. |
| `name` | Descriptive name or label for the address. |
| `category` | The category that best describes the address’ role (e.g., dex, wallet). |
| `contributor` | The Dune user who contributed the data. |
| `source` | The source or methodology used to gather or verify the information. |
| `created_at` | The date when the label record was first created. |
| `updated_at` | The date when the label record was last updated. |
| `model_name` | The model used for categorizing or labeling the address. |
| `label_type` | The type of label applied to the address, indicating its primary usage or function. |

## [​](#table-sample) Table Sample

## [​](#example-query) Example Query

The following SQL query demonstrates how to find addresses categorized under ‘dex’ within the Binance blockchain:

Copy

Ask AI

```
SELECT
  address,
  name
FROM
  labels.addresses
WHERE
  category = 'dex' AND
  blockchain = 'bnb'

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/labels/address-labels)

[Overview](/data-catalog/curated/labels/overview)[ENS](/data-catalog/curated/labels/ens-labels)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.