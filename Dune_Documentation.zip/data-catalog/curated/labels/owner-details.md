[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Labels

labels.owner\_details

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels

  + [Overview](/data-catalog/curated/labels/overview)
  + [All labels](/data-catalog/curated/labels/address-labels)
  + [ENS](/data-catalog/curated/labels/ens-labels)
  + [Addresses](/data-catalog/curated/labels/owner-addresses)
  + [Details](/data-catalog/curated/labels/owner-details)
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)
* [Example Query](#example-query)

Labels

# labels.owner\_details

Description of the labels.owner\_details table on Dune

The `labels.owner_details` table on Dune provides essential information about various entities within the ecosystem, detailing their operational, social, and technical profiles.
Data in this table is sourced from community contributions and official documentation, offering a comprehensive overview of the entities’ activities, categories, and online presence. Analysts can leverage this data to track the latest developments, partnerships, and projects associated with specific entities.

You can find addresses assocaited with the account owners and custody owners in the `labels.owner_addresses` table.

## [​](#column-descriptions) Column Descriptions

| Column Name | Description |
| --- | --- |
| `name` | The name of the entity. |
| `owner_key` | A unique identifier for the owner. |
| `website` | Official website URL of the entity. |
| `dune_team` | Indicates if the entity is part of the Dune team (deprecated/not widely used, often null). |
| `project_documentation` | Link to the official documentation of the project. |
| `project_github_url` | GitHub URL if the project is open-source. |
| `social` | Social media or other online presence links. |
| `primary_category` | The primary category under which the entity operates (e.g., DEX, Oracle). |
| `category_tags` | Additional tags related to the category such as functionalities or special features. |
| `country_name` | The country in which the entity is based. |
| `description` | A brief description of the entity and its operations. |
| `created_at` | Timestamp of when the record was first created. |
| `created_by` | Identifier of the contributor who created the record. |
| `updated_at` | Timestamp of the last update to the record. |
| `updated_by` | Identifier of the contributor who last updated the record. |

## [​](#table-sample) Table Sample

## [​](#example-query) Example Query

The following SQL query demonstrates how to retrieve basic information about entities categorized as ‘Decentralized Exchange’:

Copy

Ask AI

```
SELECT
  name,
  website,
  primary_category
FROM
  labels.owner_details
WHERE
  primary_category = 'Decentralized Exchange'

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/curated/labels/owner-details)

[Addresses](/data-catalog/curated/labels/owner-addresses)[Prices](/data-catalog/curated/prices/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.