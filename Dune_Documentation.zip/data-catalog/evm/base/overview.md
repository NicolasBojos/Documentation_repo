[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Base

Base Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base

  + [Overview](/data-catalog/evm/base/overview)
  + Raw
  + Decoded
  + Curated
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Catalog](#data-catalog)

Base

# Base Overview

Base data on Dune

Base is a secure, low-cost, builder-friendly Ethereum Layer 2 solution incubated by Coinbase. It is designed to onboard the next billion users to the blockchain, emphasizing ease of use and accessibility for a global audience. The platform aims for progressive decentralization over the years, underlining its commitment to an open, global cryptoeconomy.
As an Ethereum L2, Base offers the security, stability, and scalability necessary to support your onchain applications. Developers can deploy any EVM-compatible codebase and smoothly transition users and assets from Ethereum L1, Coinbase, and other compatible chains.
**Big Features, Small Fees:**
Base provides an Ethereum Virtual Machine (EVM) environment at significantly lower costs. It introduces early access to new Ethereum features such as Account Abstraction (ERC4337), developer-friendly APIs for gasless transactions, and advanced smart contract wallets.
**Open Source Commitment:**
Built on the MIT-licensed OP Stack in collaboration with Optimism, Base contributes as the second Core Development team to ensure the OP Stack remains a public good accessible to all.
**Scaled by Coinbase:**
Base leverages Coinbase’s robust infrastructure to offer decentralized apps enhanced product integration, straightforward fiat onramps, and access to a vast network of millions of verified users within the Coinbase ecosystem.

[## Base documentation

Explore comprehensive documentation on Base, detailing its architecture, protocol, and resources for developers.](https://base.org/docs)

## [​](#data-catalog) Data Catalog

[## Logs

Detailed event logs from smart contracts, providing insights into interactions within the Base network.](./raw/logs)[## Blocks

Information on blocks, illustrating the operational capacity and activity levels on Base.](./raw/blocks)[## Transactions

Extensive transaction data, showcasing the efficiency and execution of operations on Base.](./raw/transactions)[## decoded

Enhanced transaction data decoded for better analysis and understanding of contract executions.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/base/overview)

[NFT Trades](/data-catalog/evm/b3/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/base/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.