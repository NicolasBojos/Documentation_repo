[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

ApeChain

ApeChain Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain

  + [Overview](/data-catalog/evm/apechain/overview)
  + Raw
  + Decoded
  + Curated
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is ApeChain?](#what-is-apechain%3F)
* [Key Features](#key-features)
* [Why ApeChain?](#why-apechain%3F)
* [Technical Architecture](#technical-architecture)
* [Development Features](#development-features)
* [Network Economics](#network-economics)
* [Data Catalog](#data-catalog)

ApeChain

# ApeChain Overview

ApeChain data on Dune

## [​](#what-is-apechain%3F) What is ApeChain?

ApeChain is a dedicated infrastructure layer designed to power the ApeCoin ecosystem. Built on Arbitrum Orbit, it provides developers and users with the best possible experience on the blockchain by focusing on ecosystem discovery, unique web3 rails, and top of funnel exposure.

## [​](#key-features) Key Features

* **Native Gas Token**: Uses $APE as its native gas token
* **Arbitrum Orbit**: Built as an Arbitrum Orbit chain for scalability and efficiency
* **Enhanced Utility**: Significantly enhances $APE’s utility
* **Ecosystem Focus**: Powers the ApeCoin ecosystem with dedicated infrastructure

## [​](#why-apechain%3F) Why ApeChain?

ApeChain positions itself as a premier platform for the ApeCoin ecosystem by:

* Fostering a robust and dynamic economy driven by $APE
* Providing dedicated infrastructure for ecosystem growth
* Enhancing the utility and value proposition of $APE

## [​](#technical-architecture) Technical Architecture

Built on Arbitrum Orbit, ApeChain inherits Arbitrum’s robust technical foundation while adding ApeCoin-specific optimizations:

### [​](#development-features) Development Features

* **Arbitrum Technology**: Leverages Arbitrum’s proven Layer 2 scaling solution
* **APE Integration**: Native support for APE token operations
* **Ecosystem Tools**: Comprehensive development and analytics tools

### [​](#network-economics) Network Economics

* **Gas Token**: $APE
* **Economic Model**: Designed to enhance $APE utility and ecosystem value

[## ApeChain Documentation

Official documentation for developers building on ApeChain](https://docs.apechain.com)

## [​](#data-catalog) Data Catalog

[## Logs

Insights into smart contract interactions through event logs](./raw/logs)[## Blocks

Information on blocks processed on ApeChain, reflecting network activity and capacity](./raw/blocks)[## Transactions

Detailed data on transactions, showcasing efficiency and operational execution](./raw/transactions)[## decoded

Decoded transaction information for enhanced analysis and understanding of smart contract executions](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/apechain/overview)

[NFT Trades](/data-catalog/evm/abstract/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/apechain/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.