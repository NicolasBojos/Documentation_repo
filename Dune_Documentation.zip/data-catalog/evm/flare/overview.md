[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Flare

Flare Chain Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare

  + [Overview](/data-catalog/evm/flare/overview)
  + Raw
  + Decoded
  + Curated
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is Flare?](#what-is-flare%3F)
* [Key Features of Flare](#key-features-of-flare)
* [Data as a Public Good](#data-as-a-public-good)
* [Dual Role Infrastructure Providers](#dual-role-infrastructure-providers)
* [Developing on Flare](#developing-on-flare)
* [Flare Networks and chains](#flare-networks-and-chains)
* [Security and Governance](#security-and-governance)
* [Data Catalog](#data-catalog)

Flare

# Flare Chain Overview

Flare blockchain data on Dune

## [​](#what-is-flare%3F) What is Flare?

Flare is a layer 1, EVM-compatible smart contract platform that redefines the utility of blockchain by making data a public good. It is uniquely designed to provide developers with efficient access to extensive data resources, facilitating the creation of sophisticated applications in various domains such as DeFi, gaming, NFTs, music, social networks, real world assets, machine learning, and artificial intelligence.

## [​](#key-features-of-flare) Key Features of Flare

Flare stands out by integrating robust data protocols directly into its blockchain architecture, offering developers powerful tools to leverage data efficiently and cost-effectively.

### [​](#data-as-a-public-good) **Data as a Public Good**

At the core of Flare’s philosophy is the provision of data as a public good. This ensures that data is accessible without central control, fostering an environment of openness and innovation.

### [​](#dual-role-infrastructure-providers) **Dual Role Infrastructure Providers**

Infrastructure providers on Flare serve a dual role as validators and data providers. This integration allows Flare to offer its unique native oracles: the Flare Time-Series Oracle (FTSO) and the Flare Data Connector.

### [​](#developing-on-flare) **Developing on Flare**

Developers interested in building on Flare can find comprehensive resources and guides at the Flare Developer Hub. This hub provides tools, documentation, and support to help developers create, test, and deploy their applications on Flare’s network.

## [​](#flare-networks-and-chains) Flare Networks and chains

Flare encompasses several networks, each designed for specific functions and stages of development:

* **Flare:** The main network with $FLR as the native currency.
* **Songbird:** The canary network where $SGB is the native currency, used for real condition testing before mainnet deployment.
* **Coston:** The public test network for developers using Songbird.
* **Coston2:** The public test network for developers using Flare.

Flare operates on two primary chains:

* **C-Chain (Contract Chain):** Hosts smart contracts and is powered by the EVM, facilitating most of the community interactions.
* **P-Chain (Platform Chain):** Manages staking and rewards distribution among validators.

## [​](#security-and-governance) Security and Governance

Flare integrates advanced security protocols and a decentralized governance model, allowing $FLR token holders to participate in network decisions. This inclusive approach ensures that Flare adapts to the evolving needs of its users and developers.

[## Flare Documentation

Explore the complete documentation for Flare.](https://docs.flare.network/)

## [​](#data-catalog) Data Catalog

[## Logs

Explore detailed logs and operational data on Flare, emphasizing transparency and access to real-time network activities and oracle updates.](./raw/logs)[## Blocks

View insights into Flare’s block production and consensus mechanism, highlighting the efficiency and security of the state connector and its impact on blockchain finality.](./raw/blocks)[## Transactions

Dive into transaction data to experience Flare’s innovative zero-gas mechanism, showcasing how it facilitates cost-effective and accessible blockchain interactions.](./raw/transactions)[## Decoded

Access decoded transaction data to gain insights into the seamless integration of FAssets and interactions across Flare’s unique app chains, driving a new era of blockchain utility.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/flare/overview)

[NFT Trades](/data-catalog/evm/fantom/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/flare/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.