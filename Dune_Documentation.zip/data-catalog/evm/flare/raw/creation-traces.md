[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Raw

flare.creation\_traces

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare

  + [Overview](/data-catalog/evm/flare/overview)
  + Raw

    - [Blocks](/data-catalog/evm/flare/raw/blocks)
    - [Creation Traces](/data-catalog/evm/flare/raw/creation-traces)
    - [Logs](/data-catalog/evm/flare/raw/logs)
    - [Transactions](/data-catalog/evm/flare/raw/transactions)
    - [Traces](/data-catalog/evm/flare/raw/traces)
  + Decoded
  + Curated
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

Raw

# flare.creation\_traces

Description of the flare.creation\_traces table on Dune

## Table Description

The `flare.creation_traces` table contains information about the creation of smart contracts on the flare blockchain. This includes the address of the contract, the address of the creator, the block number at which the contract was created, the transaction hash, and the contract's bytecode. This table is useful for understanding the deployment of smart contracts on the flare blockchain.

This table is a subset of the `traces` table, which contains information about all traces on the flare blockchain. The `creation_traces` table is filtered to only include traces that create new smart contracts. The filter for this is `type = 'create'` .

## Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## Table Sample

## Examples

### Show the creation of a specific smart contract

```
SELECT * FROM flare.creation_traces
WHERE contract_address = 0x06012c8cf97bead5deae237070f9587f8e7a266d
```

### Show the creation of smart contracts by a specific creator

```
SELECT * FROM flare.creation_traces
WHERE "from" = 0x0d4a11d5eeaac28ec3f61d100da81f6a1b65c9d6
```

### Show the creation of smart contracts in the last 10 days

```
SELECT 
    date_trunc('day', block_time) AS day,
    COUNT(*)
FROM flare.creation_traces
GROUP BY 1
ORDER BY 1 DESC
LIMIT 10
```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/flare/raw/creation-traces)

[Blocks](/data-catalog/evm/flare/raw/blocks)[Logs](/data-catalog/evm/flare/raw/logs)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.