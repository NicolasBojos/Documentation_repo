[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Raw

flare.traces

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare

  + [Overview](/data-catalog/evm/flare/overview)
  + Raw

    - [Blocks](/data-catalog/evm/flare/raw/blocks)
    - [Creation Traces](/data-catalog/evm/flare/raw/creation-traces)
    - [Logs](/data-catalog/evm/flare/raw/logs)
    - [Transactions](/data-catalog/evm/flare/raw/transactions)
    - [Traces](/data-catalog/evm/flare/raw/traces)
  + Decoded
  + Curated
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

Raw

# flare.traces

Description of the flare.traces table on Dune

## Table Description

The `flare.traces` table contains the traces of the transactions executed on the Ethereum Virtual Machine (EVM). It includes the traces of the transaction and the traces of the internal transactions. Traces are the result of the execution of the transaction and are used to debug and understand the execution of the transaction. They are also known as `internal transactions` and can be used to understand the execution of a transaction.

This is the raw version of this table. If the chain is a Fully Managed chain, decoded transaction calls will be available, see [call tables](/data-catalog/evm/flare/decoded/call-tables) section. If this is a Hosted chain, decoded call tables will not be available.

## Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## Table Sample

## Example

### Querying traces for a specific transaction hash

```
SELECT *
FROM flare.traces
WHERE tx_hash = 0xb30d6d67cf7d148c2257bf598c5f5cdf5912a3d05c7d3b000398d675d2fa912c

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/flare/raw/traces)

[Transactions](/data-catalog/evm/flare/raw/transactions)[Flare Chain Decoded Overview](/data-catalog/evm/flare/decoded/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.