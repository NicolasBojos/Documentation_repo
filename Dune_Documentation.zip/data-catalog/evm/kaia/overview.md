[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

KAIA

KAIA Chain Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA

  + [Overview](/data-catalog/evm/kaia/overview)
  + Raw
  + Decoded
  + Curated
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is KAIA?](#what-is-kaia%3F)
* [Key Features of KAIA](#key-features-of-kaia)
* [Immediate Finality and High Throughput](#immediate-finality-and-high-throughput)
* [Low-Cost Transactions](#low-cost-transactions)
* [EVM Compatibility](#evm-compatibility)
* [Network Architecture](#network-architecture)
* [Node Types in KAIA](#node-types-in-kaia)
* [Consensus Mechanism](#consensus-mechanism)
* [Security and Interoperability](#security-and-interoperability)
* [Token Economy](#token-economy)
* [Governance and Transparency](#governance-and-transparency)
* [Why KAIA?](#why-kaia%3F)
* [Data Catalog](#data-catalog)

KAIA

# KAIA Chain Overview

KAIA blockchain data on Dune

## [​](#what-is-kaia%3F) What is KAIA?

KAIA is a highly optimized, BFT-based public blockchain designed to meet the performance and reliability needs of enterprises. With features like immediate finality, high transaction throughput, and EVM compatibility, KAIA provides a robust infrastructure for blockchain applications across industries.
KAIA’s network architecture and consensus mechanism prioritize security and scalability, making it a preferred choice for businesses looking to deploy fast, cost-effective, and scalable blockchain solutions.

## [​](#key-features-of-kaia) Key Features of KAIA

KAIA’s infrastructure is built around a few core design goals, ensuring its suitability for enterprise and real-world use cases. These goals drive the performance and flexibility of the blockchain.

### [​](#immediate-finality-and-high-throughput) **Immediate Finality and High Throughput**

KAIA enables 1-second block generation, confirming transactions with immediate finality. The network supports up to **4,000 transactions per second (TPS)**, providing the speed and reliability needed for real-time applications.

### [​](#low-cost-transactions) **Low-Cost Transactions**

KAIA offers transaction costs at approximately 1/10th the price of Ethereum, making it more accessible for businesses and developers looking to scale operations without high gas fees.

### [​](#evm-compatibility) **EVM Compatibility**

KAIA is fully compatible with the Ethereum Virtual Machine (EVM), supporting Solidity contracts. This makes it easy for Ethereum developers to migrate their applications to KAIA with minimal changes, leveraging familiar tools like Remix, Hardhat, and Foundry.

## [​](#network-architecture) Network Architecture

KAIA’s network architecture is divided into three logical subnetworks that work together to ensure high performance, scalability, and efficient resource utilization.

* **Core Cell Network (CCN):** Responsible for transaction verification, block creation, and execution.
* **Endpoint Node Network (ENN):** Handles API requests and processes data for auxiliary service chains.
* **Service Chain Network (SCN):** Operates independently while connected to the main chain, enabling scalable dApp development.

### [​](#node-types-in-kaia) **Node Types in KAIA**

KAIA employs a tiered architecture with several types of nodes, each serving specific roles:

* **Consensus Node (CN):** Generates blocks and participates in the consensus process.
* **Proxy Node (PN):** Handles transaction requests and network communication.
* **Endpoint Node (EN):** Processes API requests and ensures data flow for service chains.

## [​](#consensus-mechanism) Consensus Mechanism

KAIA utilizes an optimized version of Istanbul BFT (Practical Byzantine Fault Tolerance) for its consensus. This ensures:

* **Fast Block Finality:** No forks or transaction reversals, providing certainty for real-time applications.
* **Verifiable Random Function (VRF):** Used for selecting block proposers, adding randomness to enhance security and decentralization.

## [​](#security-and-interoperability) Security and Interoperability

KAIA incorporates several security measures to protect the integrity of its network:

* **Validator Key Separation:** Ensures that keys used for validation are kept separate from reward keys, reducing the risk of key theft.
* **Cross-Chain Compatibility:** EVM compatibility allows KAIA to interoperate with other EVM-based chains, supporting cross-chain transactions and smart contract execution.

## [​](#token-economy) Token Economy

KAIA’s native token, **KAIA**, plays a central role in its economy:

* **Block Rewards:** Distributed to validators and stakers to incentivize network participation.
* **Inflation Rate:** Initially set at 5.2% annually, with block rewards allocated between creators, stakers, and ecosystem funds to support development and infrastructure.

## [​](#governance-and-transparency) Governance and Transparency

KAIA operates with an on-chain governance system where voting power is based on staked KAIA tokens. Governance ensures:

* **Fair Representation:** Voting rights are capped to prevent dominance by large stakeholders.
* **Delegation Allowed:** Token holders can delegate voting power to trusted representatives.
* **Transparency:** All governance proposals and transactions are recorded on-chain, ensuring full auditability.

## [​](#why-kaia%3F) Why KAIA?

KAIA is built to lead Web3 adoption in Asia by offering high-performance, low-cost infrastructure for businesses of all sizes. It provides real-world asset (RWA) linkage, abundant liquidity support, and convenient development tools, making it an attractive platform for decentralized applications across various sectors.

[## KAIA documentation

Access comprehensive documentation for KAIA, providing detailed insights into its zk-Rollup technology, platform architecture, and how to build on it.](https://docs.kaia.io/learn/)

## [​](#data-catalog) Data Catalog

[## Logs

Detailed event logs from smart contracts, offering insights into contract interactions and the dynamics of kaia’s zk-Rollup operations.](./raw/logs)[## Blocks

Information on blocks processed through KAIA’s zk-Rollups, illustrating the network’s enhanced throughput and scalability.](./raw/blocks)[## Transactions

Extensive transaction data, highlighting the efficiency and reduced costs of operations on kaia.](./raw/transactions)[## decoded

Decoded transaction data for easier analysis and deeper understanding of smart contract executions on the kaia network.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/kaia/overview)

[NFT Trades](/data-catalog/evm/ink/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/kaia/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.