[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Hemi

Hemi Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi

  + [Overview](/data-catalog/evm/hemi/overview)
  + Raw
  + Decoded
  + Curated
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is Hemi?](#what-is-hemi%3F)
* [Key Features](#key-features)
* [Ecosystem Highlights](#ecosystem-highlights)
* [Data on Dune](#data-on-dune)
* [Resources](#resources)

Hemi

# Hemi Overview

Hemi data on Dune

## [​](#what-is-hemi%3F) What is Hemi?

Hemi is a modular Layer-2 protocol that provides superior scaling, security, and interoperability by combining the power of Bitcoin and Ethereum. Unlike other projects that treat Bitcoin and Ethereum as separate ecosystem silos, Hemi views them as components of a single supernetwork, unlocking new levels of programmability, portability, and potential.

## [​](#key-features) Key Features

* **Bitcoin-Ethereum Integration**: Combines Bitcoin and Ethereum as components of a supernetwork
* **Hemi Virtual Machine (hVM)**: Incorporates a full Bitcoin node within an Ethereum Virtual Machine
* **Proof-of-Proof (PoP) Consensus**: Ensures transactions surpass Bitcoin’s security level in hours
* **Trustless Cross-chain Portability**: Secure asset transfers between Hemi and other chains via “Tunnels”
* **Bitcoin Programmability**: Smart contracts with granular indexed views of Bitcoin state
* **Extensibility**: Allows external projects to create chains secured by Hemi’s technology

## [​](#ecosystem-highlights) Ecosystem Highlights

* Modular Layer-2 protocol for superior scaling and security
* Full integration of Bitcoin and Ethereum ecosystems
* Advanced on-chain functionalities including routing, time-lock, and password protection
* Bitcoin-Security-as-a-Service capabilities
* Enhanced dual-chain interoperability and asset handling

## [​](#data-on-dune) Data on Dune

[## Raw Data

Access to raw blockchain data including blocks, transactions, logs, and traces](/data-catalog/evm/hemi/raw/blocks)[## Decoded Data

Human-readable contract interactions and events](/data-catalog/evm/hemi/decoded/overview)

## [​](#resources) Resources

[## Hemi Documentation

Official documentation for developers building on Hemi](https://docs.hemi.xyz/)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/hemi/overview)

[NFT Trades](/data-catalog/evm/gnosis/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/hemi/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.