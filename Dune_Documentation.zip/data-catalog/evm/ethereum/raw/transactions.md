[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Raw

ethereum.transactions

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum

  + [Overview](/data-catalog/evm/ethereum/overview)
  + Raw

    - [Transactions](/data-catalog/evm/ethereum/raw/transactions)
    - [Logs](/data-catalog/evm/ethereum/raw/logs)
    - [Traces](/data-catalog/evm/ethereum/raw/traces)
    - [Creation Traces](/data-catalog/evm/ethereum/raw/creation-traces)
    - [Blocks](/data-catalog/evm/ethereum/raw/blocks)
    - [Withdrawals](/data-catalog/evm/ethereum/raw/withdrawals)
  + Decoded
  + Curated
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)
* [Examples](#examples)
* [Show all transactions sent by a specific address](#show-all-transactions-sent-by-a-specific-address)
* [Count the number of transactions per block](#count-the-number-of-transactions-per-block)
* [Show the top 10 transactions with the highest gas price](#show-the-top-10-transactions-with-the-highest-gas-price)

Raw

# ethereum.transactions

Description of the ethereum.transactions table on Dune

## [​](#table-description) Table Description

The `transactions` table contains information about all transactions on the Ethereum blockchain. Each row represents a single transaction and includes information such as block number, hash, timestamp, sender, recipient, value, gas, gas price, and more.
Transactions are the fundamental unit of interaction with the Ethereum blockchain. Transactions are created by users and are used to send value, deploy smart contracts, and interact with smart contracts.
This is the raw version of this table, for decoded transaction calls, see the [call tables](/data-catalog/evm/ethereum/decoded/call-tables) section.

## [​](#column-descriptions) Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## [​](#table-sample) Table Sample

## [​](#examples) Examples

### [​](#show-all-transactions-sent-by-a-specific-address) Show all transactions sent by a specific address

Copy

Ask AI

```
select * 
from ethereum.transactions where "from" = 0x50A1b5c358F8D34F0d35aA2f10742c46054E247e

```

### [​](#count-the-number-of-transactions-per-block) Count the number of transactions per block

Copy

Ask AI

```
SELECT 
    block_number, 
    COUNT(*)
FROM ethereum.transactions
GROUP BY 1
ORDER BY 1 DESC
LIMIT 10

```

### [​](#show-the-top-10-transactions-with-the-highest-gas-price) Show the top 10 transactions with the highest gas price

Copy

Ask AI

```
SELECT 
    hash, 
    gas_price
FROM ethereum.transactions
ORDER BY gas_price DESC
LIMIT 10

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/ethereum/raw/transactions)

[Overview](/data-catalog/evm/ethereum/overview)[Logs](/data-catalog/evm/ethereum/raw/logs)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.