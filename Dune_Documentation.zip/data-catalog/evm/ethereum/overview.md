[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Ethereum

Ethereum Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum

  + [Overview](/data-catalog/evm/ethereum/overview)
  + Raw
  + Decoded
  + Curated
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Catalog](#data-catalog)

Ethereum

# Ethereum Overview

Ethereum data on Dune

Ethereum is a decentralized, open-source blockchain system that features its own cryptocurrency, Ether. It is a platform for numerous decentralized applications (dApps), including everything from financial tools to games and complex databases. Ethereum is well-known for its flexibility and its pioneering role in the introduction and use of smart contracts, which are self-executing contracts with the terms of the agreement directly written into code.
The network supports a broad range of applications due to its general-purpose nature, and it operates on a proof-of-stake consensus mechanism, enhancing its scalability and energy efficiency compared to earlier proof-of-work systems.
**Versatility and Developer Support:**
Ethereum supports the creation of a wide variety of applications beyond simple transactions. This includes decentralized finance (DeFi) applications, NFTs, and more, supported by a robust development toolkit and a strong global community.
**Smart Contract Functionality:**
Ethereum’s use of smart contracts automates enforcement, management, performance, and payment — they execute automatically when conditions are met.

[## Ethereum documentation

The official documentation for Ethereum, providing a wealth of resources on how to build on and interact with the platform.](https://ethereum.org/en/developers/docs/)

## [​](#data-catalog) Data Catalog

[## Logs

Event logs from smart contracts, showcasing the diverse and dynamic usage of Ethereum’s decentralized platform.](./raw/logs)[## Blocks

Information on Ethereum blocks, reflecting the network’s activity and scalability achievements.](./raw/blocks)[## Transactions

Detailed information on transactions, underscoring the high throughput and complexity of operations on Ethereum.](./raw/transactions)[## decoded

Decoded transaction data, facilitating easier analysis and deeper understanding of smart contract operations.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/ethereum/overview)

[Traces](/data-catalog/evm/degen/raw/traces)[Transactions](/data-catalog/evm/ethereum/raw/transactions)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.