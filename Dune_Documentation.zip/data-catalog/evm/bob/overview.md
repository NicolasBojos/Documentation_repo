[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

BOB

BOB Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB

  + [Overview](/data-catalog/evm/bob/overview)
  + Raw
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is BOB?](#what-is-bob%3F)
* [Why Hybrid L2?](#why-hybrid-l2%3F)
* [BOB Architecture](#bob-architecture)
* [BOB Stack](#bob-stack)
* [BOB Rollup Design](#bob-rollup-design)
* [Data Catalog](#data-catalog)

BOB

# BOB Overview

BOB data on Dune

## [​](#what-is-bob%3F) What is BOB?

BOB (“Build on Bitcoin”) is a first-of-its-kind hybrid Layer-2 powered by Bitcoin and Ethereum. It combines the security, liquidity, and userbase of Bitcoin with the innovation capabilities of Ethereum’s EVM. BOB aims to become the most secure and accessible Layer-2 for developers and users.

### [​](#why-hybrid-l2%3F) Why Hybrid L2?

BOB leverages Bitcoin’s robustness and Ethereum’s smart contract capabilities to bridge the gap between mass adoption and innovation. It allows developers to build dapps on a network with the highest security and user base while providing Bitcoin users access to Ethereum’s innovative ecosystem without leaving the Bitcoin network.

### [​](#bob-architecture) BOB Architecture

#### [​](#bob-stack) BOB Stack

![](https://mintlify.s3.us-west-1.amazonaws.com/dune/images/bob-stack.png)

**Rollup Layer**: Utilizing Bitcoin’s PoW security and native Ethereum bridge, BOB initially launches on the OP stack, aiming to settle directly on Bitcoin L1 using merged mining and optimistic rollup mechanisms.
**EVM Core**: At its core, BOB leverages Ethereum’s EVM, supporting Solidity smart contracts, existing developer tooling, wallets, and infrastructure components like block explorers and data analytics tools.
**Rust zkVM**: Supporting Bitcoin’s Rust libraries through RISC Zero zkVM, enabling off-chain execution of Rust programs with ZK proofs verified in EVM smart contracts. This paves the way for future ZK rollups on Bitcoin.
**Bitcoin Bridges**: BOB provides trustless access to Bitcoin block and transactional data via a BTC light client, supporting a range of decentralized and institutional Bitcoin bridges for seamless interaction with Ethereum assets.
**BOB SDK**: A comprehensive toolkit for developers building on Bitcoin, offering Solidity contracts to interact with Bitcoin assets, improved APIs, and tools for a unified BTC and EVM wallet experience.

#### [​](#bob-rollup-design) BOB Rollup Design

BOB’s hybrid L2 design will be launched in multiple stages:

* **Phase 1 (“Launch”)**: Bootstrapping as an ETH rollup.
* **Phase 2**: Bitcoin PoW security and economic alignment through merged mining.
* **Phase 3**: Hybrid L2 with settlement on Bitcoin and Ethereum, leveraging BitVM for security.

[## BOB documentation

Explore comprehensive documentation on BOB, detailing its architecture, protocol, and resources for developers.](https://docs.gobob.xyz/docs/learn/introduction/stack)

## [​](#data-catalog) Data Catalog

[## Logs

Detailed event logs from smart contracts, providing insights into interactions within the BOB network.](./raw/logs)[## Blocks

Information on blocks, illustrating the operational capacity and activity levels on BOB.](./raw/blocks)[## Transactions

Extensive transaction data, showcasing the efficiency and execution of operations on BOB.](./raw/transactions)[## Traces

Enhanced transaction data, including internal transactions invoked by top level transactions.](./raw/traces)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/bob/overview)

[NFT Trades](/data-catalog/evm/bnb/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/bob/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.