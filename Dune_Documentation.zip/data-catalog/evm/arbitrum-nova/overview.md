[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Arbitrum Nova

Arbitrum One Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova

  + [Overview](/data-catalog/evm/arbitrum-nova/overview)
  + Raw
  + Decoded
  + Curated
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is Arbitrum Nova?](#what-is-arbitrum-nova%3F)
* [Why Arbitrum Nova?](#why-arbitrum-nova%3F)
* [Arbitrum Nova Architecture](#arbitrum-nova-architecture)
* [AnyTrust Technology](#anytrust-technology)
* [Rollup Mechanism](#rollup-mechanism)
* [Compatibility with Ethereum](#compatibility-with-ethereum)
* [Arbitrum Ecosystem](#arbitrum-ecosystem)
* [Utility Token](#utility-token)
* [Data Catalog](#data-catalog)

Arbitrum Nova

# Arbitrum One Overview

Arbitrum Nova data on Dune

## [​](#what-is-arbitrum-nova%3F) What is Arbitrum Nova?

Arbitrum Nova is a Layer 2 scaling solution on Ethereum that leverages the AnyTrust technology to provide efficient, low-cost transactions while maintaining high security and compatibility with the Ethereum ecosystem. As part of the Arbitrum family, Nova complements Arbitrum One by offering a different balance of security and transaction cost options for users and developers.

## [​](#why-arbitrum-nova%3F) Why Arbitrum Nova?

Arbitrum Nova is designed to handle high transaction volumes at a lower cost, making it ideal for applications such as gaming, social networks, and other scenarios where frequent, low-cost transactions are essential. It uses the AnyTrust protocol, which optimizes security and efficiency, ensuring that transactions are both economical and secure.

## [​](#arbitrum-nova-architecture) Arbitrum Nova Architecture

Arbitrum Nova’s architecture is built to maximize scalability and minimize transaction costs through its unique AnyTrust solution:

### [​](#anytrust-technology) AnyTrust Technology

At the core of Arbitrum Nova is the AnyTrust protocol, which provides a flexible approach to transaction validation. This protocol batches transactions and uses a committee of trusted validators to ensure the integrity and security of the data.

### [​](#rollup-mechanism) Rollup Mechanism

Similar to Arbitrum One, Nova batches multiple transactions into a single rollup block. This rollup mechanism significantly increases throughput and reduces transaction costs by spreading the computational load across multiple transactions.

### [​](#compatibility-with-ethereum) Compatibility with Ethereum

Arbitrum Nova maintains full compatibility with the Ethereum Virtual Machine (EVM), allowing developers to deploy their existing Solidity smart contracts on Nova without modifications. This seamless integration with Ethereum ensures that Nova can support a wide range of decentralized applications (dApps) with ease.

## [​](#arbitrum-ecosystem) Arbitrum Ecosystem

Arbitrum offers two main chains on Ethereum: Arbitrum One, an Optimistic Rollup chain, and Arbitrum Nova, an AnyTrust chain. This dual-chain strategy allows users and developers to choose the solution that best fits their needs in terms of security and transaction costs.

### [​](#utility-token) Utility Token

Ether (ETH) is the primary utility token on Arbitrum Nova, used for paying transaction fees. This alignment with Ethereum’s native currency simplifies the user experience and enhances interoperability within the Ethereum ecosystem.

[## Arbitrum One Website

The official page for Arbitrum Nova (an AnyTrust chain), offering comprehensive details on the platform, its architecture, and resources for developers](https://arbitrum.io/anytrust)

## [​](#data-catalog) Data Catalog

[## Logs

Insights into smart contract interactions through event logs](./raw/logs)[## Blocks

Information on blocks processed on Arbitrum One, reflecting network activity and capacity](./raw/blocks)[## Transactions

Detailed data on transactions, showcasing efficiency and operational execution](./raw/transactions)[## decoded

Decoded transaction information for enhanced analysis and understanding of smart contract executions](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/arbitrum-nova/overview)

[NFT Trades](/data-catalog/evm/arbitrum/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/arbitrum-nova/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.