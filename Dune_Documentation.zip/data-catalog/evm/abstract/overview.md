[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Abstract

Abstract Chain Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract

  + [Overview](/data-catalog/evm/abstract/overview)
  + Raw
  + Decoded
  + Curated
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is Abstract?](#what-is-abstract%3F)
* [Key Features of Abstract](#key-features-of-abstract)
* [Layer 2 ZK Rollup Architecture](#layer-2-zk-rollup-architecture)
* [EVM Compatibility with Optimized VM](#evm-compatibility-with-optimized-vm)
* [Lower Gas Fees and Higher Throughput](#lower-gas-fees-and-higher-throughput)
* [Transaction Lifecycle](#transaction-lifecycle)
* [EVM Differences](#evm-differences)
* [Why Abstract?](#why-abstract%3F)
* [Data Catalog](#data-catalog)

Abstract

# Abstract Chain Overview

Abstract blockchain data on Dune

## [​](#what-is-abstract%3F) What is Abstract?

Abstract is a Layer 2 (L2) network built on top of Ethereum, designed to securely support consumer-facing blockchain applications at scale. Utilizing zero-knowledge (ZK) rollup technology, Abstract achieves low fees and fast transaction speeds by processing transactions off-chain, then batching and verifying them on Ethereum using ZK proofs.
With EVM compatibility, Abstract allows developers to port existing Ethereum applications with minimal adjustments, providing an Ethereum-like environment but with optimized scalability and reduced costs.

## [​](#key-features-of-abstract) Key Features of Abstract

Abstract’s infrastructure is built with a focus on scalability, security, and developer accessibility, offering several powerful features:

### [​](#layer-2-zk-rollup-architecture) **Layer 2 ZK Rollup Architecture**

Abstract batches transactions off-chain and posts them to Ethereum for security, inheriting Ethereum’s security properties while enabling faster, more cost-effective transactions. This ZK rollup structure ensures that all state transitions are verified without executing transactions on Ethereum.

### [​](#evm-compatibility-with-optimized-vm) **EVM Compatibility with Optimized VM**

Abstract maintains compatibility with the Ethereum ecosystem, allowing developers to use familiar tools. However, Abstract’s ZKsync VM utilizes optimized bytecode and opcodes to facilitate efficient ZK proof generation, offering unique ways for developers to build scalable applications.

### [​](#lower-gas-fees-and-higher-throughput) **Lower Gas Fees and Higher Throughput**

Gas fees on Abstract are significantly lower than on Ethereum, thanks to batch processing and ZK proofing. This reduction in transaction costs, coupled with high throughput, makes Abstract ideal for high-demand applications.

## [​](#transaction-lifecycle) Transaction Lifecycle

Each transaction on Abstract undergoes a lifecycle that includes four key stages:

1. **Processing on Abstract**: Transactions are executed on Abstract, and soft confirmation is provided to the user.
2. **Batch Submission to Ethereum**: Transactions are batched and committed to Ethereum in optimized submissions.
3. **Proof Validation**: A ZK proof validating the batch is generated off-chain and verified by Ethereum.
4. **State Finalization**: Once verified, the state is finalized, ensuring transaction accuracy on Ethereum.

## [​](#evm-differences) EVM Differences

While compatible with Ethereum’s development environment, Abstract’s ZKsync VM introduces specific changes for optimized performance:

* **Opcode Adjustments**: Certain opcodes are modified or supplemented by system contracts.
* **Gas Fee Management**: Fees and refunds are handled differently via Abstract’s bootloader.
* **Nonces and Libraries**: Nonces are stored within smart contract accounts, and library handling is adapted for efficiency.

## [​](#why-abstract%3F) Why Abstract?

Abstract combines Ethereum’s security with the scalability of ZK rollups, making it ideal for applications requiring high throughput and low transaction costs. This enables developers to build consumer-ready dApps without sacrificing speed, cost-efficiency, or security.

[## Abstract documentation

Access full documentation for Abstract, including architecture, EVM differences, and best practices.](https://docs.abs.xyz/overview)

## [​](#data-catalog) Data Catalog

[## Logs

Smart contract event logs with insights into Abstract’s ZK rollup dynamics.](./raw/logs)[## Blocks

Information on processed blocks, highlighting Abstract’s throughput.](./raw/blocks)[## Transactions

Data on transactions, illustrating Abstract’s cost-effective operation.](./raw/transactions)[## Decoded

Decoded transaction data for in-depth analysis of contract executions.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/abstract/overview)

[Overview](/data-catalog/evm/overview)[Blocks](/data-catalog/evm/abstract/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.