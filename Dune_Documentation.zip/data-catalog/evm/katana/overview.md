[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Katana

Katana Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana

  + [Overview](/data-catalog/evm/katana/overview)
  + Raw
  + Decoded
  + Curated
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is Katana?](#what-is-katana%3F)
* [Key Features](#key-features)
* [High Performance](#high-performance)
* [Developer Experience](#developer-experience)
* [Security and Infrastructure](#security-and-infrastructure)
* [Data Catalog](#data-catalog)

Katana

# Katana Overview

Katana data on Dune

## [​](#what-is-katana%3F) What is Katana?

Katana is a high-performance blockchain platform designed for scalability and developer experience. It provides a robust infrastructure for building decentralized applications with advanced features and optimized performance.

## [​](#key-features) Key Features

### [​](#high-performance) High Performance

* Optimized for high-frequency trading and DeFi applications
* Supports thousands of transactions per second
* Low latency transaction confirmations

### [​](#developer-experience) Developer Experience

* Full EVM compatibility with enhanced capabilities
* Comprehensive developer tools and SDKs
* Easy deployment and management of smart contracts

### [​](#security-and-infrastructure) Security and Infrastructure

* Robust security model with multiple layers of protection
* Advanced cryptographic protocols for transaction validation
* Distributed network architecture for enhanced reliability

[## Katana Documentation

Official documentation and resources for developers building on Katana](https://app.katana.network/krates)

## [​](#data-catalog) Data Catalog

[## Logs

Insights into smart contract interactions through event logs](./raw/logs)[## Blocks

Information on blocks processed on Katana](./raw/blocks)[## Transactions

Detailed data on transactions](./raw/transactions)[## decoded

Decoded transaction information for enhanced analysis](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/katana/overview)

[NFT Trades](/data-catalog/evm/kaia/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/katana/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.