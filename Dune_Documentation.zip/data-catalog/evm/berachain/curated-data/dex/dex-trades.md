[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

DEX

dex.trades on berachain

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain

  + [Overview](/data-catalog/evm/berachain/overview)
  + Raw
  + Decoded
  + Curated

    - DEX

      * [Dex Trades](/data-catalog/evm/berachain/curated-data/dex/dex-trades)
      * [Aggregator Trades](/data-catalog/evm/berachain/curated-data/dex/dex-aggregator-trades)
    - NFT
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

DEX

# dex.trades on berachain

The `dex.trades` table captures detailed data on decentralized exchange (DEX) trades, recording all raw trade events across various protocols on berachain.

This is a cross-chain table but can be filtered for berachain transactions.

## Table Description

The `dex.trades` table captures detailed data on trades executed via decentralized exchanges (DEXs). This table captures all raw trade events that happen across all liqudity pools. It provides a comprehensive view of the entire trade execution process, detailing the specific paths and liquidity sources utilized.

## Functional Overview

The `dex.trades` table provides an in-depth view of trades on decentralized exchanges like Uniswap or Curve. This table includes entries for each segment of a trade that passes through different liquidity pools, as well as single-step trades. For example, a user may initiate a trade to swap USDC for PEPE. If this trade is executed through multiple liquidity pools, such as USDC-WETH and WETH-PEPE, the `dex.trades` table will record each segment of the trade as a separate entry. Conversely, a single-step trade, such as directly swapping USDC for ETH, will be recorded as a single entry.This detailed approach allows for granular analysis of trade execution paths, enabling users to:

* **Analyze Liquidity Sources:** Understand which liquidity pools are used and how they interact in both single-step and multi-step trades.
* **Track Trade Execution Paths:** Follow the exact route a trade takes across different DEXs and liquidity pools
* **Assess Slippage and Execution Quality:** Evaluate the impact of each step on the overall trade execution, including slippage and price changes.
* **Monitor Market Dynamics:** Gain insights into the behavior and dynamics of different liquidity pools and DEXs over time.

## Table Coverage

 The following table shows which projects and versions of those projects are covered in the `dex.trades` table on berachain. 

## Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/berachain/curated-data/dex/dex-trades)

[Decoded Traces](/data-catalog/evm/berachain/decoded/traces-decoded)[Aggregator Trades](/data-catalog/evm/berachain/curated-data/dex/dex-aggregator-trades)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.