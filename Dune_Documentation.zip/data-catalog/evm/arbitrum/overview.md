[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Arbitrum One

Arbitrum One Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One

  + [Overview](/data-catalog/evm/arbitrum/overview)
  + Raw
  + Decoded
  + Curated
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Catalog](#data-catalog)

Arbitrum One

# Arbitrum One Overview

Arbitrum One data on Dune

Arbitrum One is a Layer 2 scaling solution built on Ethereum that utilizes optimistic rollups to enhance scalability and reduce costs while maintaining compatibility with the Ethereum Virtual Machine (EVM). This allows developers to deploy their existing Solidity smart contracts on Arbitrum without any modifications.
At the heart of Arbitrum One’s technology is its unique rollup solution, which batches multiple transactions into a single rollup block. This technique dramatically increases throughput and decreases the transaction costs, all while leveraging the underlying security of the Ethereum mainnet.
The primary utility token of Arbitrum One is Ether, which is used for paying transaction fees. Unlike traditional Layer 1 solutions, Arbitrum One offers a seamless extension of Ethereum, enhancing its scalability and efficiency without compromising on security or decentralization.
Dune provides extensive datasets for Arbitrum One, covering various aspects such as event logs, transactions, blocks, and token movements. These datasets provide valuable insights into network performance, user behavior, and smart contract functionality.

[## Arbitrum One docs

The official documentation for Arbitrum One, offering comprehensive details on the platform, its architecture, and resources for developers](https://arbitrum.io/docs)

## [​](#data-catalog) Data Catalog

[## Logs

Insights into smart contract interactions through event logs](./raw/logs)[## Blocks

Information on blocks processed on Arbitrum One, reflecting network activity and capacity](./raw/blocks)[## Transactions

Detailed data on transactions, showcasing efficiency and operational execution](./raw/transactions)[## decoded

Decoded transaction information for enhanced analysis and understanding of smart contract executions](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/arbitrum/overview)

[NFT Trades](/data-catalog/evm/apechain/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/arbitrum/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.