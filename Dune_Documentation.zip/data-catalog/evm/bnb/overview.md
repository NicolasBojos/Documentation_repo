[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

BNB

BNB Chain Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB

  + [Overview](/data-catalog/evm/bnb/overview)
  + Raw
  + Decoded
  + Curated
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Catalog](#data-catalog)

BNB

# BNB Chain Overview

BNB Chain data on Dune

BNB Chain is a high-performance blockchain network developed by Binance that supports the creation and functionality of decentralized applications (dApps). It is designed to provide scalability and high throughput with low transaction costs, targeting a broad and global user base.
BNB Chain operates as a dual-chain architecture, which combines the capabilities of Binance Chain (BC) and Binance Smart Chain (BSC) into a single ecosystem. This design supports interoperability and flexible user experiences, allowing transfers and cross-chain communication between different blockchains.
**Efficient and Economical:**
BNB Chain provides a scalable infrastructure with significantly reduced transaction fees, making it accessible for a wide range of applications, from small transactions to large-scale dApps.
**EVM Compatibility:**
It fully supports Ethereum Virtual Machine (EVM) compatible applications, enabling developers to migrate Ethereum-based dApps to BNB Chain with minimal adjustments and utilize the existing developer tools and ecosystem.
**Robust Community and Ecosystem:**
BNB Chain benefits from the strong community support and the extensive ecosystem of Binance, including integrations with Binance’s marketplaces, services, and large user base.

[## BNB Chain documentation

Access the official documentation for BNB Chain, offering detailed guides on its technology, architecture, and resources for developers.](https://docs.bnbchain.org)

## [​](#data-catalog) Data Catalog

[## Logs

Event logs from smart contracts, offering insights into interactions and activities on BNB Chain.](./raw/logs)[## Blocks

Data on blocks processed, indicating network activity and operational capacity on BNB Chain.](./raw/blocks)[## Transactions

Detailed information on transactions, illustrating operational efficiency and execution on the network.](./raw/transactions)[## decoded

Decoded transaction data for easier analysis and better understanding of smart contract executions.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/bnb/overview)

[NFT Trades](/data-catalog/evm/blast/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/bnb/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.