[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Raw

bnb.blocks

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB

  + [Overview](/data-catalog/evm/bnb/overview)
  + Raw

    - [Blocks](/data-catalog/evm/bnb/raw/blocks)
    - [Creation Traces](/data-catalog/evm/bnb/raw/creation-traces)
    - [Logs](/data-catalog/evm/bnb/raw/logs)
    - [Transactions](/data-catalog/evm/bnb/raw/transactions)
    - [Traces](/data-catalog/evm/bnb/raw/traces)
  + Decoded
  + Curated
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

Raw

# bnb.blocks

Description of the bnb.blocks table on Dune

## Table description

The `bnb.blocks` table contains information about blocks in the bnb blockchain. A block is a collection of transactions that are hashed and added to the blockchain. Each block contains a reference to the previous block, known as the parent hash, and a timestamp. The table contains information about each block, such as the block number, the block hash, the block size, the number of transactions, and the gas used.

## Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## Table Sample

## Examples

### Show the most recent blocks

```
SELECT
    number,
    hash, 
    size,
    gas_used
  FROM bnb.blocks
  ORDER BY number DESC
  LIMIT 10
```

### Show the number of blocks mined each day

```
SELECT
    date_trunc('day', time) AS day,
    count(distinct number)
  FROM bnb.blocks
  GROUP BY day
  ORDER BY day DESC
```

### Show the number of transactions in each block

```
SELECT
    number,
    count(*)
  FROM bnb.blocks
  GROUP BY 1 
  LIMIT 10
```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/bnb/raw/blocks)

[Overview](/data-catalog/evm/bnb/overview)[Creation Traces](/data-catalog/evm/bnb/raw/creation-traces)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.