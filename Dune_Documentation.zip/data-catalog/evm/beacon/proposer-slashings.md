[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Beacon

beacon.proposer\_slashings

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon

  + [Overview](/data-catalog/evm/beacon/overview)
  + [Attestations](/data-catalog/evm/beacon/attestations)
  + [Attester Slashings](/data-catalog/evm/beacon/attester-slashings)
  + [Blobs](/data-catalog/evm/beacon/blobs)
  + [Blocks](/data-catalog/evm/beacon/blocks)
  + [BLS To Execution Changes](/data-catalog/evm/beacon/bls-to-execution-changes)
  + [Deposits](/data-catalog/evm/beacon/deposits)
  + [Epoch Summaries](/data-catalog/evm/beacon/epoch-summaries)
  + [Operators](/data-catalog/evm/beacon/operators)
  + [Proposer Slashings](/data-catalog/evm/beacon/proposer-slashings)
  + [Raw](/data-catalog/evm/beacon/raw)
  + [Validator Day Summaries](/data-catalog/evm/beacon/validator-day-summaries)
  + [Validators](/data-catalog/evm/beacon/validators)
  + [Voluntary Exits](/data-catalog/evm/beacon/voluntary-exits)
  + [Withdrawals](/data-catalog/evm/beacon/withdrawals)
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Table Sample](#table-sample)

Beacon

# beacon.proposer\_slashings

Description of the beacon.proposer\_slashings table on Dune.

## [​](#table-description) Table Description

Stores information about proposer slashings on the Beacon Chain. A proposer slashing occurs when a validator proposes two conflicting blocks at the same slot. This table contains information about the conflicting blocks and the proposer responsible for the slashing.

| **Column** | **Type** | **Description** |
| --- | --- | --- |
| **block\_epoch** | long | Epoch number when the block containing the proposer slashing was proposed. |
| **block\_slot** | long | Slot number within the epoch when the block containing the proposer slashing was proposed. |
| **block\_time** | timestamp | Timestamp when the block containing the proposer slashing was included in the chain. |
| **block\_date** | date | Date corresponding to the block\_time. |
| **signed\_header\_1\_body\_root** | binary | Root hash of the body of the first conflicting block header. |
| **signed\_header\_1\_parent\_root** | binary | Root hash of the parent block referenced by the first conflicting block header. |
| **signed\_header\_1\_proposer\_index** | long | Validator index of the proposer for the first conflicting block. |
| **signed\_header\_1\_slot** | long | Slot number for which the first conflicting block was proposed. |
| **signed\_header\_1\_state\_root** | binary | Root hash of the state after processing the first conflicting block. |
| **signed\_header\_1\_signature** | binary | BLS signature of the proposer for the first conflicting block. |
| **signed\_header\_2\_body\_root** | binary | Root hash of the body of the second conflicting block header. |
| **signed\_header\_2\_parent\_root** | binary | Root hash of the parent block referenced by the second conflicting block header. |
| **signed\_header\_2\_proposer\_index** | long | Validator index of the proposer for the second conflicting block. |
| **signed\_header\_2\_slot** | long | Slot number for which the second conflicting block was proposed. |
| **signed\_header\_2\_state\_root** | binary | Root hash of the state after processing the second conflicting block. |
| **signed\_header\_2\_signature** | binary | BLS signature of the proposer for the second conflicting block. |

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/beacon/proposer-slashings)

[Operators](/data-catalog/evm/beacon/operators)[Raw](/data-catalog/evm/beacon/raw)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.