[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Beacon

beacon.blocks

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon

  + [Overview](/data-catalog/evm/beacon/overview)
  + [Attestations](/data-catalog/evm/beacon/attestations)
  + [Attester Slashings](/data-catalog/evm/beacon/attester-slashings)
  + [Blobs](/data-catalog/evm/beacon/blobs)
  + [Blocks](/data-catalog/evm/beacon/blocks)
  + [BLS To Execution Changes](/data-catalog/evm/beacon/bls-to-execution-changes)
  + [Deposits](/data-catalog/evm/beacon/deposits)
  + [Epoch Summaries](/data-catalog/evm/beacon/epoch-summaries)
  + [Operators](/data-catalog/evm/beacon/operators)
  + [Proposer Slashings](/data-catalog/evm/beacon/proposer-slashings)
  + [Raw](/data-catalog/evm/beacon/raw)
  + [Validator Day Summaries](/data-catalog/evm/beacon/validator-day-summaries)
  + [Validators](/data-catalog/evm/beacon/validators)
  + [Voluntary Exits](/data-catalog/evm/beacon/voluntary-exits)
  + [Withdrawals](/data-catalog/evm/beacon/withdrawals)
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)

Beacon

# beacon.blocks

Description of the beacon.blocks table on Dune

## [​](#table-description) Table Description

Stores information about blocks in the Ethereum 2.0 Beacon Chain, including the block proposer, block metadata, and the blob sidecar associated with the block.

## [​](#column-descriptions) Column Descriptions

| **Column** | **Type** | **Description** |
| --- | --- | --- |
| **epoch** | long | Epoch number when the block was proposed. |
| **slot** | long | Slot number within the epoch when the block was proposed. |
| **time** | timestamp | Timestamp when the block was included in the chain. |
| **date** | date | Date corresponding to the time. |
| **parent\_root** | binary | Root hash of the parent block, linking to the previous block in the chain. |
| **proposer\_index** | long | Validator index of the block proposer. |
| **state\_root** | binary | Root hash of the state after processing the block, reflecting the system’s state. |
| **execution\_optimistic** | boolean | Indicates if the block is considered optimistic in terms of execution. |
| **finalized** | boolean | Indicates if the block has been finalized. |
| **version** | string | Version of the block structure or protocol. |
| **signature** | binary | BLS signature of the block proposer, ensuring authenticity. |
| **graffiti** | binary | Arbitrary data included by the proposer, often used for identification or messages. |
| **randao\_reveal** | binary | Revealed RANDAO value used for randomness in validator selection. |
| **eth1\_block\_hash** | binary | Hash of the latest Ethereum 1.0 block observed by the proposer. |
| **eth1\_deposit\_count** | long | Number of deposits from Ethereum 1.0 included up to this block. |
| **eth1\_deposit\_root** | binary | Root hash of the deposit tree containing Ethereum 1.0 deposits. |
| **execution\_payload\_timestamp** | long | Timestamp of the execution payload within the block. |
| **execution\_payload\_base\_fee\_per\_gas** | long | Base fee per gas for transactions in the execution payload. |
| **execution\_payload\_block\_hash** | binary | Hash of the execution payload block. |
| **execution\_payload\_block\_number** | long | Block number of the execution payload. |
| **execution\_payload\_extra\_data** | binary | Extra data field in the execution payload, containing arbitrary data. |
| **execution\_payload\_fee\_recipient** | binary | Address of the fee recipient for transaction fees in the execution payload. |
| **execution\_payload\_gas\_limit** | long | Gas limit for the execution payload block. |
| **execution\_payload\_gas\_used** | long | Amount of gas used in the execution payload block. |
| **execution\_payload\_logs\_bloom** | binary | Bloom filter for logs in the execution payload, used for quick log searches. |
| **execution\_payload\_parent\_hash** | binary | Hash of the parent execution payload block. |
| **execution\_payload\_prev\_randao** | binary | Previous RANDAO value in the execution payload, used for randomness. |
| **execution\_payload\_receipts\_root** | binary | Root hash of the receipts trie for transactions in the execution payload. |
| **execution\_payload\_state\_root** | binary | Root hash of the state trie after applying the execution payload. |
| **execution\_payload\_transactions** | array | List of transactions included in the execution payload. |
| **sync\_committee\_bits** | binary | Bitfield indicating which sync committee members have signed off on the block. |
| **sync\_committee\_signature** | binary | Aggregate signature from the sync committee members for the block. |

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/beacon/blocks)

[Blobs](/data-catalog/evm/beacon/blobs)[BLS To Execution Changes](/data-catalog/evm/beacon/bls-to-execution-changes)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.