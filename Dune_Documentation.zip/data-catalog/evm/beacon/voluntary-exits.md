[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Beacon

beacon.voluntary\_exits

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon

  + [Overview](/data-catalog/evm/beacon/overview)
  + [Attestations](/data-catalog/evm/beacon/attestations)
  + [Attester Slashings](/data-catalog/evm/beacon/attester-slashings)
  + [Blobs](/data-catalog/evm/beacon/blobs)
  + [Blocks](/data-catalog/evm/beacon/blocks)
  + [BLS To Execution Changes](/data-catalog/evm/beacon/bls-to-execution-changes)
  + [Deposits](/data-catalog/evm/beacon/deposits)
  + [Epoch Summaries](/data-catalog/evm/beacon/epoch-summaries)
  + [Operators](/data-catalog/evm/beacon/operators)
  + [Proposer Slashings](/data-catalog/evm/beacon/proposer-slashings)
  + [Raw](/data-catalog/evm/beacon/raw)
  + [Validator Day Summaries](/data-catalog/evm/beacon/validator-day-summaries)
  + [Validators](/data-catalog/evm/beacon/validators)
  + [Voluntary Exits](/data-catalog/evm/beacon/voluntary-exits)
  + [Withdrawals](/data-catalog/evm/beacon/withdrawals)
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)

Beacon

# beacon.voluntary\_exits

Description of the beacon.voluntary\_exits table on Dune

## [​](#table-description) Table Description

Stores data about voluntary exits initiated by validators on the Beacon network. This table is partitioned by block\_date.

## [​](#column-descriptions) Column Descriptions

| **Column** | **Type** | **Description** |
| --- | --- | --- |
| **block\_epoch** | long | Epoch number when the block containing the voluntary exit was proposed. |
| **block\_slot** | long | Slot number within the epoch when the block containing the voluntary exit was proposed. |
| **block\_time** | timestamp | Timestamp when the block containing the voluntary exit was included in the chain. |
| **block\_date** | date | Date corresponding to the block\_time. |
| **validator\_index** | long | Unique identifier of the validator initiating the voluntary exit. |
| **signature** | binary | BLS signature authorizing the voluntary exit, ensuring its authenticity. |

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/beacon/voluntary-exits)

[Validators](/data-catalog/evm/beacon/validators)[Withdrawals](/data-catalog/evm/beacon/withdrawals)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.