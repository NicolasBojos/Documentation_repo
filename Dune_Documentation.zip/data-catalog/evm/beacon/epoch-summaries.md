[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Beacon

beacon.epoch\_summaries

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon

  + [Overview](/data-catalog/evm/beacon/overview)
  + [Attestations](/data-catalog/evm/beacon/attestations)
  + [Attester Slashings](/data-catalog/evm/beacon/attester-slashings)
  + [Blobs](/data-catalog/evm/beacon/blobs)
  + [Blocks](/data-catalog/evm/beacon/blocks)
  + [BLS To Execution Changes](/data-catalog/evm/beacon/bls-to-execution-changes)
  + [Deposits](/data-catalog/evm/beacon/deposits)
  + [Epoch Summaries](/data-catalog/evm/beacon/epoch-summaries)
  + [Operators](/data-catalog/evm/beacon/operators)
  + [Proposer Slashings](/data-catalog/evm/beacon/proposer-slashings)
  + [Raw](/data-catalog/evm/beacon/raw)
  + [Validator Day Summaries](/data-catalog/evm/beacon/validator-day-summaries)
  + [Validators](/data-catalog/evm/beacon/validators)
  + [Voluntary Exits](/data-catalog/evm/beacon/voluntary-exits)
  + [Withdrawals](/data-catalog/evm/beacon/withdrawals)
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Table Description](#table-description)
* [Column Descriptions](#column-descriptions)
* [Table Sample](#table-sample)

Beacon

# beacon.epoch\_summaries

Description of the beacon.epoch\_summaries table on Dune.

## [​](#table-description) Table Description

This table is indexed from Lido. Stores summary data for each epoch on the Beacon Chain, including the number of validators, attestations, and other key metrics. This table is partitioned by block\_date.

## [​](#column-descriptions) Column Descriptions

| **Column** | **Type** | **Description** |
| --- | --- | --- |
| **block\_date** | date | Date corresponding to the epoch. |
| **epoch** | bigint | Epoch number representing a specific period in the Beacon Chain. |
| **activation\_queue\_length** | bigint | Number of validators awaiting activation. |
| **activating\_validators** | bigint | Number of validators activated during the epoch. |
| **active\_validators** | bigint | Total number of active validators during the epoch. |
| **active\_real\_balance** | bigint | Total effective balance of active validators, measured in Gwei. |
| **active\_balance** | bigint | Total balance of active validators, measured in Gwei. |
| **attesting\_validators** | bigint | Number of validators who submitted attestations during the epoch. |
| **attesting\_balance** | bigint | Total balance of attesting validators, measured in Gwei. |
| **target\_correct\_validators** | bigint | Number of validators whose attestations correctly identified the target block. |
| **target\_correct\_balance** | bigint | Total balance of target-correct validators, measured in Gwei. |
| **head\_correct\_validators** | bigint | Number of validators whose attestations correctly identified the head block. |
| **head\_correct\_balance** | bigint | Total balance of head-correct validators, measured in Gwei. |
| **attestations\_for\_epoch** | bigint | Number of attestations included in the epoch. |
| **attestations\_in\_epoch** | bigint | Number of attestations referencing the epoch. |
| **duplicate\_attestations\_for\_epoch** | bigint | Number of duplicate attestations included in the epoch. |
| **proposer\_slashings** | bigint | Number of proposer slashing events during the epoch. |
| **attester\_slashings** | bigint | Number of attester slashing events during the epoch. |
| **deposits** | bigint | Number of deposits processed during the epoch. |
| **exiting\_validators** | bigint | Number of validators exiting during the epoch. |
| **canonical\_blocks** | bigint | Number of canonical blocks in the epoch. |
| **withdrawals** | bigint | Number of withdrawals processed during the epoch. |
| **updated\_at** | timestamp | Last time the record was updated |
| **ingested\_at** | timestamp | Time when the record was ingested |

## [​](#table-sample) Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/beacon/epoch-summaries)

[Deposits](/data-catalog/evm/beacon/deposits)[Operators](/data-catalog/evm/beacon/operators)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.