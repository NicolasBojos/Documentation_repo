[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Beacon

Beacon Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon

  + [Overview](/data-catalog/evm/beacon/overview)
  + [Attestations](/data-catalog/evm/beacon/attestations)
  + [Attester Slashings](/data-catalog/evm/beacon/attester-slashings)
  + [Blobs](/data-catalog/evm/beacon/blobs)
  + [Blocks](/data-catalog/evm/beacon/blocks)
  + [BLS To Execution Changes](/data-catalog/evm/beacon/bls-to-execution-changes)
  + [Deposits](/data-catalog/evm/beacon/deposits)
  + [Epoch Summaries](/data-catalog/evm/beacon/epoch-summaries)
  + [Operators](/data-catalog/evm/beacon/operators)
  + [Proposer Slashings](/data-catalog/evm/beacon/proposer-slashings)
  + [Raw](/data-catalog/evm/beacon/raw)
  + [Validator Day Summaries](/data-catalog/evm/beacon/validator-day-summaries)
  + [Validators](/data-catalog/evm/beacon/validators)
  + [Voluntary Exits](/data-catalog/evm/beacon/voluntary-exits)
  + [Withdrawals](/data-catalog/evm/beacon/withdrawals)
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

Beacon

# Beacon Overview

Beacon Chain data on Dune

The Ethereum **Beacon Chain** is the backbone of Ethereum’s transition to a Proof-of-Stake (PoS) consensus mechanism. Launched on December 1, 2020, it introduced PoS to the Ethereum ecosystem, enhancing security, scalability, and energy efficiency.
**Key Features:**

* **Proof-of-Stake Consensus:** The Beacon Chain manages a registry of validators who propose and attest to new blocks, replacing the energy-intensive Proof-of-Work system.
* **Validator Coordination:** It coordinates validators, ensuring the network’s security and proper functioning by assigning responsibilities and managing rewards and penalties.
* **Foundation for Sharding:** The Beacon Chain lays the groundwork for future scalability improvements, such as sharding, which will enable the network to process more transactions concurrently.

**Data Catalog**
Explore the following datasets to gain insights into the Beacon Chain’s operations:

[## Attestations

Records of validator attestations, which are votes for a specific block, contributing to consensus and chain finality.](./attestations)[## Attester Slashings

Details of penalties imposed on validators who have violated protocol rules by signing conflicting attestations.](./attester-slashings)[## Blob Sidecars

Data related to blob sidecars, which are auxiliary data structures associated with blocks.](./blobs)[## Blocks

Information on Beacon Chain blocks, including proposer details, parent roots, and state roots.](./blocks)[## BLS to Execution Changes

Records of changes from BLS public keys to execution addresses, facilitating validator withdrawals.](./bls-to-execution-changes)[## Deposits

Details of ETH deposits made by validators to join the Beacon Chain and participate in staking.](./deposits)[## Epoch Summaries

Summarized data for each epoch, providing insights into validator performance and network health.](./epoch-summaries)[## Operators

Information about staking operators managing validator nodes on the Beacon Chain.](./operators)[## Proposer Slashings

Details of penalties imposed on validators who have proposed conflicting blocks.](./proposer-slashings)[## Validator Day Summaries

Daily summaries of validator activities, balances, and performance metrics.](./validator-day-summaries)[## Voluntary Exits

Records of validators voluntarily exiting the active set, ceasing their participation in consensus duties.](./voluntary-exits)[## Withdrawals

Information on ETH withdrawals by validators from the Beacon Chain to the execution layer.](./withdrawals)

These datasets provide a comprehensive view of the Beacon Chain’s functionality, validator activities, and the overall health of Ethereum’s PoS consensus layer.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/beacon/overview)

[NFT Trades](/data-catalog/evm/berachain/curated-data/nft/nft-trades)[Attestations](/data-catalog/evm/beacon/attestations)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.