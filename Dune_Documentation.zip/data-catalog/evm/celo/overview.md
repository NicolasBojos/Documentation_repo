[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Celo

Celo Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo

  + [Overview](/data-catalog/evm/celo/overview)
  + Raw
  + Decoded
  + Curated
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Catalog](#data-catalog)

Celo

# Celo Overview

Celo data on Dune

Celo is a blockchain ecosystem focused on increasing cryptocurrency adoption among smartphone users. By leveraging mobile access, Celo aims to empower anyone with a smartphone to access financial services, send money to phone contacts, and pay for goods and services with crypto.
The Celo network utilizes a unique consensus algorithm and a stablecoin ecosystem to offer secure, fast, and low-cost transactions. It’s designed to be light enough to run on mobile devices, reducing the barriers for entry and facilitating a user-friendly experience.
**Mobile-First Approach:**
Celo’s architecture is specifically tailored for mobile users, supporting easy integration and operation on smartphones, which is essential for accessibility in regions with limited access to traditional banking.
**Stablecoin Ecosystem:**
The network supports various stablecoins pegged to fiat currencies, facilitating everyday transactions and reducing the volatility typically associated with cryptocurrencies.
**Decentralized Finance (DeFi) Capabilities:**
Celo extends the reach of DeFi applications by enabling a suite of decentralized apps that are accessible on mobile devices, broadening financial inclusion.

[## Celo documentation

Access the official documentation for Celo, providing comprehensive information on its technology, mobile integration, and DeFi solutions.](https://docs.celo.org)

## [​](#data-catalog) Data Catalog

[## Logs

Detailed event logs from smart contracts, providing insights into interactions and activities within the Celo network.](./raw/logs)[## Blocks

Information on blocks processed, highlighting network activity and the performance of the mobile-first infrastructure.](./raw/blocks)[## Transactions

Extensive transaction data, showcasing the efficiency and user engagement across the network.](./raw/transactions)[## decoded

Decoded transaction data for better analysis and understanding of contract executions on Celo.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/celo/overview)

[NFT Trades](/data-catalog/evm/boba/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/celo/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.