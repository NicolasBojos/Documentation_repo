[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

DEX

dex\_aggregator.trades on celo

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo

  + [Overview](/data-catalog/evm/celo/overview)
  + Raw
  + Decoded
  + Curated

    - DEX

      * [Dex Trades](/data-catalog/evm/celo/curated-data/dex/dex-trades)
      * [Aggregator Trades](/data-catalog/evm/celo/curated-data/dex/dex-aggregator-trades)
    - NFT
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

DEX

# dex\_aggregator.trades on celo

Description of the Dex Aggregator Trades table for celo

This table is a cross-chain table but can be filtered for celo transactions.

## Table Description

The `dex_aggregator.trades` table captures high-level data on trades executed via decentralized exchange (DEX) aggregators. These aggregators aggregate liquidity from multiple DEXs to provide users with the best possible trade execution. Unlike the `dex.trades` table, which records each intermediary step of a trade, `dex_aggregator.trades` condenses the trade data to reflect the user's intended trade, presenting it as a single entry.

## Functional Overview

Users can expect the `dex_aggregator.trades` table to provide a high-level view of DEX trades facilitated by aggregators. This table simplifies trade records by showing a single entry for trades that may involve multiple DEXs and liquidity pools. For instance, a user might initiate a trade to swap USDC for PEPE via a DEX aggregator. The aggregator might route this trade through several liquidity pools such as WETH-USDC and WETH-PEPE, but `dex_aggregator.trades` will record it as a single USDC → PEPE trade.Complimentary to `dex_aggregator.trades` is the `dex.trades` table, where detailed trade executions are recorded. This table captures the granular steps of each trade, including interactions with different liquidity pools. The volume routed through aggregators is also recorded in the `dex.trades` table. One row in `dex_aggregator.trades` corresponds to one or more rows in `dex.trades`, providing a comprehensive view of the detailed execution path that aggregated trades take.

## Coverage

 The following table shows which projects and versions of those projects are covered in the `dex.trades` table on celo. 

## Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/celo/curated-data/dex/dex-aggregator-trades)

[Dex Trades](/data-catalog/evm/celo/curated-data/dex/dex-trades)[NFT Trades](/data-catalog/evm/celo/curated-data/nft/nft-trades)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.