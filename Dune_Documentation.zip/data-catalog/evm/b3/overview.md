[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

B3

B3 Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3

  + [Overview](/data-catalog/evm/b3/overview)
  + Raw
  + Decoded
  + Curated
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Catalog](#data-catalog)

B3

# B3 Overview

B3 data on Dune

B3 is a fun-first gaming ecosystem designed to bring the next generation of gamers and game creators onchain. Created by a team of Base/Coinbase alumni and OG Ethereum contributors, B3 provides a seamless gaming experience without the need for wallets, bridging, or switching networks. Players can dive into games instantly—just visit [Basement.fun](https://basement.fun) to experience it yourself.
**Fast, Cheap, and Scalable:**
B3 is a Layer 3 (L3) solution that settles on Base, delivering lightning-fast transactions with sub-cent fees. It is purpose-built for gamers, offering dedicated blockspace that scales to meet the demands of high-throughput games. Whether you’re building or playing, B3 ensures a smooth, low-cost experience.
**Onchain is the New Online:**
B3 envisions a future where onchain gaming becomes the new standard for online interactions, empowering game creators and rewarding creativity. B3 allows anyone to play games from anywhere, all while leveraging the security and scalability of Base.
**Scalable Architecture:**
B3’s rollup engine offers horizontal scaling through application-layer sharding. By orchestrating dedicated sidecars for games and other computationally heavy operations, B3 can handle web2-scale games while maintaining near gasless transactions.
**Built on Base:**
As a secure, low-cost Layer 2 incubated by Coinbase, Base provides the ideal foundation for B3. Leveraging Base as its settlement layer, B3 is positioned to further scale the Base ecosystem and contribute to its technical and product strategy.

[## B3 documentation

Explore comprehensive documentation of B3, detailing its architecture, protocol, and resources for developers.](https://docs.b3.fun/)

## [​](#data-catalog) Data Catalog

[## Logs

Detailed event logs from smart contracts, providing insights into interactions within the b3 network.](./raw/logs)[## Blocks

Information on blocks, illustrating the operational capacity and activity levels on b3.](./raw/blocks)[## Transactions

Extensive transaction data, showcasing the efficiency and execution of operations on b3.](./raw/transactions)[## decoded

Enhanced transaction data decoded for better analysis and understanding of contract executions.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/b3/overview)

[NFT Trades](/data-catalog/evm/avalanche/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/b3/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.