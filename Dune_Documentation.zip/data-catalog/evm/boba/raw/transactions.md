[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Raw

boba.transactions

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba

  + [Overview](/data-catalog/evm/boba/overview)
  + Raw

    - [Blocks](/data-catalog/evm/boba/raw/blocks)
    - [Creation Traces](/data-catalog/evm/boba/raw/creation-traces)
    - [Logs](/data-catalog/evm/boba/raw/logs)
    - [Transactions](/data-catalog/evm/boba/raw/transactions)
    - [Traces](/data-catalog/evm/boba/raw/traces)
  + Decoded
  + Curated
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

Raw

# boba.transactions

Description of the boba.transactions table on Dune

## Table Description

The `boba.transactions` table contains information about all transactions on the boba blockchain. Each row represents a single transaction and includes information such as block number, hash, timestamp, sender, recipient, value, gas, gas price, and more. Transactions are the fundamental unit of interaction with the boba blockchain. Transactions are created by users and are used to send value, deploy smart contracts, and interact with smart contracts.

This is the raw version of this table. If the chain is a Fully Managed chain, decoded transaction calls will be available, see [call tables](/data-catalog/evm/boba/decoded/call-tables) section. If this is a Hosted chain, decoded call tables will not be available.

## Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## Table Sample

## Examples

### Show all transactions sent by a specific address

```
SELECT * 
FROM boba.transactions WHERE "from" = '0x50A1b5c358F8D34F0d35aA2f10742c46054E247e'

```

### Count the number of transactions per block

```
SELECT 
    block_number, 
    COUNT(*)
FROM boba.transactions
GROUP BY 1
ORDER BY 1 DESC
LIMIT 10

```

### Show the top 10 transactions with the highest gas price

```
SELECT 
    hash, 
    gas_price
FROM boba.transactions
ORDER BY gas_price DESC
LIMIT 10

```

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/boba/raw/transactions)

[Logs](/data-catalog/evm/boba/raw/logs)[Traces](/data-catalog/evm/boba/raw/traces)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.