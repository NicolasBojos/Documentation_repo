[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Fantom

Fantom Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom

  + [Overview](/data-catalog/evm/fantom/overview)
  + Raw
  + Decoded
  + Curated
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Catalog](#data-catalog)

Fantom

# Fantom Overview

Fantom data on Dune

Fantom is a high-performance, scalable, and secure smart-contract platform that is designed to overcome the limitations of previous generation blockchain platforms. Fantom is unique in its use of a directed acyclic graph (DAG) architecture, which allows for asynchronous confirmation of transactions, resulting in high throughput and minimal transaction costs.
The network uses a bespoke consensus algorithm called Lachesis, which ensures transactions are confirmed within 1-2 seconds, significantly improving the user experience and efficiency for decentralized applications (dApps) running on the platform.
**High Throughput and Low Cost:**
Fantom’s DAG architecture enables unparalleled transaction speed and drastically reduced costs, making it an ideal platform for developers looking to build scalable dApps.
**Developer-Friendly:**
Fantom is fully compatible with Ethereum, allowing developers to deploy Ethereum-based applications quickly and seamlessly using existing tools and languages like Solidity.
**Ecosystem Growth:**
Fantom supports a growing ecosystem of decentralized finance (DeFi) applications, NFT platforms, and other blockchain projects, fostering innovation and new developments within its network.

[## Fantom documentation

Access comprehensive documentation for Fantom, detailing its unique technology, features, and developer resources.](https://docs.fantom.foundation)

## [​](#data-catalog) Data Catalog

[## Logs

Insights into smart contract interactions through detailed event logs, providing visibility into the dynamic activity on Fantom.](./raw/logs)[## Blocks

Information on blocks processed on Fantom, reflecting the network’s high throughput and capacity for handling large volumes of transactions.](./raw/blocks)[## Transactions

Extensive transaction data, highlighting the efficiency and speed of operations across the Fantom network.](./raw/transactions)[## decoded

Decoded transaction information for enhanced analysis and understanding of smart contract executions.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/fantom/overview)

[NFT Trades](/data-catalog/evm/ethereum/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/fantom/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.