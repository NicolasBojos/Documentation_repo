[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Blast

Blast Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast

  + [Overview](/data-catalog/evm/blast/overview)
  + Raw
  + Decoded
  + Curated
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Key Features:](#key-features%3A)
* [Data Catalog](#data-catalog)

Blast

# Blast Overview

Blast data on Dune Analytics

Blast is an Ethereum Layer 2 (L2) that natively provides yield for ETH and stablecoins. Blast is an EVM-compatible, optimistic rollup that raises the baseline yield for users and developers without changing the experience cryptonatives expect. This yield makes it possible to create new business models for Dapps that aren’t possible on other L2s.

### [​](#key-features%3A) Key Features:

* **Yield:** Blast is the only Ethereum L2 with native yield for ETH and stablecoins. The yield comes from ETH staking and RWA protocols. The default interest rate on other L2s is 0%. On Blast, it’s 4% for ETH and 5% for stablecoins.
* **Auto Rebasing:** ETH itself, not WETH, STETH, or any other ERC20, is natively rebasing on the L2. The ETH balance for EOAs is automatically rebasing. Smart contracts can opt-in to this rebasing, making it easy for existing Dapps to deploy on Blast without any changes. USDB, Blast’s native stablecoin, is automatically rebasing as well. Like ETH on Blast, USDB is automatically rebasing for EOAs. USDB is also automatically rebasing for smart contracts. Smart contracts can opt-out from this rebasing.
* **L1 Staking:** Blast only became possible following Ethereum’s Shanghai upgrade. ETH yield from L1 staking, initially Lido, is automatically transferred to users via rebasing ETH on the L2. In the future, the Blast community will have the power to supplement, or even fully replace, Lido with Blast-native solutions or other third-party protocols.
* **T-Bill Yield:** Users who bridge stablecoins receive USDB, Blast’s auto-rebasing stablecoin. The yield for USDB comes from MakerDAO’s on-chain T-Bill protocol. USDB can be redeemed for DAI when bridging back to Ethereum. In the future, the Blast community will have the power to supplement, or even fully replace, MakerDAO with Blast-native solutions or other third-party protocols.
* **Gas Revenue Sharing:** Other L2s keep revenue from gas fees for themselves. Blast gives net gas revenue back to Dapps programmatically. Dapps developers can keep this revenue for themselves or use it to subsidize gas fees for users.

[## Blast documentation

Explore comprehensive documentation on Blast, detailing its architecture, protocol, and resources for developers.](https://docs.blast.io/)

## [​](#data-catalog) Data Catalog

[## Logs

Detailed event logs from smart contracts, providing insights into interactions within the Blast network.](./raw/logs)[## Blocks

Information on blocks, illustrating the operational capacity and activity levels on Blast.](./raw/blocks)[## Transactions

Extensive transaction data, showcasing the efficiency and execution of operations on Blast.](./raw/transactions)[## Decoded

Enhanced transaction data decoded for better analysis and understanding of contract executions.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/blast/overview)

[Withdrawals](/data-catalog/evm/beacon/withdrawals)[Blocks](/data-catalog/evm/blast/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.