[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Ink

Ink Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink

  + [Overview](/data-catalog/evm/ink/overview)
  + Raw
  + Decoded
  + Curated
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is Ink?](#what-is-ink%3F)
* [Technical Architecture](#technical-architecture)
* [Optimistic Rollup Technology](#optimistic-rollup-technology)
* [Network Specifications](#network-specifications)
* [Developer Tools & Infrastructure](#developer-tools-%26-infrastructure)
* [Compatibility & Integration](#compatibility-%26-integration)
* [Data Catalog](#data-catalog)

Ink

# Ink Overview

Ink data on Dune

## [​](#what-is-ink%3F) What is Ink?

Ink is Kraken’s dedicated DeFi chain, built as a Layer 2 solution using the OP Stack technology. As part of the Superchain ecosystem, it provides a scalable, secure environment for decentralized finance applications while maintaining full compatibility with the Ethereum ecosystem.

## [​](#technical-architecture) Technical Architecture

Ink’s architecture leverages the OP Stack to deliver a robust DeFi-focused platform:

### [​](#optimistic-rollup-technology) Optimistic Rollup Technology

* Inherits Ethereum’s security through optimistic rollups
* Posts transaction data to Ethereum mainnet
* Uses fraud proofs for security guarantees
* Provides fast transaction finality with L2 execution

### [​](#network-specifications) Network Specifications

* **Technology Stack**: OP Stack (Superchain)
* **Gas Token**: ETH
* **Challenge Period**: ~7 days
* **Block Time**: ~2 seconds
* **Network Type**: EVM-compatible Layer 2

### [​](#developer-tools-%26-infrastructure) Developer Tools & Infrastructure

* **Smart Contract Development**: Support for Foundry, Hardhat, and Remix
* **Block Explorers**: Multiple options for transaction monitoring
* **Infrastructure**:
  + Account Abstraction support
  + Cross-chain bridges
  + Oracle integration
  + VRF capabilities
  + Indexing services

### [​](#compatibility-%26-integration) Compatibility & Integration

* Full EVM compatibility
* Native bridge functionality
* Support for standard Ethereum development tools
* Seamless integration with existing Ethereum infrastructure

[## Ink Documentation

Official documentation for developers building on Ink - Kraken’s DeFi chain](https://docs.inkonchain.com)

## [​](#data-catalog) Data Catalog

[## Logs

Insights into smart contract interactions through event logs](./raw/logs)[## Blocks

Information on blocks processed on Ink](./raw/blocks)[## Transactions

Detailed data on transactions](./raw/transactions)[## decoded

Decoded transaction information for enhanced analysis](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/ink/overview)

[Dex Trades](/data-catalog/evm/hemi/curated-data/dex/dex-trades)[Blocks](/data-catalog/evm/ink/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.