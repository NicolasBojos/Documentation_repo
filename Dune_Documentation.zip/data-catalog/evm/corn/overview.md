[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Corn

Corn Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn

  + [Overview](/data-catalog/evm/corn/overview)
  + Raw
  + Decoded
  + Curated
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [What is Corn?](#what-is-corn%3F)
* [Key Features](#key-features)
* [Why Corn?](#why-corn%3F)
* [Technical Architecture](#technical-architecture)
* [Development Features](#development-features)
* [Network Economics](#network-economics)
* [Data Catalog](#data-catalog)

Corn

# Corn Overview

Corn data on Dune

## [​](#what-is-corn%3F) What is Corn?

Corn is a next-generation Ethereum Layer 2 network specifically designed to unlock the full potential of Bitcoin. Built on Arbitrum Orbit, it provides a Bitcoin-centric ecosystem that combines scalability, efficiency, and innovative features to enhance the Bitcoin ecosystem.

## [​](#key-features) Key Features

* **Bitcorn (BTCN)**: Native gas token of the network
* **popCORN System**: Provides long-term incentives for ecosystem participants
* **LayerZero Integration**: Enables seamless cross-chain asset transfers
* **Arbitrum Orbit**: Leverages Arbitrum’s technology for scalability and efficiency
* **Stylus Support**: Allows developers to use multiple programming languages for smart contract development

## [​](#why-corn%3F) Why Corn?

Corn positions itself as the “Butter Network” with three main value propositions:

* Butter yield
* Butter BTC
* Butter vibes

It’s designed to be the optimal platform for putting Bitcoin to work, creating a rich ecosystem of Bitcoin-focused applications and services.

## [​](#technical-architecture) Technical Architecture

Built on Arbitrum Orbit, Corn inherits the robust technical foundation of Arbitrum while adding Bitcoin-specific optimizations:

### [​](#development-features) Development Features

* **Multiple Language Support**: Through Stylus integration, developers can write smart contracts in various programming languages
* **Bitcoin Integration**: Native support for Bitcoin-related operations and assets
* **Cross-chain Capabilities**: LayerZero integration for efficient cross-chain transactions

### [​](#network-economics) Network Economics

* **Gas Token**: Bitcorn (BTCN)
* **Incentive Structure**: popCORN System for sustainable long-term ecosystem growth

[## Corn Documentation

Official documentation for developers building on Corn - The Butter Network for Bitcoin](https://docs.usecorn.com)

## [​](#data-catalog) Data Catalog

[## Logs

Insights into smart contract interactions through event logs](./raw/logs)[## Blocks

Information on blocks processed on Corn, reflecting network activity and capacity](./raw/blocks)[## Transactions

Detailed data on transactions, showcasing efficiency and operational execution](./raw/transactions)[## decoded

Decoded transaction information for enhanced analysis and understanding of smart contract executions](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/corn/overview)

[NFT Trades](/data-catalog/evm/celo/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/corn/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.