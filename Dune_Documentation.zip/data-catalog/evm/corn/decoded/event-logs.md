[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Decoded

Event Logs

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn

  + [Overview](/data-catalog/evm/corn/overview)
  + Raw
  + Decoded

    - [Corn Decoded Overview](/data-catalog/evm/corn/decoded/overview)
    - [Corn Call Tables](/data-catalog/evm/corn/decoded/call-tables)
    - [Event Logs](/data-catalog/evm/corn/decoded/event-logs)
    - [Decoded Contracts](/data-catalog/evm/corn/decoded/contracts)
    - [Decoded Logs](/data-catalog/evm/corn/decoded/logs-decoded)
    - [traces\_decoded](/data-catalog/evm/corn/decoded/traces-decoded)
  + Curated
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Overview](#overview)
* [Event Logs in Dune](#event-logs-in-dune)
* [Example](#example)
* [Multiple Instances](#multiple-instances)
* [Further Reading](#further-reading)

Decoded

# Event Logs

Smart Contracts emit event logs when certain predefined actions are completed.

## [​](#overview) Overview

Smart contracts emit event logs when certain predefined actions are completed. The emitted event logs are stored on the blockchain and are publicly accessible. Event logs are an important tool for smart contract developers to communicate with the outside world, as well as for data analysts to keep track of what happens inside of a smart contract.
For example, the ERC20 standard defines the `Transfer` event, which is emitted every time a token transfer occurs. The event log contains the sender, the recipient and the amount of tokens transferred.

Copy

Ask AI

```
event Transfer(address indexed from, address indexed to, uint256 value);

```

Decoded event logs always originate from the fields `topic0`, `topic1`, `topic2`, `topic3` and `data` in the `logs` table.

## [​](#event-logs-in-dune) Event Logs in Dune

In Dune, we store all event logs of decoded smart contracts in separate tables.
The structure published in these logs is predefined by the developer of the smart contract, the content is dynamically created during the transaction.
Logs are useful for monitoring, alerting and in general keeping track of what happens inside of a smart contract. Logs are your best friend as a data analyst since they reliably present you with data that is intended to be analyzed post factum. If you ever want to see which logs *can* be emitted by a smart contract, you can simply search for the keyword `emit` in the source code of the smart contract.
We will decode all event logs for smart contracts into tables named accordingly to this schema:
`[projectname_blockchain].[contractName]_evt_[eventName]`

## [​](#example) Example

Let’s take the [uniswap v3 factory](https://etherscan.io/address/0x1f98431c8ad98523631ae4a59f267346ea31f984#code) as an example and look at the event that gets emitted upon the creation of a new pool. The event is called `PoolCreated` and gets emitted every time somebody successfully deploys a new Uniswap V3 pool by calling the function `createPool`. The event will readily give us information like the tokens in the pool, the fee tier of this pool and the tick spacing. In Etherscan, you can easily look at the event logs of transaction by opening the [logs tab](https://etherscan.io/tx/0xdeb368592f3de0f2840754bce61d2c3f29cdb3407c63c699052e68a854c71eaa#eventlog). In Dune, this particular event will be stored in the table:
`uniswap_v3_ethereum.Factory_evt_PoolCreated`

## [​](#multiple-instances) Multiple Instances

If there is multiple instances of a contract we will collect all event logs across all instances of this smart contract in one table. For example, all uniswap v3 pool `swap` events (on ethereum) are stored in the table: `uniswap_v3_ethereum.Pair_evt_Swap`
The column `contract_address` indicates as to which smart contract emitted this event.

## [​](#further-reading) Further Reading

* [Understanding event logs on the Ethereum blockchain](https://medium.com/mycrypto/understanding-event-logs-on-the-ethereum-blockchain-f4ae7ba50378)
* [Everything You Ever Wanted to Know About Events and Logs on Ethereum](https://medium.com/linum-labs/everything-you-ever-wanted-to-know-about-events-and-logs-on-ethereum-fec84ea7d0a5)

[## Submit any contract for decoding](/web-app/decoding/decoding-contracts)[## Explore already decoded contracts](/data-catalog/evm/ethereum/decoded/contracts)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/corn/decoded/event-logs)

[Corn Call Tables](/data-catalog/evm/corn/decoded/call-tables)[Decoded Contracts](/data-catalog/evm/corn/decoded/contracts)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.