[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Decoded

Avalanche C-Chain Call Tables

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche

  + [Overview](/data-catalog/evm/avalanche/overview)
  + Raw
  + Decoded

    - [Avalanche C-Chain Decoded Overview](/data-catalog/evm/avalanche/decoded/overview)
    - [Avalanche C-Chain Call Tables](/data-catalog/evm/avalanche/decoded/call-tables)
    - [Event Logs - Avalanche](/data-catalog/evm/avalanche/decoded/event-logs)
    - [Decoded Contracts](/data-catalog/evm/avalanche/decoded/contracts)
    - [Decoded Logs](/data-catalog/evm/avalanche/decoded/logs-decoded)
    - [Decoded Traces](/data-catalog/evm/avalanche/decoded/traces-decoded)
  + Curated
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Overview](#overview)
* [Decoding](#decoding)
* [Multiple Instances](#multiple-instances)
* [Common misconceptions](#common-misconceptions)
* [Further Reading](#further-reading)

Decoded

# Avalanche C-Chain Call Tables

On Dune, we parse all message calls and transactions made to smart contracts on the Avalanche C-Chain network in their own tables.

## [​](#overview) Overview

On Dune, we parse all message calls and transactions made to smart contracts in their own tables. This allows us to isolate the logic of a specific smart contract and analyze how it interacts with other smart contracts.
The data is stored in the format:
`[projectname_blockchain].[contractName]_call_[functionName]`
This allows us to analyze how a specific function is used in a smart contract, and how often it is called, as well as how it interacts with other smart contracts.
Call tables always originate from the `traces` table, which contains all the transactions and message calls on the Ethereum network. We parse the `data` field of the `traces` table to decode the function call and parameters.

## [​](#decoding) Decoding

When a transaction is sent to a smart contract on the Ethereum network, it contains a `data` field. This `data` field is the encoded function call and parameters. Dune decodes this data and stores it in the corresponding table.
For example, when a transaction is sent to the [Uniswap v3 factory](https://etherscan.io/address/0x1f98431c8ad98523631ae4a59f267346ea31f984#code) contract on the Ethereum network, Dune will decode the `data` field and store it in the table:
`uniswap_v3_ethereum.Factory_call_createPool`

## [​](#multiple-instances) Multiple Instances

For a contract where multiple instances exist, we will decode all calls to all instances of this smart contract into one table. If there are transactions calling the `swap` function of any instance of the [Uniswap v3 pair](https://etherscan.io/address/0x8f8ef111b67c04eb1641f5ff19ee54cda062f163#writeContract) contract, we will decode this data into the table `uniswap_v3_ethereum.Pair_call_swap`. The `pair` contract is a template contract and there are many instances of it, each with its own address. The column `contract_address` will indicate the address of the instance of the pair contract that was called.

## [​](#common-misconceptions) Common misconceptions

One thing to keep in mind here is that [web3.js](https://web3js.readthedocs.io), [web3.py](https://web3py.readthedocs.io/en/stable) and all other methods of (locally) calling a `pure`, `read`, or `constant` function do not broadcast or publish anything on the blockchain and are therefore not recorded in Dune.
However, if one of these functions is invoked by another smart contract in the context of a transaction, this will be broadcast on the chain and therefore accessible in Dune.
In short: **State data stored in the memory of a smart contract is not available on Dune!**
A good example of this is the function `decimals` of the [erc20 token contract](https://etherscan.io/token/0x1f9840a85d5af5bf1d1762f925bdaddc4201f984#readContract) `Uni` which is a `constant` state variable that is able to be accessed through an automatically created “[getter function](https://docs.soliditylang.org/en/v0.7.4/contracts.html#getter-functions)”. Should a smart contract invoke this function in the context of transaction, this message call will be recorded in the Dune table [`uniswap."UNI_call_decimals"`](https://dune.com/queries/741354).
This is in contrast to anyone calling this function locally using web3.py/web3.js or using the Etherscan frontend to access this state. These local calls are not recorded in Dune.

## [​](#further-reading) Further Reading

[## What is the difference between a transaction and a call?](https://ethereum.stackexchange.com/questions/765/what-is-the-difference-between-a-transaction-and-a-call)[## Soliditylang.org documentation](https://docs.soliditylang.org/en/v0.8.13/contracts.html#function-visibility)[## How Calldata is Encoded](https://degatchi.com/articles/reading-raw-evm-calldata)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/avalanche/decoded/call-tables)

[Avalanche C-Chain Decoded Overview](/data-catalog/evm/avalanche/decoded/overview)[Event Logs - Avalanche](/data-catalog/evm/avalanche/decoded/event-logs)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.