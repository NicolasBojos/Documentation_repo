[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

NFT

NFT.trades on gnosis

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis

  + [Overview](/data-catalog/evm/gnosis/overview)
  + Raw
  + Decoded
  + Curated

    - DEX
    - NFT

      * [NFT Trades](/data-catalog/evm/gnosis/curated-data/nft/nft-trades)
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

NFT

# NFT.trades on gnosis

The `nft.trades` table captures detailed data on NFT marketplaces, recording all trade events across various protocols on gnosis.

This is a cross-chain table but can be filtered for gnosis transactions.

## Table Description

The `nft.trades` table on Dune Analytics is central to capturing and analyzing Non-Fungible Token (NFT) transactions across various marketplaces. It is a pivotal resource for dissecting the intricacies of NFT trade execution, market behavior, and collector activity within the NFT space.

## Usage

The `nft.trades` table serves as an essential tool for delving into the NFT market's complexities. It offers a detailed snapshot of each NFT transaction, encompassing data points such as sale price, transaction timestamp, buyer and seller addresses, and the specific NFT assets involved. This table allows analysts to explore trends in NFT valuation, trading volumes, and marketplace dynamics, providing insights into the evolving landscape of digital collectibles and art.

## Table Coverage

 The following table shows which projects and versions of those projects are covered in the `dex.trades` table on gnosis. 

## Column Descriptions

Datatypes on Snowflake datashare are different in some cases, read more [here](/datashare/datashare#datatypes).

## Table Sample

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/gnosis/curated-data/nft/nft-trades)

[Aggregator Trades](/data-catalog/evm/gnosis/curated-data/dex/dex-aggregator-trades)[Overview](/data-catalog/evm/hemi/overview)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.