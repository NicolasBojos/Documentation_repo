[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Gnosis

Gnosis Chain Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis

  + [Overview](/data-catalog/evm/gnosis/overview)
  + Raw
  + Decoded
  + Curated
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

On this page

* [Data Catalog](#data-catalog)

Gnosis

# Gnosis Chain Overview

Gnosis Chain data on Dune

Gnosis Chain is a Layer 2 scaling solution designed for Ethereum, focusing on creating a low-cost, high-efficiency platform for decentralized applications (dApps). Formerly known as xDai Chain, Gnosis Chain emphasizes predictability in transaction costs, which are paid in the native stablecoin, xDAI.
This platform uses a unique consensus mechanism called POSDAO, which is a Proof of Stake system that provides enhanced security and scalability while supporting environmental sustainability. Gnosis Chain is compatible with Ethereum, allowing Ethereum assets and projects to transition smoothly without the need for code changes.
**Cost Efficiency and Predictability:**
Transaction costs on Gnosis Chain are highly predictable, making it an attractive platform for developers and businesses that require consistent budgeting for blockchain operations.
**Ethereum Compatibility:**
Full compatibility with Ethereum ensures that developers can leverage existing tools and infrastructures to deploy and manage their applications on Gnosis Chain with minimal adjustments.

[## Gnosis Chain documentation

Explore the official documentation for Gnosis Chain, which provides a deep dive into its consensus mechanism, network features, and how to develop on the platform.](https://docs.gnosischain.com)

## [​](#data-catalog) Data Catalog

[## Logs

Event logs from smart contracts, offering detailed insights into interactions and activities within the Gnosis Chain network.](./raw/logs)[## Blocks

Data on blocks processed, illustrating the network’s capacity and the performance of its POSDAO system.](./raw/blocks)[## Transactions

Comprehensive transaction data, showcasing the efficiency and cost-effectiveness of operations on Gnosis Chain.](./raw/transactions)[## decoded

Decoded transaction data for easier analysis and better understanding of contract executions on Gnosis Chain.](./decoded/overview)

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/gnosis/overview)

[NFT Trades](/data-catalog/evm/flare/curated-data/nft/nft-trades)[Blocks](/data-catalog/evm/gnosis/raw/blocks)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.