[Dune Docs home page![light logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-light.png)![dark logo](https://mintlify.s3.us-west-1.amazonaws.com/dune/logo/dune-logo-dark.png)](/)

Search...

⌘KAsk AI

* [Support](mailto:support@dune.com)
* [Start building](https://dune.com)
* [Start building](https://dune.com)

Search...

Navigation

Decoded

Gnosis Chain Decoded Overview

[Get Started](/home)[Analytics Studio](/web-app/overview)[Query Engine](/query-engine/overview)[Data Catalog](/data-catalog/overview)[Analytics API](/api-reference/overview/introduction)[Datashare](/datashare/datashare)[Catalyst](/catalyst/overview)

#####

* [Data Catalog](/data-catalog/overview)
* [Data Freshness](/data-catalog/data-freshness)
* [Bring your Data](/data-catalog/bring-your-own-data)

##### Curated Data

* [Overview](/data-catalog/curated/overview)
* DEX Trades
* Token Transfers
* Labels
* Prices
* NFT Trades

##### EVM Networks

* [Overview](/data-catalog/evm/overview)
* Abstract
* ApeChain
* Arbitrum One
* Arbitrum Nova
* Avalanche
* B3
* Base
* Berachain
* Beacon
* Blast
* BNB
* BOB
* Boba
* Celo
* Corn
* Degen
* Ethereum
* Fantom
* Flare
* Gnosis

  + [Overview](/data-catalog/evm/gnosis/overview)
  + Raw
  + Decoded

    - [Gnosis Chain Decoded Overview](/data-catalog/evm/gnosis/decoded/overview)
    - [Gnosis Chain Call Tables](/data-catalog/evm/gnosis/decoded/call-tables)
    - [Event Logs](/data-catalog/evm/gnosis/decoded/event-logs)
    - [Decoded Contracts](/data-catalog/evm/gnosis/decoded/contracts)
    - [Decoded Logs](/data-catalog/evm/gnosis/decoded/logs-decoded)
    - [Decoded Traces](/data-catalog/evm/gnosis/decoded/traces-decoded)
  + Curated
* Hemi
* Ink
* KAIA
* Katana
* Lens
* Linea
* Mantle
* opBNB
* Optimism
* Plume
* Polygon
* Polygon-zkEVM
* Ronin
* Scroll
* Sei
* Sepolia
* Shape
* Sonic
* Sophon
* Superseed
* Tac
* Taiko
* Unichain
* Viction
* World Chain
* zkSync
* Zora

##### Other Networks

* Aptos
* Bitcoin
* Fuel
* Noble
* NEAR
* Polkadot
* Solana
* Starknet
* Stellar
* TON
* XRPL
* Tron

##### Protocols

* LayerZero

##### Community Data

* Flashbots
* Farcaster
* Lens
* Reservoir
* Snapshot

##### Dune Index

* [Introduction](/data-catalog/dune-index/introduction)
* [Transactions Fees](/data-catalog/dune-index/gas-fees)
* [Net Transfers](/data-catalog/dune-index/net-transfers)
* [Transactions](/data-catalog/dune-index/transactions)

Decoded

# Gnosis Chain Decoded Overview

Simplifying Gnosis Chain smart contract analysis through human-readable tables.

## Overview of Dune's Decoded Data Approach

Dune uses the ABI (Application Binary Interface) of smart contracts to decode blockchain transactions into structured tables. Each event log and function call from the ABI are parsed into their own tables. This decoding process transforms the raw, encoded data on the blockchain into human-readable tables, simplifying the analysis of smart contract data.Dune's decoded data approach offers several benefits:

* **Enhanced Readability:** The decoded data tables provide a clear and intuitive representation of smart contract activities.
* **Efficient Analysis:** The structured tables enable efficient querying and analysis of smart contract data.
* **Handling Multiple Contract Instances:** For smart contracts with multiple instances, Dune aggregates the data from these instances into a single table, simplifying the analysis process.
* **Collaborative Mapping:** Dune's smart contract library is continuously expanded through the active participation of the Dune community, ensuring that the decoding coverage remains comprehensive and current.

[## Explore decoded logs](/data-catalog/evm/gnosis/decoded/event-logs)[## Explore decoded traces](/data-catalog/evm/gnosis/decoded/call-tables)

## Which contracts have decoded data?

Contract submission on Dune are driven by the community. Usually, the odds are good that the contract you are looking at is already decoded, but especially for new projects or new contracts, it might be that the contract is not decoded yet. In those cases, you can submit the contract to be decoded. Decoding usually takes about 24 hours, in special cases it might take longer.You can check if contracts are already decoded by querying the `[blockchain].contracts` tables, the [data explorer](/web-app/query-editor/data-explorer), or use [this dashboard](https://dune.com/dune/is-my-contract-decoded-yet-v2).If you want to submit several contracts at the same time, there is also the possibility of submitting a batch of contracts. To do so, please use [this CSV](https://gist.github.com/antonio-mendes/c6a43c22862581674c11462cae230e23) as a template and fill it in with the appropriate information for the contracts you want to decode. Afterwards, send the CSV to decoding@dune.com.

[## Submit any contract for decoding](/web-app/decoding-contracts)[## Explore already decoded contracts](/data-catalog/evm/gnosis/decoded/contracts)

## How does decoding work?

Smart Contracts on any EVM blockchain are mostly written in high-level languages like [Solidity](https://docs.soliditylang.org/en/v0.8.2) or [Vyper](https://vyper.readthedocs.io/en/stable). In order for them to be deployed to an EVM execution environment, they need to be compiled to EVM executable bytecode. Once deployed, the bytecode gets associated with an address on the respective chain and is permanently stored in the chain's state storage.To be able to interact with this smart contract, which is now just bytecode, we need a guide to call the functions defined in the high-level languages. This translation of names and arguments into byte representation is done using an **Application Binary Interface (ABI)**. The ABI documents names, types, and arguments precisely, which allows us to interact with the smart contract using a somewhat human-readable format. The ABI can be compiled using the high-level language source code.**The ABI is used to call a smart contract or interpret the data it emits.**![Decoding process illustration](/data-catalog/images/decoding.png)

## Decoding Example

We are going to look at an event log of an ERC20 transfer event from the [smart contract](https://etherscan.io/token/0x429881672B9AE42b8EbA0E26cD9C73711b891Ca5#readContract) that represents the $PICKLE token. On [Etherscan](https://etherscan.io/tx/0x2bb7c8283b782355875fa37d05e4bd962519ea294678a3dcf2fdffbbd0761bc5#eventlog), the undecoded event looks like this:![Etherscan event log screenshot](/data-catalog/images/etherscan.png)If we query for this transaction in the `ethereum.logs` table in the Dune database, we will receive the same encoded bytecode as our result dataset.

```
SELECT *
FROM ethereum.logs
WHERE tx_hash = 0x2bb7c8283b782355875fa37d05e4bd962519ea294678a3dcf2fdffbbd0761bc5

```

We could make short work of this encoded bytecode by using [DuneSQL Varbinary functions](/query-engine/Functions-and-operators/varbinary) to decode it, but having the contract's ABI at hand makes this process much easier.   
This contract is decoded in Dune, so we can use the `pickle_finance_ethereum.PickleToken_evt_Transfer` table to access the decoded event log.

```
SELECT *
FROM pickle_finance_ethereum.PickleToken_evt_Transfer
WHERE evt_tx_hash = 0x2bb7c8283b782355875fa37d05e4bd962519ea294678a3dcf2fdffbbd0761bc5
```

**Now this is actually useful for analyzing this transaction!** This data is much more readable and understandable than the encoded bytecode. We can see the sender, receiver, and the amount of tokens transferred in this event log.

## How do I understand decoded data?

Decoded data is the high level programming language representation of two pieces of software talking to each other via the blockchain.It's not always easy for a human to understand what exactly is going on in these interactions, but most of the time, looking at column names and the data that is transmitted within them should help you to understand what is happening within that specific log or call.If you are not able to make sense of the data by just searching the tables, it usually helps to look at single transactions using the transaction hash and [Etherscan](https://etherscan.io).Furthermore, going into the code of the smart contract (our favorite way to do this is [DethCode](https://etherscan.deth.net)) to read the comments or the actual logic can help to understand the smart contract's emitted data.If that also doesn't lead to satisfactory results, scouring the relevant docs and GitHub of the project can lead you to the desired answers. Furthermore, talking to the developers and core community of a project can also help you to get an understanding of the smart contracts.

Was this page helpful?

YesNo

[Raise issue](https://github.com/duneanalytics/dune-docs/issues/new?title=Issue on docs&body=Path: /data-catalog/evm/gnosis/decoded/overview)

[Traces](/data-catalog/evm/gnosis/raw/traces)[Gnosis Chain Call Tables](/data-catalog/evm/gnosis/decoded/call-tables)

[linkedin](https://www.linkedin.com/company/dune-analytics)[github](https://github.com/duneanalytics)[twitter](https://x.com/dune)[discord](https://discord.gg/ErrzwBz)[telegram](https://t.me/dune_updates)[youtube](https://www.youtube.com/@dunecom)

[Powered by Mintlify](https://mintlify.com/preview-request?utm_campaign=poweredBy&utm_medium=referral&utm_source=dune)

Assistant

Responses are generated using AI and may contain mistakes.